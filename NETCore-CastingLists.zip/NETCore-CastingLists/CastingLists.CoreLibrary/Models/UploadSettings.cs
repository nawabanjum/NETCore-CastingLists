﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models
{
   public class UploadSettings
    {
        public int LogoFileSizeLimitInBytes { get; set; }
        public string ImdbSaveFolderLocation { get; set; }
        public string ImdbSaveUrlLocation { get; set; }
        public string ActorCardSaveFolderLocation { get; set; }
        public string ActorCardSaveUrlLocation { get; set; }
    }

    public class ValidImageExtensions
    {
        public string Extensions { get; set; }
        
    }
    public class CWBActorPhotoSetting
    {
        public string ActorImagesLocation { get; set; }
        public string HttpActorImagesLocation { get; set; }

    }
    public class ValidateImageSizes
    {
        public string ImageSizes { get; set; }

    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorImdbArchiveDTO
    {
        public int Id { get; set; }
        [JsonPropertyName("ActorId")]
        public int ActorRId { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        public string ImdbId { get; set; }
        public string Json { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
    }
}

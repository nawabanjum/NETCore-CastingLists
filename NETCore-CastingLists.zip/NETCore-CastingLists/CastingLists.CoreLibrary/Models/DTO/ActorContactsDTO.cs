﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorContactsDTO
    {
        public int ContactId { get; set; }
        [MaxLength(250)]
        public string ContactType { get; set; }
        [MaxLength(250)]
        public string ContactGroup { get; set; }
        [MaxLength(250)]
        public string ContactName { get; set; }
        [MaxLength(250)]
        public string ContactCompany { get; set; }
        [MaxLength(250)]
        public string ContactCompanyImdb { get; set; }
        [MaxLength(250)]
        public string ContactCompanyWebSite { get; set; }
        [MaxLength(250)]
        public string ContactCompanyPhone { get; set; }
        [MaxLength(250)]
        public string ContactCompanyEmail { get; set; }
        [MaxLength(250)]
        public string ContactCompanyAddress { get; set; }
        [MaxLength(50)]
        public string ContactPhone { get; set; }
        [MaxLength(50)]
        public string ContactCountry { get; set; }
        [MaxLength(250)]
        public string ContactImdbLink { get; set; }
        [MaxLength(250)]
        public string ContactWebSite { get; set; }
        [MaxLength(250)]
        public string ContactEmail { get; set; }
        public int ActorId { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
        public bool IsDeleted { get; set; }
        
    }
}

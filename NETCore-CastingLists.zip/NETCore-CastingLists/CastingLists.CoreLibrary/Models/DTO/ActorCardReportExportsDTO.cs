﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class ActorCardReportExportsDTO
    {
		public int Id { get; set; }
		public int ListId { get; set; }
		[Required]
		[MaxLength(256)]
		public string Title { get; set; }
	
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public int CreatedByUserId { get; set; }
		[JsonIgnore]
		public int CreatedByUserType { get; set; }
		public string JsonData { get; set; }
	}
	public class ActorCardReportExportsListDTO
	{
		public int Id { get; set; }
		public int ListId { get; set; }
		public string Title { get; set; }
		public DateTime CreatedOn { get; set; }
		public int CreatedByUserId { get; set; }
		public int CreatedByUserType { get; set; }
	}
}

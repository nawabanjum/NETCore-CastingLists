﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class TreeDTO
    {
        public CommonLookUpNodeDTO ProjectNode { get; set; }
        public List<CommonLookUpChildNodeDTO> ListNode { get; set; }
        public List<CommonLookUpChildNodeDTO> RoleNode { get; set; }
        public TreeDTO()
        {
            this.ProjectNode = new CommonLookUpNodeDTO();
            this.RoleNode = new List<CommonLookUpChildNodeDTO>();
            this.ListNode = new List<CommonLookUpChildNodeDTO>();
        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorDTO
    {
        public int ActorId { get; set; }
        public string ImdbId { get; set; }
        [Required]
        [MaxLength(120)]
        public string FirstName { get; set; }
        [MaxLength(120)]
        public string LastName { get; set; }
        public string PictureUrl { get; set; }
        public string ImageSourceUrl { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public decimal? RankStarMeeter { get; set; }
        public string AgeRange { get; set; }
        public string Gender { get; set; }
        public string Height { get; set; }
        public string Weigth { get; set; }
        public string Ethnicity { get; set; }
        public string Ranking { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        public string OriginalPlatform { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedPlatform { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public bool IsDeleted { get; set; }
       
        public List<ActorContactsDTO> ActorContacts { get; set; }
        public List<SocialLinkDTO> SocialLinks { get; set; }
        public List<KnowsForDTO> KnowsFors { get; set; }
        public List<FilmographyDTO>  Filmography { get; set; }
        public ActorDTO()
        {
            this.SocialLinks = new List<SocialLinkDTO>();
            this.KnowsFors = new List<KnowsForDTO>();
            this.ActorContacts = new List<ActorContactsDTO>();
            this.Filmography = new List<FilmographyDTO>();
        }

        // populate field from the settings, so the front-end can access the image link directly
        public string ImageTarget {get;set;}
    }
    public class ActorImportDTO
    {
        public int ActorId { get; set; }
        public string ImdbId { get; set; }
        [Required]
        [MaxLength(120)]
        public string FirstName { get; set; }
        [MaxLength(120)]
        public string LastName { get; set; }
        public string ImageSourceUrl { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public decimal? RankStarMeeter { get; set; }
        public string AgeRange { get; set; }
        public string Gender { get; set; }
        public string Height { get; set; }
        public string Weigth { get; set; }
        public string Ethnicity { get; set; }
        public string Ranking { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        public string OriginalPlatform { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedPlatform { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public bool IsDeleted { get; set; }

        public List<ActorContactsDTO> ActorContacts { get; set; }
        public List<SocialLinkDTO> SocialLinks { get; set; }
        public List<KnowsForDTO> KnowsFors { get; set; }
        public List<FilmographyDTO> Filmography { get; set; }
        public ActorImportDTO()
        {
            this.SocialLinks = new List<SocialLinkDTO>();
            this.KnowsFors = new List<KnowsForDTO>();
            this.ActorContacts = new List<ActorContactsDTO>();
            this.Filmography = new List<FilmographyDTO>();
        }
    }
    public class ActorRankDTO
    {
        public int ActorId { get; set; }
        public decimal RankStarMeeter { get; set; }
    }
    public class ActorImageDTO
    {
        public int ActorId { get; set; }
        public string ImageLink { get; set; }
        [JsonIgnore]
        public string ImageSourceUrl { get; set; }

    }
}

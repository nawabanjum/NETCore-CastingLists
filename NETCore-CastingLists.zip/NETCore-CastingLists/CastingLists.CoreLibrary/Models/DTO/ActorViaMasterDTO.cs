﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class MasterDto
    {
        public ActorViaMasterDTO  actorViaMasterDTO { get; set; }
        public ActorContactViaMasterDTO  actorContactViaMasterDTO { get; set; }
        public ActorViaMasterClientDTO  actorViaMasterClientDTO { get; set; }
        public List<ActorImageViaMasterDTO>  actorImageViaMasterDTO { get; set; }
        public MasterDto()
        {
            this.actorContactViaMasterDTO = new ActorContactViaMasterDTO();
            this.actorViaMasterDTO = new ActorViaMasterDTO();
            this.actorViaMasterClientDTO = new ActorViaMasterClientDTO();
            this.actorImageViaMasterDTO = new List<ActorImageViaMasterDTO>();
        }
    }
    public class ActorViaMasterDTO
    {
        public string Agentname { get; set; }
        public string Firstname { get; set; }
        public string Middlename { get; set; }
        public string Lastname { get; set; }
        public int Gender { get; set; }
        public int Heightfeet { get; set; }
        public int Heightinches { get; set; }
        public int Weight { get; set; }
        public DateTime Birthday { get; set; }
        public int Agefrom { get; set; }
        public int Ageto { get; set; }
        public int RosterId { get; set; }
    }
    public class ActorViaMasterClientDTO
    {
        public string ClientName { get; set; }
        public string Client_Firstname { get; set; }
        public string Client_Middlename { get; set; }
        public string Client_Lastname { get; set; }
        public int Client_Gender { get; set; }
        public int Client_Heightfeet { get; set; }
        public int Client_Heightinches { get; set; }
        public int Client_Weight { get; set; }
        public DateTime Client_Birthday { get; set; }
    }
    public class ActorContactViaMasterDTO
    {
        public int AgentId { get; set; }
        public string Actor_FirstName { get; set; }
        public string Actor_LastName { get; set; }
        public string Actor_Company { get; set; }
        public string Actor_Phone { get; set; }
        public bool Actor_IsHidden { get; set; }
        public string Actor_Email { get; set; }
        public string Actor_Address { get; set; }
        public string Actor_Website { get; set; }
    }
    public class ActorImageViaMasterDTO
    {
        public int Client_ID { get; set; }
        public string Image { get; set; }
        public int PhotoNum { get; set; }
        public int File_Size { get; set; }
    }
    public class ImageViaMasterDTO
    {
        public string Image { get; set; }
        public string ImageUrl { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorReportDTO
    {

        public List<ActorCardDTO>  ActorCard { get; set; }
        public List<ActorCardKnowsForDTO>  ActorCardKnows { get; set; }
        public List<ActorCardContactsDTO> ActorContacts { get; set; }
        public List<ActorCardEthnicityDTO>  CastingListEthnicities { get; set; }
        public List<ActroRoleDTO>   ActorRoles { get; set; }
        public ActorReportDTO()
        {
            this.ActorCardKnows = new List<ActorCardKnowsForDTO>();
            this.ActorContacts = new List<ActorCardContactsDTO>();
            this.CastingListEthnicities = new List<ActorCardEthnicityDTO>();
            this.ActorCard = new List<ActorCardDTO>();
            this.ActorRoles = new List<ActroRoleDTO>();
        }
    }
}

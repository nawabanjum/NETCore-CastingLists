﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
  public  class ServiceResponse
    {
        public string ServiceResponseMessage { get; set; } = "Success";
        public bool IsError { get; set; }

        public object Id { get; set; }
    }
}

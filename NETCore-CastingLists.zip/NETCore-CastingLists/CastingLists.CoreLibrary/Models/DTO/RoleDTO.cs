﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class RoleDTO
    {
        public int RoleId { get; set; }
        //[JsonPropertyName("ProjectId")]
        public int ProjectRId { get; set; }
        public bool IsActive { get; set; }
        public int SortOrder { get; set; }
        [Required]
        [MaxLength(70)]
        public string RoleTitle { get; set; }
        [MaxLength(150)]
        public string RoleDesc { get; set; }
        [JsonIgnore]
        public int ModifiedBy { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime ModifiedOn { get; set; }
    }
}

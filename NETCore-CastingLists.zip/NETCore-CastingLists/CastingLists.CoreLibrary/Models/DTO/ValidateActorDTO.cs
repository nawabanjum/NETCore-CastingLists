﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class ValidateActorDTO
    {
        public string ImdbActorId { get; set; }
        public int ActorId { get; set; }
        public int ProjectrId { get; set; }
        public int RolerId { get; set; }
        public int ListrId { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
    }
}

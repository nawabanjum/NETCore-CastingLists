﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorImdbImagesDTO
    {
        public int Id { get; set; }
        public int ActorRId { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        public string ImageSourceUrl { get; set; }
        public string ImageType { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
    }
    public class ActorImdbImagesListDTO
    {
        public int Id { get; set; }
        public int ActorRId { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        public string ImageSourceUrl { get; set; }
        public string ImageTarget { get; set; }
        public string ImageType { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class CommonLookUpDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
    public class CommonLookUpNodeDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
    public class CommonLookUpChildNodeDTO
    {
        public int ProjectId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int TotalCount { get; set; }

        public List<CommonLookUpChildNodeRoleDTO> Roles { get; set; }
        public CommonLookUpChildNodeDTO()
        {
            this.Roles = new List<CommonLookUpChildNodeRoleDTO>();
        }

    }
    public class CommonLookUpChildNodeRoleDTO
    {
        public int ProjectId { get; set; }
        public int Id { get; set; }
        public int TotalCount { get; set; }
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

    }
}

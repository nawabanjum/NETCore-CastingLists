﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
  public  class ClientDTO
    {
        public int RosterId { get; set; }
        public int ClientrId { get; set; }
        public int Status { get; set; }
        public int AgentrId { get; set; }
        public int DefPhotoum { get; set; }
        public int RosterType { get; set; }
        public int SubType { get; set; }
        public int ActorSubType { get; set; }
        public string Photonums { get; set; }
        public string Code { get; set; }
        public string AgentName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public bool IsFreemium { get; set; }
        public int Gender { get; set; }
        public int Clone_Source_Id { get; set; }
        public string PictureUrl { get; set; }
        public string AgeRange { get; set; }
        public string Height { get; set; }
        public string CompanyName { get; set; }
        public string AgentFirstName { get; set; }
        public string AgentLastName { get; set; }
        public int OriginalAgencyRId { get; set; }
        public int OriginalAgentRId { get; set; }

    }

    public class ClientUpdatedDTO
    {
        public int RosterId { get; set; }
        public int ClientrId { get; set; }
        public int Status { get; set; }
        public int AgentrId { get; set; }
        public int DefPhotoum { get; set; }
        public int RosterType { get; set; }
        public int SubType { get; set; }
        public int ActorSubType { get; set; }
        public string Photonums { get; set; }
        public string Code { get; set; }
        public string AgentName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public bool IsFreemium { get; set; }
        public int Gender { get; set; }
        public int Clone_Source_Id { get; set; }
        public string PictureUrl { get; set; }
        public string AgeRange { get; set; }
        public string AgeFrom { get; set; }
        public string AgeTo { get; set; }
        public string HeightFeet { get; set; }
        public string HeightInches { get; set; }
        public DateTime BirthDay { get; set; }
        public string AgentFirstName { get; set; }
        public string AgentLastName { get; set; }
        public int OriginalAgencyRId { get; set; }
        public int OriginalAgentRId { get; set; }
        public string CompanyName { get; set; }

    }
}

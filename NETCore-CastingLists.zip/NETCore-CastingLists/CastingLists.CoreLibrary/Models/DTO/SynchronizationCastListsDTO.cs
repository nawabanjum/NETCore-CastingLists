﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class SynchronizationCastListsDTO
    {
		public int Id { get; set; }
		public int ListRId { get; set; }
		public int RoleRId { get; set; }
		public int ProjectRId { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public int CreatedByUserId { get; set; }
		[JsonIgnore]
		public int CreatedByUserType { get; set; }
		[MaxLength(256)]
		public string EventType { get; set; }
		public bool IsSuccess { get; set; }
		public bool IsError { get; set; }
		[MaxLength(256)]
		public string Details { get; set; }
		public int NumberOfRecords { get; set; }
		public int QtyProcessed { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class KnowsForDTO
    {
        public int KnowsId { get; set; }
        [Required]
        [MaxLength(256)]
        public string Title { get; set; }
        public string ImdbId { get; set; }
        public string Link { get; set; }
        public int StartYear { get; set; }
        public int EndYear { get; set; }
        public string FullDescription { get; set; }
        public int ActorId { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
        public bool IsDeleted { get; set; }
    }
}

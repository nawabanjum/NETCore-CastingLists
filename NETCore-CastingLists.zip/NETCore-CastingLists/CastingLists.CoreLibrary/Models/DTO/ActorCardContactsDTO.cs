﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
  public  class ActorCardContactsDTO
    {
		public int ActrorCard_ContactsId { get; set; }
		[MaxLength(250)]
		public string ContactType { get; set; }
		[MaxLength(250)]
		public string ContactName { get; set; }
		[MaxLength(250)]
		public string ContactCompany { get; set; }
		[MaxLength(250)]
		public string ContactEmail { get; set; }
		[MaxLength(50)]
		public string ContactPhone { get; set; }
		public int ActorCardRId { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public DateTime LastUpdatedDate { get; set; }
		public bool IsHidden { get; set; }
		public int SortOrder { get; set; }
		public int? OriginalImdbContactRId { get; set; }
	}
}

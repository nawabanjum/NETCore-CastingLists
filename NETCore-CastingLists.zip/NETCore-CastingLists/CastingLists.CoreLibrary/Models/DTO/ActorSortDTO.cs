﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorSortDTO
    {
        public int Id { get; set; }
        public int SortOrder { get; set; }
    }
    public class ActorStatusDTO
    {
        public int Id { get; set; }
        public bool IsHidden { get; set; }
    }
}

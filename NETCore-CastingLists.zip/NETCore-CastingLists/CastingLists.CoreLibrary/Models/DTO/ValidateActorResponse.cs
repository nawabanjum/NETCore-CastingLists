﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ValidateActorResponse
    {
        public bool AlreadyExists { get; set; }
        public bool TalentMatchingFound { get; set; }
        public bool IsValid { get; set; }
        public IEnumerable<ClientDTO> Duplicates { get; set; }
        public ValidateActorResponse()
        {
            this.Duplicates = new List<ClientDTO>();
        }
    }
    public class ValidateDuplicate
    {
        public int RosterId { get; set; }
        public int ClientrId { get; set; }
        public int Status { get; set; }
        public int AgentrId { get; set; }
        public int DefPhotoum { get; set; }
        public int RosterType { get; set; }
        public int SubType { get; set; }
        public int ActorSubType { get; set; }
        public int ModelSubType { get; set; }
        public int ProductionSubType { get; set; }
        public string Photonums { get; set; }
        public string Code { get; set; }
        public string AgentName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public bool IsFreemium { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class SocialLinkDTO
    {
        public int LinkId { get; set; }
        [Required]
        [MaxLength(256)]
        public string Title { get; set; }
        [MaxLength(256)]
        public string Link { get; set; }
        //[JsonPropertyName("ActorId")]
        public int ActorRId { get; set; }
        [JsonIgnore]
        public bool IsDeleted { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class JobDTO
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string JobTitle { get; set; }
        [MaxLength(50)]
        public string AltTitle { get; set; }
        public int? AgencyID { get; set; }
        public bool IsProjectDirector { get; set; }
    }
}

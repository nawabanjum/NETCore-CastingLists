﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorPrivateNotesDTO
    {
        public int Id { get; set; }
        [JsonPropertyName("ActorId")]
        public int ActorId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [Required]
        [MaxLength(256)]
        public string Note { get; set; }
    }
}

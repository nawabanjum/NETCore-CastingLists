﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class GenderTypeDTO
    {
		public int gendertypeID { get; set; }
		public string gendertype { get; set; }
		public short displayorder { get; set; }
		public string gendertype_1 { get; set; }
		public string gendertype_2 { get; set; }
		public string gendertype_99 { get; set; }
		public string TranslationKey { get; set; }
		public string gendertype_3 { get; set; }
	}
}

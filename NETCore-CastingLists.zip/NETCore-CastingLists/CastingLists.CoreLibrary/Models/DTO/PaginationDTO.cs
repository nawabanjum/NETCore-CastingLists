﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class PaginationDTO
    {

        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public int TotalNumber { get; set; }

        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }

    }
    public class GlobalSearch : PaginationDTO
    {
        public string SearchKey { get; set; }

    }
    public class ParamListDTO
    {
        public int ProjectId { get; set; }
    }
    public class ParamActorDTO
    {
        public int ActorId { get; set; }
    }
    public class ParamCastingActorDTO
    {
        public int ActorCardId { get; set; }
    }
    public class ParamImdbActorDTO
    {
        public int ImdbActorId { get; set; }
    }
    public class GlobalSearchActor
    {
        public string ActorName { get; set; }
    }
    public class GlobalSearchClient
    {
        public string Clientname { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }

    }
    public class GlobalSearchImdb
    {
        public string Imdb { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
    }
    public class GlobalSearchActorImdb
    {
        public int ListId { get; set; }
        public bool IsGenender { get; set; }
        public bool IsHeight { get; set; }
        public bool IsContact { get; set; }
        public bool IsKnowsFor { get; set; }
        public bool IsPlayage { get; set; }
        public bool IsNotes { get; set; }
        public bool IsEthnicity { get; set; }
        public List<ActorRoles> ActorRoles { get; set; }
        public GlobalSearchActorImdb()
        {
            this.ActorRoles = new List<ActorRoles>();
        }
    }
    public class ParamActorImdbSearchDTO
    {
        public int RoleRId { get; set; }
        public int ProjectRId { get; set; }
        public int ListRId { get; set; }
        public int? ClientRId { get; set; }
        public int? RosterRId { get; set; }
        public int CastingList_IMDBActorId { get; set; }
        
    }
    public class ParamActorMasterCastSearchDTO
    {
        public int RoleRId { get; set; }
        public int ProjectRId { get; set; }
        public int ListRId { get; set; }
        public int ClientRId { get; set; }
        public int RosterRId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
    }
    public class ActorRoles
    {
        [Required]
        public int  RoleId { get; set; }
    }
    
}

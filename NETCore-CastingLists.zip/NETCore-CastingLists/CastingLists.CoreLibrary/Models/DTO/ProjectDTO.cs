﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class ProjectDTO
    {
        public int ProjectId { get; set; }
        [Required]
        [MaxLength(100)]
        public string ProjectTitle { get; set; }
        [MaxLength(100)]
        public string StudioName { get; set; }
        public bool IsActive { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime ModifiedOn { get; set; }
        public int AgencyId { get; set; }
        public int SortOrder { get; set; }
        //[JsonPropertyName("ProjectListTypeId")]
        public int ProjectListTypeRId { get; set; }
        //[JsonPropertyName("ProjectListSourceId")]
        public int ProjectListSourceRId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ListDTO
    {
        public int ListId { get; set; }
        public int? ParentListId { get; set; }
        [Required]
        [MaxLength(500)]
        public string ListName { get; set; }
        
        public int ProjectId { get; set; }
        public bool IsActive { get; set; }
        [JsonIgnore]
        public int CreatedByUserId { get; set; }
        [JsonIgnore]
        public int CreatedByUserType { get; set; }
        [JsonIgnore]
        public DateTime? CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime ModifiedOn { get; set; }
        public int SortOrder { get; set; }
    }
}

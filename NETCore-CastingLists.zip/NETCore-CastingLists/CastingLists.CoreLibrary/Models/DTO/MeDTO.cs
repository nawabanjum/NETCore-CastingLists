﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
  public  class MeDTO
    {
        public string Login { get; set; }
        public string WebSessionKey { get; set; }
        public string UserId { get; set; }
        public string UserType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SellerId { get; set; }
        public string AgencyId { get; set; }
        public int exp { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class EthnicitiesDTO
    {
        public int code { get; set; }
        public string description { get; set; }
        public int displayorder { get; set; }
        public string description_1 { get; set; }
        public string description_3 { get; set; }
        public string description_2 { get; set; }
        public string description_99 { get; set; }
        public byte serial { get; set; }
        
    }
}

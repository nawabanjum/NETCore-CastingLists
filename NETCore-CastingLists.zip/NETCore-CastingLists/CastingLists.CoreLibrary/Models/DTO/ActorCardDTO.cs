﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorCardDTO
    {
		public int Id { get; set; }
		[Required]
		[MaxLength(250)]
		public string DisplayName { get; set; }
		public int RoleRId { get; set; }
		public int ProjectRId { get; set; }
		public int ListRId { get; set; }
		[MaxLength(1024)]
		public string Notes { get; set; }
		public DateTime BOD { get; set; }
		
		public string ImdbId { get; set; }
		public string AgeRange { get; set; }
		public int GenderRId { get; set; }
		public int HeightFeet { get; set; }
		public int HeightInches { get; set; }
		public int MasterCast_ClientId { get; set; }
		public int MasterCast_RosterId { get; set; }
		public int CastingList_IMDBActorId { get; set; }
		[JsonIgnore]
		public int CreatedByUserId { get; set; }
		[JsonIgnore]
		public int CreatedByUserType { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public DateTime LastUpdatedDate { get; set; }
		public decimal? RankStarMeeter { get; set; }
		public bool IsHidden { get; set; }
		public int SortOrder { get; set; }
		public List<ActorCardContactsDTO> ActorContacts { get; set; }
		public List<ActorCardPrivateNoteDTO> PrivateNotes { get; set; }
		public List<ActorCardKnowsForDTO> KnowsFors { get; set; }
		public List<ActorCardVideoDTO> ActorVideos { get; set; }
		public List<ActorCardImagesDTO>  ActorCardImages { get; set; }
		public List<ActorCardLinksDTO> ActorCardLinks { get; set; }
		public List<ActorCardEthnicityDTO>  ActorCardEthnicities { get; set; }
		public ActorCardDTO()
		{
			this.PrivateNotes = new List<ActorCardPrivateNoteDTO>();
			this.KnowsFors = new List<ActorCardKnowsForDTO>();
			this.ActorContacts = new List<ActorCardContactsDTO>();
			this.ActorVideos = new List<ActorCardVideoDTO>();
			this.ActorCardImages = new List<ActorCardImagesDTO>();
			this.ActorCardLinks = new List<ActorCardLinksDTO>();
			this.ActorCardEthnicities = new List<ActorCardEthnicityDTO>();
		}
	}
	public class CastingListActorUpdateDTO
    {
		public int Id { get; set; }
		[Required]
		[MaxLength(250)]
		public string DisplayName { get; set; }
		public int RoleRId { get; set; }
		public int ProjectRId { get; set; }
		public int ListRId { get; set; }
		[MaxLength(1024)]
		public string Notes { get; set; }
		public DateTime BOD { get; set; }

		public string AgeRange { get; set; }
		public int GenderRId { get; set; }
		public int HeightFeet { get; set; }
		public int HeightInches { get; set; }
		public int MasterCast_ClientId { get; set; }
		public int MasterCast_RosterId { get; set; }
		public int CastingList_IMDBActorId { get; set; }
		[JsonIgnore]
		public int CreatedByUserId { get; set; }
		[JsonIgnore]
		public int CreatedByUserType { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public DateTime LastUpdatedDate { get; set; }
		public bool IsHidden { get; set; }
		public int SortOrder { get; set; }

	}
	public class ActorCardSimplifiedDTO
	{
		public int Id { get; set; }
		[Required]
		[MaxLength(250)]
		public string DisplayName { get; set; }
		public int RoleRId { get; set; }
		public int ProjectRId { get; set; }
		public int ListRId { get; set; }
		[MaxLength(1024)]
		public string Notes { get; set; }
		public DateTime BOD { get; set; }
		public string ImdbId { get; set; }
		public string AgeRange { get; set; }
		public int GenderRId { get; set; }
		public int HeightFeet { get; set; }
		public int HeightInches { get; set; }
		public int MasterCast_ClientId { get; set; }
		public int MasterCast_RosterId { get; set; }
		public int CastingList_IMDBActorId { get; set; }
		[JsonIgnore]
		public int CreatedByUserId { get; set; }
		[JsonIgnore]
		public int CreatedByUserType { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public DateTime LastUpdatedDate { get; set; }
		public bool IsHidden { get; set; }
		public int SortOrder { get; set; }
		public decimal? RankStarMeeter { get; set; }

	}
}

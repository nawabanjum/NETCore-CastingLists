﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorCardPrivateNoteDTO
    {
        public int ActorCard_PrivateNoteId { get; set; }
        [Required]
        [MaxLength(250)]
        public string Notes { get; set; }
        public int ActorCardRId { get; set; }
        [JsonIgnore]
        public DateTime CreatedOn { get; set; }
        [JsonIgnore]
        public DateTime LastUpdatedDate { get; set; }
        public bool IsHidden { get; set; }
        public int SortOrder { get; set; }
    }
}

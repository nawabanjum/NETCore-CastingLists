﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class FilmographyDTO
    {
		public int FilmographyId { get; set; }
		[Required]
		[MaxLength(256)]
		public string Title { get; set; }
		[MaxLength(256)]
		public string Link { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		[JsonIgnore]
		public DateTime LastUpdatedDate { get; set; }
		public bool IsDeleted { get; set; }
		public string StartYear { get; set; }
		public string EndYear { get; set; }
		public string FullDescription { get; set; }
		public string ImdbId { get; set; }
		public int ActorRId { get; set; }
	}
}

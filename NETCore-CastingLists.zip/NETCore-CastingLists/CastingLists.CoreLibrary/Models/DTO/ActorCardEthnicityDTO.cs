﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorCardEthnicityDTO
    {
		public int ActorCard_EthnicityId { get; set; }
		public int? EthnicityRId { get; set; }
		public int ActorCardRId { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		public bool IsHidden { get; set; }
		public int SortOrder { get; set; }
	}
}

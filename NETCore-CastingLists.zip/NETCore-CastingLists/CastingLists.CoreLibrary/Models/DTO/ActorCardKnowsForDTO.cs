﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
    public class ActorCardKnowsForDTO
    {
		public int ActorCard_KnowsForId { get; set; }
		[Required]
		[MaxLength(250)]
		public string Title { get; set; }
		[MaxLength(250)]
		public string Link { get; set; }
		public int SortOrder { get; set; }
		public int ActorCardRId { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		public bool IsHidden { get; set; }
		[JsonIgnore]
		public DateTime ModifiedOn { get; set; }
		public int? OriginalImdbKnowsForRId { get; set; }
	}
}

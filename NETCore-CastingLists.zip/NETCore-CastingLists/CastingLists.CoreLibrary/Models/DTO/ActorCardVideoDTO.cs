﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.DTO
{
   public class ActorCardVideoDTO
    {
		public int ActorCard_VideoId { get; set; }
		public int? MediaRId { get; set; }
		public bool IsAudio { get; set; }
		public bool IsStudio { get; set; }
		public bool IsHidden { get; set; }
		public int ActorCardRId { get; set; }
		[JsonIgnore]
		public DateTime CreatedOn { get; set; }
		public int SortOrder { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
	[Table("tblSynchronizationImdbActors")]
    public partial class tblSynchronizationImdbActors
    {
		[Key]
		public int Id { get; set; }
		public int ActorRId { get; set; }
		public int SyncCastListRId { get; set; }
		public string ImdbId { get; set; }
		public int ListRId { get; set; }
		public int RoleRId { get; set; }
		public int ProjectRId { get; set; }
		public DateTime CreatedOn { get; set; }
		public int CreatedByUserId { get; set; }
		public int CreatedByUserType { get; set; }
		public string EventType { get; set; }
		public bool IsSuccess { get; set; }
		public bool IsError { get; set; }
		public string Details { get; set; }
		[ForeignKey("ProjectRId")]
		public tblProjectList tblProjectList { get; set; }
		[ForeignKey("RoleRId")]
		public tblRoles tblRoles { get; set; }
		[ForeignKey("ListRId")]
		public tblList tblList { get; set; }
		[ForeignKey("ActorRId")]
		public tblActorImdb tblActorImdb { get; set; }
		[ForeignKey("SyncCastListRId")]
		public tblSynchronizationCastLists  tblSynchronizationCastLists { get; set; }
    }
}

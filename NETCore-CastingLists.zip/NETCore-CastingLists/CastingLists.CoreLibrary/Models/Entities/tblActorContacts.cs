﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblActorContacts")]
    public class tblActorContacts
    {
        [Key]
		public int ContactId { get; set; }
		public string ContactType { get; set; }
		public string ContactGroup { get; set; }
		public string ContactName { get; set; }
		public string ContactCompany { get; set; }
		public string ContactCompanyImdb { get; set; }
		public string ContactCompanyWebSite { get; set; }
		public string ContactCompanyPhone { get; set; }
		public string ContactCompanyEmail { get; set; }
		public string ContactCompanyAddress { get; set; }
		public string ContactPhone { get; set; }
		public string ContactCountry { get; set; }
		public string ContactImdbLink { get; set; }
		public string ContactWebSite { get; set; }
		public string ContactEmail { get; set; }
		public int ActorRId { get; set; }
		public DateTime CreatedOn { get; set; }
		public DateTime LastUpdatedDate { get; set; }
		public bool IsDeleted { get; set; }

		[ForeignKey("ActorRId")]
        public tblActorImdb tblActorImdb { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblList")]
    public partial class tblList 
    {
        [Key]
        public int ListId { get; set; }
        public string ListName { get; set; }
        public bool IsActive { get; set; }
        public DateTime ModifiedOn { get; set; }
        public int SortOrder { get; set; }
        public int CreatedByUserId { get; set; }
        public int CreatedByUserType { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int ProjectRId { get; set; }
        [ForeignKey("ProjectRId")]
        public tblProjectList tblProjectList { get; set; }
        
        //[ForeignKey("TblList")]
        public int? ParentListId { get; set; }
        public virtual ICollection<tblActorCard> TblCastingListActors { get; set; }



    }
}

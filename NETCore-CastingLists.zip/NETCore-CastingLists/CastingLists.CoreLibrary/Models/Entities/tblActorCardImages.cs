﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblActorCardImages")]
    public class tblActorCardImages
    {
        [Key]
        public int Id { get; set; }
        public bool IsDefault { get; set; }
        public string PicturePath { get; set; }
        public int ActorCardRId { get; set; }
        [ForeignKey("ActorCardRId")]
        public tblActorCard  tblActorCard { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblActorPriveNotes")]
    public partial class tblActorPriveNotes
    {
        [Key]
        public int Id { get; set; }
        public int ActorRId { get; set; }
        public int CreatedByUserType { get; set; }
        public int CreatedByUserId { get; set; }
        public string Note { get; set; }
        [ForeignKey("ActorRId")]
        public tblActorImdb tblActorImdb { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("lstProjectListType")]
    public class lstProjectListType
    {
        [Key]
        public int TypeId { get; set; }
        public string TypeTitle { get; set; }
        public DateTime CreatedOn { get; set; }
        public int SortOrder { get; set; }

    }
}

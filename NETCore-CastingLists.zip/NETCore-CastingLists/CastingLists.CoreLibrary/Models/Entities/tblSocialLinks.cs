﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblSocialLinks")]
    public partial class tblSocialLinks
    {
        [Key]
        public int LinkId { get; set; }
        public string Title { get; set; }
        public string Link { get; set; }
        public int ActorRId { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedDate { get; set; }

        [ForeignKey("ActorRId")]
        public tblActorImdb  tblActorImdb { get; set; }
    }
}

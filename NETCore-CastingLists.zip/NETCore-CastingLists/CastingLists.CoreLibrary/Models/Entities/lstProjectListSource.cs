﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("lstProjectListSource")]
    public class lstProjectListSource
    {
        [Key]
        public int SourceId { get; set; }
        public string SourceTitle { get; set; }
        public DateTime CreatedOn { get; set; }
        public int SortOrder { get; set; }
    }
}

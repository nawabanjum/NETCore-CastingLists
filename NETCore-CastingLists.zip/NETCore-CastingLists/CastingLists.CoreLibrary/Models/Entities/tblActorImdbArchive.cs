﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblActorImdbArchive")]
    public partial class tblActorImdbArchive
    {
        [Key]
        public int Id { get; set; }
        public int ActorRId { get; set; }
        public int CreatedByUserId { get; set; }
        public int CreatedByUserType { get; set; }
        public string ImdbId { get; set; }
        public string Json { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblKnowsFor")]
    public class tblKnowsFor
    {
        [Key]
        public int KnowsId { get; set; }
        public string ImdbId { get; set; }

        public string Title { get; set; }
        public string Link { get; set; }
        public int StartYear { get; set; }
        public int EndYear { get; set; }
        public string FullDescription { get; set; }
        public int ActorRId { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public bool IsDeleted { get; set; }
        [ForeignKey("ActorRId")]
        public tblActorImdb tblActorImdb { get; set; }
    }
}

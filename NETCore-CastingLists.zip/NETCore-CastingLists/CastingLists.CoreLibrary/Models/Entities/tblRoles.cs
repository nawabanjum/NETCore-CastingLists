﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblRoles")]
    public partial class tblRoles : CommonEntity
    {
        [Key]
        public int RoleId { get; set; }
    
        public int ProjectRId { get; set; }
        public int SortOrder { get; set; }
        public bool IsActive { get; set; }
        public string RoleTitle { get; set; }
        public string RoleDesc { get; set; }
        public int ModifiedBy { get; set; }
        
        public DateTime ModifiedOn { get; set; }
        [ForeignKey("ProjectRId")]
        public tblProjectList tblProjectList { get; set; }
        public virtual ICollection<tblActorCard> TblCastingListActors { get; set; }

    }
}

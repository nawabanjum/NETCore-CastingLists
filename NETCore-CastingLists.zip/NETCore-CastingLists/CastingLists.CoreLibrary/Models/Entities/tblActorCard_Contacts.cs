﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
	[Table("tblActorCard_Contacts")]
	public partial class tblActorCard_Contacts
    {
		[Key]
		public int ActrorCard_ContactsId { get; set; }
		public string ContactType { get; set; }
		public string ContactName { get; set; }
		public string ContactCompany { get; set; }
		public string ContactEmail { get; set; }
		public string ContactPhone { get; set; }
		public int ActorCardRId { get; set; }
		public DateTime CreatedOn { get; set; }
		public DateTime LastUpdatedDate { get; set; }
		public bool IsHidden { get; set; }
		public int SortOrder { get; set; }
		public int? OriginalImdbContactRId { get; set; }

		
		[ForeignKey("ActorCardRId")]
		public tblActorCard  tblActorCard { get; set; }
	}
}

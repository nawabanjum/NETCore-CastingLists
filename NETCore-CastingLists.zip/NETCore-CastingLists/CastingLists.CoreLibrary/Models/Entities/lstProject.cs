﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblProjectList")]
    public partial class tblProjectList : CommonEntity
    {
        [Key]
        public int ProjectId { get; set; }
        [Required]
        public string ProjectTitle { get; set; }
        public string StudioName { get; set; }
        public bool IsActive { get; set; }        
        public DateTime ModifiedOn { get; set; }
        public int AgencyId { get; set; }
        public int SortOrder { get; set; }
        public int ProjectListTypeRId { get; set; }
        public int ProjectListSourceRId { get; set; }
       
        public virtual ICollection<tblList> tblLists { get; set; }
        public virtual ICollection<tblRoles> TblRoles { get; set; }
        public virtual ICollection<tblActorCard> TblActorCards { get; set; }

    }
}

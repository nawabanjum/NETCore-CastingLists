﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
	[Table("tblActorCardExports")]
    public partial class tblActorCardExports
    {
		[Key]
		public int Id { get; set; }
		public int ListId { get; set; }
		public string Title { get; set; }
		public DateTime CreatedOn { get; set; }
		public int CreatedByUserId { get; set; }
		public int CreatedByUserType { get; set; }
		public string JsonData { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblActorImdb")]
    public partial class tblActorImdb
    {
        [Key]
        public int ActorId { get; set; }
        public string ImdbId { get; set; }
        public decimal? RanKStarMeeter { get; set; }
        
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PicturePath { get; set; }
        public string ImageSourceUrl { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string AgeRange { get; set; }
        public string Gender { get; set; }
        public string Height { get; set; }
        public string Weigth { get; set; }
        public string Ethnicity { get; set; }
        public string Ranking { get; set; }
        public DateTime CreatedOn { get; set; }
        public string OriginalPlatform { get; set; }
        public DateTime LastUpdatedPlatform { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        public int CreatedByUserId { get; set; }
        public int CreatedByUserType { get; set; }
        public bool IsDeleted { get; set; }
        public virtual ICollection<tblSocialLinks> TblSocials { get; set; }
        public virtual ICollection<tblActorContacts>  TblActorContacts { get; set; }
        public virtual ICollection<tblKnowsFor>  TblKnowsFors { get; set; }
        public virtual ICollection<tblActorPriveNotes>  TblActorPrivateNotes { get; set; }
        public virtual ICollection<tblFilmographyImdb>   TblFilmographyImdbs { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
  public class CommonEntity
    {
        public int CreatedByUserId { get; set; }
        public int CreatedByUserType { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblActorImdbImages")]
    public partial class tblActorImdbImages
    {
        [Key]
        public int Id { get; set; }
        public int ActorRId { get; set; }
        public int CreatedByUserId { get; set; }
        public int CreatedByUserType { get; set; }
        public string ImageSourceUrl { get; set; }
        public string ImageType { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedDate { get; set; }
        [ForeignKey("ActorRId")]
        public tblActorImdb tblActorImdb { get; set; }
    }
}

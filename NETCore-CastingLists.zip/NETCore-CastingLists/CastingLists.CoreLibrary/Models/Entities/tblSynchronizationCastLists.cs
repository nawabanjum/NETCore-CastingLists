﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
	[Table("tblSynchronizationCastLists")]
    public partial class tblSynchronizationCastLists
    {
		[Key]
		public int Id { get; set; }
		public int ListRId { get; set; }
		public int RoleRId { get; set; }
		public int ProjectRId { get; set; }
		public DateTime CreatedOn { get; set; }
		public int CreatedByUserId { get; set; }
		public int CreatedByUserType { get; set; }
		public string EventType { get; set; }
		public bool IsSuccess { get; set; }
		public bool IsError { get; set; }
		public string Details { get; set; }
		public int NumberOfRecords { get; set; }
		public int QtyProcessed { get; set; }
		[ForeignKey("ProjectRId")]
		public tblProjectList tblProjectList { get; set; }
		[ForeignKey("RoleRId")]
		public tblRoles tblRoles { get; set; }
		[ForeignKey("ListRId")]
		public tblList tblList { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
	[Table("tblActorCard")]
    public partial class tblActorCard
	{
		[Key]
        public int Id { get; set; }
        public string DisplayName { get; set; }
	
		public int RoleRId { get; set; }
		[ForeignKey("RoleRId")]
		public tblRoles  tblRoles { get; set; }
		public int ListRId { get; set; }
		[ForeignKey("ListRId")]
		public tblList tblList { get; set; }
	
		public int ProjectRId { get; set; }
		[ForeignKey("ProjectRId")]
		public tblProjectList tblProjectList { get; set; }

		public string Notes { get; set; }
		public DateTime BOD { get; set; }
		public string AgeRange { get; set; }
		public int GenderRId { get; set; }
		public int HeightFeet { get; set; }
		public int HeightInches { get; set; }
		public int MasterCast_ClientId { get; set; }
		public int MasterCast_RosterId { get; set; }
		public int CastingList_IMDBActorId { get; set; }
		public int CreatedByUserId { get; set; }
		public int CreatedByUserType { get; set; }
		public int SortOrder { get; set; }
		public DateTime CreatedOn { get; set; }
		public DateTime LastUpdatedDate { get; set; }
		public bool IsHidden { get; set; }
		public virtual ICollection<tblActorCardVideos>  TblCastingListActorVideos { get; set; }
		public virtual ICollection<tblActorCard_Contacts>  TblActorCard_Contacts { get; set; }
		public virtual ICollection<tblActorCard_PrivateNote>  TblCastingListActor_PrivateNotes { get; set; }
		public virtual ICollection<tblActorCard_KnowsFor> TblActorCard_KnowsFor { get; set; }
		public virtual ICollection<tblActorCardLinks>    TblActorCardLinks { get; set; }
		public virtual ICollection<tblActorCardImages>  TblActorCardImages { get; set; }
		public virtual ICollection<tblActorCardEthnicity>   TblActorCardEthnicities { get; set; }
	}
}

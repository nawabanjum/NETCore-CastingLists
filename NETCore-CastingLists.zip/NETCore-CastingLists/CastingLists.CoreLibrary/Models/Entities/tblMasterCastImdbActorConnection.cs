﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
    [Table("tblMasterCastImdbActorConnection")]
    public  class tblMasterCastImdbActorConnection
    {
		[Key]
		public int Id { get; set; }
		public int RoleRId { get; set; }
		public int projectRId { get; set; }
		public int ListRId { get; set; }
		public int ClientRId { get; set; }
		public int RosterId { get; set; }
		public int CreatedByUserId { get; set; }
		public int CreatedByUserType { get; set; }
		public int ImdbActorRId { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
   
   
    [Table("lstJob")]
   
    public partial class lstJob
    {
        [Column("IPK")]
        [Key]
        public int Id { get; set; }

        [Column("cJobTitle")]
        public string JobTitle { get; set; }
        [Column("cAltTitle")]
        public string AltTitle { get; set; }       

        public int? AgencyID { get; set; }
        public bool IsProjectDirector { get; set; }

        

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models.Entities
{
	[Table("tblActorCard_KnowsFor")]
   public partial class tblActorCard_KnowsFor
	{
		[Key]
		public int ActorCard_KnowsForId { get; set; }
		public string Title { get; set; }
		public string Link { get; set; }
		public int SortOrder { get; set; }
		public int ActorCardRId { get; set; }
		public DateTime CreatedOn { get; set; }
		public bool IsHidden { get; set; }
		public DateTime ModifiedOn { get; set; }
		public int? OriginalImdbKnowsForRId { get; set; }
		[ForeignKey("ActorCardRId")]
		public tblActorCard tblActorCard { get; set; }
	}
}

﻿using CastingLists.CoreLibrary.Models.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models
{
    public partial class ProjectManContext : DbContext
    {
        public virtual DbSet<lstJob> lstJob { get; set; }
        public virtual DbSet<tblProjectList> lstProject { get; set; }
        public virtual DbSet<tblList> tblList { get; set; }
        public virtual DbSet<lstProjectListSource> LstProjectListSources { get; set; }
        public virtual DbSet<lstProjectListType> LstProjectListTypes { get; set; }
        public virtual DbSet<tblRoles> TblRoles { get; set; }
        public virtual DbSet<tblActorImdb> TblActorImdbs { get; set; }
        public virtual DbSet<tblSocialLinks> TblSocials { get; set; }
        public virtual DbSet<tblActorContacts> TblActorContacts { get; set; }
        public virtual DbSet<tblKnowsFor> TblKnowsFors { get; set; }
        public virtual DbSet<tblActorPriveNotes> TblActorPriveNotes { get; set; }
        public virtual DbSet<tblActorImdbArchive> TblActorImdbArchives { get; set; }
        public virtual DbSet<tblActorCard> TblActorCards { get; set; }
        public virtual DbSet<tblActorCardVideos> TblCastingListActorVideos { get; set; }
        public virtual DbSet<tblActorCard_Contacts> TblActorCard_Contacts { get; set; }
        public virtual DbSet<tblActorCard_KnowsFor> TblActorCard_KnowsFor { get; set; }
        public virtual DbSet<tblActorCard_PrivateNote> TblActorCard_PrivateNotes { get; set; }
        public virtual DbSet<tblActorCardEthnicity> TblCastingListEthnicities { get; set; }
        public virtual DbSet<tblFilmographyImdb> TblFilmographyImdbs { get; set; }
        public virtual DbSet<tblActorCardExports> TblCastListReportExports { get; set; }
        public virtual DbSet<tblActorCardImages> TblActorCardImages { get; set; }
        public virtual DbSet<tblActorCardLinks> TblActorCardLinks { get; set; }
        public virtual DbSet<tblMasterCastImdbActorConnection> TblMasterCastImdbActorConnections { get; set; }
        public virtual DbSet<tblSynchronizationCastLists>  TblSynchronizationCastLists { get; set; }
        public virtual DbSet<tblSynchronizationImdbActors>   TblSynchronizationImdbActors { get; set; }
        public virtual DbSet<tblActorImdbImages>    TblActorImdbImages { get; set; }
        public ProjectManContext(DbContextOptions<ProjectManContext> options) : base(options)
        {
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


            //modelBuilder.Entity<tblProjectList>(entity =>
            //{
            //    entity.Property(e => e.ProjectId);
            //    entity.Property(e => e.ProjectTitle)
            //        .HasMaxLength(100)
            //        .IsUnicode(false);
            //    entity.Property(e => e.StudioName)
            //        .HasMaxLength(100)
            //        .IsUnicode(false);
            //    entity.Property(e => e.IsActive);
            //    entity.Property(e => e.CreatedByUserId);
            //    entity.Property(e => e.CreatedByUserType);
            //    entity.Property(e => e.CreatedOn);
            //    entity.Property(e => e.ModifiedOn);
            //    entity.Property(e => e.AgencyId);
            //    entity.Property(e => e.SortOrder);
            //    entity.Property(e => e.ProjectListSourceRId);
            //    entity.Property(e => e.ProjectListTypeRId);
            //});
            modelBuilder.Entity<tblProjectList>();
            modelBuilder.Entity<lstJob>();
            base.OnModelCreating(modelBuilder);
        }

    }
}

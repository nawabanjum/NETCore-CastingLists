﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using ImageMagick;
using log4net.Repository.Hierarchy;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Models
{
    public class CommonOperations
    {

        public async Task<ServiceResponse> UploadImageImdb(string imageurl, UploadSettings _env, HttpClient httpClient, string[] Extensions)
        {
            string result = string.Empty;
            ServiceResponse response = new ServiceResponse();
            try
            {
                byte[] data = null;
                if (string.IsNullOrEmpty(imageurl))
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.CheckImage;
                    return response;
                }
                using (var reslt = await httpClient.GetAsync(imageurl))
                {
                    if (reslt.IsSuccessStatusCode)
                    {
                        data = await reslt.Content.ReadAsByteArrayAsync();
                    }
                }
                var splitFolder = _env.ImdbSaveUrlLocation.Split(new[] { '/' });
                string folder = splitFolder[1];
                //suppose you are checking you ext
                //Get FileName from coming Image Path
                var fileName = Path.GetFileName(imageurl.Replace("/", "\\"));
                string ext = Path.GetExtension(fileName);
                if (Extensions.Contains(ext))
                {
                    var webRoot = _env.ImdbSaveFolderLocation;
                    var PathWithFolderName = System.IO.Path.Combine(webRoot, folder);

                    if (!Directory.Exists(PathWithFolderName))
                    {
                        // Try to create the directory.
                        DirectoryInfo di = Directory.CreateDirectory(PathWithFolderName);
                    }

                    var updatedFileName = DateTime.Now.ToString("yyyyMM") + fileName;
                    //Get File with directory

                    var imagePath = $"{ _env.ImdbSaveFolderLocation}\\{folder}\\{updatedFileName}";

                    //save image
                    System.IO.File.WriteAllBytes(imagePath, data);
                    result = updatedFileName;
                    response.ServiceResponseMessage = result;
                }
                else
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.InvalidExtension;
                }
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ServiceResponseMessage = ex.ToString();
            }
            return response;
        }
        public async Task<ServiceResponse> UploadImageActorCard(string imageurl, UploadSettings _env, HttpClient httpClient, string[] Extensions, string ImageSize)
        {
            string result = string.Empty;
            ServiceResponse response = new ServiceResponse();
            try
            {
                byte[] data = null;
                if (string.IsNullOrEmpty(imageurl))
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.CheckImage;
                    return response;
                }
                using (var reslt = await httpClient.GetAsync(imageurl))
                {
                    if (reslt.IsSuccessStatusCode)
                    {
                        data = await reslt.Content.ReadAsByteArrayAsync();
                    }
                }
                var splitFolder = _env.ActorCardSaveUrlLocation.Split(new[] { '/' });
                string folder = splitFolder[1];
                //suppose you are checking you ext
                //Get FileName from coming Image Path
                var fileName = Path.GetFileName(imageurl.Replace("/", "\\"));
                string ext = Path.GetExtension(fileName);
                if (Extensions.Contains(ext))
                {
                    var webRoot = _env.ActorCardSaveFolderLocation;
                    var PathWithFolderName = System.IO.Path.Combine(webRoot, folder);

                    if (!Directory.Exists(PathWithFolderName))
                    {
                        // Try to create the directory.
                        DirectoryInfo di = Directory.CreateDirectory(PathWithFolderName);
                    }

                    var updatedFileName = DateTime.Now.ToString("yyyyMM") + fileName;
                    //Get File with directory

                    var imagePath = $"{ _env.ActorCardSaveFolderLocation}\\{folder}\\{updatedFileName}";

                    //save image
                    System.IO.File.WriteAllBytes(imagePath, data);
                    var ImageSizelist = GeImageSizes(ImageSize);
                    if (ImageSizelist != null && ImageSizelist.Count() > 0)
                    {
                        
                        var fileGuid = Guid.NewGuid();

                        foreach (var photoSize in ImageSizelist)
                        {
                            var ImageName = $"{fileGuid}{photoSize.Height}{photoSize.Width}.jpg";
                            var imagePath1 = $"{ _env.ActorCardSaveFolderLocation}\\{folder}\\{ImageName}";

                            // act on the Base64 data

                            using (var image = new MagickImage(imagePath))
                            {
                                image.Resize(photoSize.Height, photoSize.Width);
                                image.Strip();
                                image.Quality = 100;
                                image.Write(imagePath1);

                            }
                            if (photoSize.Letter.Contains("j"))
                            {
                                response.ServiceResponseMessage = ImageName;
                            }

                        }
                        if ((System.IO.File.Exists(imagePath)))
                        {
                            System.IO.File.Delete(imagePath);
                        }
                    }
                }
                else
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.InvalidExtension;
                }
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ServiceResponseMessage = ex.ToString();
            }
            return response;
        }

        public async Task<ServiceResponse> UploadPictureActorCard(IFormFile file, UploadSettings _env, HttpClient httpClient, string ImageSize, string[] Extensions)
        {

            ServiceResponse response = new ServiceResponse();
            try
            {
                if (file == null)
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.CheckImage;
                    return response;
                }
                var splitFolder = _env.ActorCardSaveUrlLocation.Split(new[] { '/' });
                string folder = splitFolder[1];
                string ext = Path.GetExtension(file.FileName);
                if (Extensions.Contains(ext))
                {
                    var webRoot = _env.ActorCardSaveFolderLocation;

                    var PathWithFolderName = System.IO.Path.Combine(webRoot, folder);

                    if (!Directory.Exists(PathWithFolderName))
                    {
                        // Try to create the directory.
                        DirectoryInfo di = Directory.CreateDirectory(PathWithFolderName);
                    }

                    var ImageSizelist = GeImageSizes(ImageSize);


                    var imagePath = $"{ _env.ActorCardSaveFolderLocation}\\{folder}\\{file.FileName}";
                    if (ImageSizelist != null && ImageSizelist.Count() > 0)
                    {
                        if (file.Length > 0)
                        {
                            using (var ms = new MemoryStream())
                            {
                                file.CopyTo(ms);
                                var fileBytes = ms.ToArray();
                                string s = Convert.ToBase64String(fileBytes);
                                System.IO.File.WriteAllBytes(imagePath, fileBytes);
                            }
                        }
                        var fileGuid = Guid.NewGuid();

                        foreach (var photoSize in ImageSizelist)
                        {
                            var ImageName = $"{fileGuid}{photoSize.Height}{photoSize.Width}.jpg";
                            var imagePath1 = $"{ _env.ActorCardSaveFolderLocation}\\{folder}\\{ImageName}";

                            // act on the Base64 data

                            using (var image = new MagickImage(imagePath))
                            {
                                image.Resize(photoSize.Height, photoSize.Width);
                                image.Strip();
                                image.Quality = 100;
                                image.Write(imagePath1);

                            }
                            if (photoSize.Letter.Contains("j"))
                            {
                                response.ServiceResponseMessage = ImageName;
                            }

                        }
                        if ((System.IO.File.Exists(imagePath)))
                        {
                            System.IO.File.Delete(imagePath);
                        }
                    }

                }
                else
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.InvalidExtension;
                }



            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ServiceResponseMessage = ex.ToString();
            }
            return response;
        }
        public async Task<ServiceResponse> CopyPictureFromImdbToActorCard(string file, UploadSettings _env, string ImageSize, string[] Extensions)
        {

            ServiceResponse response = new ServiceResponse();
            try
            {
                if (file == null)
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.CheckImage;
                    return response;
                }
                var splitFolder = _env.ImdbSaveUrlLocation.Split(new[] { '/' });
                string folder = splitFolder[1];
                string ext = Path.GetExtension(file);
                if (Extensions.Contains(ext))
                {
                    var webRoot = _env.ActorCardSaveFolderLocation;

                    var PathWithFolderName = System.IO.Path.Combine(webRoot, folder);

                    if (!Directory.Exists(PathWithFolderName))
                    {
                        // Try to create the directory.
                        DirectoryInfo di = Directory.CreateDirectory(PathWithFolderName);
                    }

                    var ImageSizelist = GeImageSizes(ImageSize);


                    var imagePath = $"{ _env.ImdbSaveFolderLocation}\\{folder}\\{file}";
                    if (ImageSizelist != null && ImageSizelist.Count() > 0)
                    {
                        var splitFolderDest = _env.ImdbSaveUrlLocation.Split(new[] { '/' });
                        string folderDest = splitFolder[1];
                        var fileGuid = Guid.NewGuid();
                        foreach (var photoSize in ImageSizelist)
                        {

                            var ImageName = $"{fileGuid}{photoSize.Height}{photoSize.Width}.jpg";
                            var imagePath1 = $"{ _env.ActorCardSaveFolderLocation}\\{folderDest}\\{ImageName}";

                            // act on the Base64 data

                            using (var image = new MagickImage(imagePath))
                            {
                                image.Resize(photoSize.Height, photoSize.Width);
                                image.Strip();
                                image.Quality = 100;
                                image.Write(imagePath1);

                            }
                            if (photoSize.Letter.Contains("j"))
                            {
                                response.ServiceResponseMessage = ImageName;
                            }

                        }

                    }

                }
                else
                {
                    response.IsError = true;
                    response.ServiceResponseMessage = StaticMessages.StaticMessages.InvalidExtension;
                }



            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ServiceResponseMessage = ex.ToString();
            }
            return response;
        }
        private IList<ImageSizeDTO> GeImageSizes(string ImageSize)
        {
            if (string.IsNullOrEmpty(ImageSize))
            {
                throw new Exception("Missing client photo images sizes from configuration file (Key: ClientPhotoImageSizes)");
            }
            var clientPhotoSizes = new List<ImageSizeDTO>();
            try
            {
                foreach (string size in ImageSize.Split(new[] { ',' }))
                {
                    var letterParts = size.Split(new[] { ';' });
                    string letter = letterParts[0];
                    var sizeParts = letterParts[1].Split(new[] { 'x' });
                    int width;
                    int height;
                    int.TryParse(sizeParts[0], out width);
                    int.TryParse(sizeParts[1], out height);
                    clientPhotoSizes.Add(new ImageSizeDTO()
                    {
                        Height = height,
                        Letter = letter,
                        Width = width
                    });
                }
            }
            catch (Exception ex)
            {
                //"Client photo sizes is not in the correct format in the configuration file (Key: ClientPhotoImageSizes - j;576x720,h;250x313;,t;125x156,s;83x104,m;24x30)"+", "ex.ToString();
                throw;
            }
            return clientPhotoSizes;
        }
    }
}

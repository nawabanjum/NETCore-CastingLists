﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.StaticMessages
{
 public   class StaticMessages
    {
        public static string ProjectNotExists = "Project Id Wrong";
        public static string ActorIdNotExists = "ActorId Id Wrong";
        public static string FilmographyIdNotExists = "Filmography Id Wrong";
        public static string ActorCardIdNotExists = "ActorCard  Id Wrong";
        public static string RoleIdNotExists = "RoleId Id Wrong";
        public static string SocialLinkIdNotExists = "LinkId Id Wrong";
        public static string ListIdNotExists = "ListId Id Wrong";
        public static string ActorContactIdNotExists = "ContactId Id Wrong";
        public static string KnowsForIdNotExists = "KnowstId Id Wrong";
        public static string ActorPrivatenotesIdNotExists = "Actore Private NotesId Id Wrong";
        public static string ActorImageNotExists = "Wrong Path";
        public static string ActorImdbNotExists = "Actore Imdb Id";
        public static string InvalidExtension = "Invalid Extension";
        public static string CheckImage = "Image link is empty";
        
        public static string RoleIds = "RoleIds are required";
        public static string ActorCardPrivatenotesIdNotExists = "ActorCard Privatenotes  Id Wrong";
        public static string ActorCardContactIdNotExists = "ActorCard Contact Id Wrong";
        public static string ActorCardKnowsForIdNotExists = "ActorCard KnowsFor Id Wrong";
        public static string ActorCardEthnicityIdNotExists = "ActorCard Ethnicity Id Wrong";
        public static string ActorCardReportExportIdNotExists = "ActorCard Report Export Id Wrong";
        public static string ActorCardLinkIdNotExists = "ActorCard Link Id Wrong";

    }
}

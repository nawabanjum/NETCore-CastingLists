﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardRepository : IActorCardRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorCardRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorCard AddActorCard(tblActorCard c)
        {
            _context.TblActorCards.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCard(int id, int UserId, int UserType)
        {
            var model = _context.TblActorCards.Where(a => a.CreatedByUserId == UserId && a.CreatedByUserType == UserType && a.Id == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorCard> Get(int UserId, int UserType)
        {
            return _context.TblActorCards.Where(a => a.CreatedByUserId == UserId && a.CreatedByUserType == UserType).ToList();
        }
        public IEnumerable<tblActorCard> GetActorCardByListId(int ListId, int UserId, int UserType)
        {
            return _context.TblActorCards.Where(a => a.CreatedByUserId == UserId && a.CreatedByUserType == UserType && a.ListRId == ListId).Include(x => x.TblActorCard_Contacts).Include(x => x.TblActorCard_KnowsFor).Include(x => x.TblCastingListActorVideos).Include(x => x.TblCastingListActor_PrivateNotes).Include(x=>x.TblActorCardImages).Include(x=>x.TblActorCardEthnicities).ToList();
        }
        public tblActorCard GetActorCardById(int id, int UserId, int UserType)
        {
            return _context.TblActorCards.Where(a => a.CreatedByUserId == UserId && a.CreatedByUserType == UserType && a.Id == id).Include(x => x.TblActorCard_Contacts).Include(x => x.TblActorCard_KnowsFor).Include(x => x.TblCastingListActorVideos).Include(x => x.TblCastingListActor_PrivateNotes).Include(x=>x.TblActorCardLinks).Include(x=>x.TblActorCardImages).FirstOrDefault();
        }
        public tblActorCard GetById(int id)
        {
            return _context.TblActorCards.Where(a => a.Id == id).FirstOrDefault();
        }
        public tblActorCard UpdateActorCard(tblActorCard c)
        {
            _context.TblActorCards.Update(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateActorCardSortOrder(List<ActorSortDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    query = query + $"Update tblActorCard SET  SortOrder={item.SortOrder} WHERE Id={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
        public void UpdateActorCardStatus(List<ActorStatusDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    int status = Convert.ToInt32(item.IsHidden);
                    query = query + $"Update tblActorCard SET  IsHidden={status} WHERE Id={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
        public IEnumerable<tblActorCard> ValidateActor(ValidateActorDTO c)
        {
            int ActorimbdId = 0;
            int.TryParse(c.ImdbActorId, out ActorimbdId);
            var param = new DynamicParameters();
            param.Add("@ListrId", c.ListrId);
            param.Add("@ProjectrId", c.ProjectrId);
            param.Add("@RolerId", c.RolerId);
            param.Add("@ActorimbdId", ActorimbdId);
            var query = @"
                    select * from tblActorCard where RoleRId=@RolerId AND ProjectRId=@ProjectrId AND ListRId=@ListrId AND CastingList_IMDBActorId=@ActorimbdId;";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                var result = conn.Query<tblActorCard>(query, param, commandType: System.Data.CommandType.Text);
                return result;
            }
        }
        public void AddActorCardsByNewList(int NewListId, int ParentListId)
        {
            var param = new DynamicParameters();
            param.Add("@NewListId", NewListId);
            param.Add("@ParentListId", ParentListId);
            var query = @"
                   DECLARE
						@Id							INT ,
						@DisplayName				VARCHAR(250)	,
						@RoleRId					INT				,
						@ProjectRId					INT				,
						@ListRId					INT				,
						@Notes						NVARCHAR(1024)	,
						@BOD						DATETIME		,
						@AgeRange					VARCHAR(50)		,
						@GenderRId					INT				,
						@HeightFeet					INT				,
						@HeightInches				INT				,
						@MasterCast_ClientId		INT				,
						@MasterCast_RosterId		INT				,
						@CastingList_IMDBActorId	INT				,
						@CreatedByUserId			INT				,
						@CreatedByUserType			INT				,
						@CreatedOn					DATETIME		,
						@LastUpdatedDate			DATETIME		,
						@IsHidden					BIT				,
						@SortOrder					INT				,
						@ActorId_Prev				INT				,
						@ActorId_New				INT

				DECLARE cursor_rawData CURSOR
				FOR SELECT
		
						i.Id,i.DisplayName,i.RoleRId,i.ProjectRId,i.ListRId,i.Notes,i.BOD,i.AgeRange,i.GenderRId,
						i.HeightFeet,i.HeightInches,i.MasterCast_ClientId,i.MasterCast_RosterId,i.CastingList_IMDBActorId,
						i.CreatedByUserId,i.CreatedByUserType,i.CreatedOn,i.LastUPdatedDate,i.IsHidden,i.SortOrder

				From tblActorCard i 
				WHERE i.ListRId=@ParentListId
				OPEN cursor_rawData

			FETCH NEXT FROM cursor_rawData INTO
						@Id							,
						@DisplayName				,
						@RoleRId					,
						@ProjectRId					,
						@ListRId					,
						@Notes						,
						@BOD						,
						@AgeRange					,
						@GenderRId					,
						@HeightFeet					,
						@HeightInches				,
						@MasterCast_ClientId		,
						@MasterCast_RosterId		,
						@CastingList_IMDBActorId	,
						@CreatedByUserId			,
						@CreatedByUserType			,
						@CreatedOn					,
						@LastUpdatedDate			,
						@IsHidden					,
						@SortOrder					
			WHILE @@FETCH_STATUS = 0
			BEGIN
			SET @ActorId_Prev  = @Id
			SET  @ActorId_New  =0
			
				INSERT INTO tblActorCard
				(
					DisplayName					,
					RoleRId						,
					ProjectRId					,
					ListRId						,
					Notes						,
					BOD							,
					AgeRange					,
					GenderRId					,
					HeightFeet					,
					HeightInches				,
					MasterCast_ClientId			,
					MasterCast_RosterId			,
					CastingList_IMDBActorId		,
					CreatedByUserId				,
					CreatedByUserType			,
					CreatedOn					,
					LastUpdatedDate				,
					IsHidden					,
					SortOrder					
				)
			VALUES
				(
					@DisplayName				,
					@RoleRId					,
					@ProjectRId					,
					@NewListId					,
					@Notes						,
					@BOD						,
					@AgeRange					,
					@GenderRId					,
					@HeightFeet					,
					@HeightInches				,
					@MasterCast_ClientId		,
					@MasterCast_RosterId		,
					@CastingList_IMDBActorId	,
					@CreatedByUserId			,
					@CreatedByUserType			,
					@CreatedOn					,
					@LastUpdatedDate			,
					@IsHidden					,
					@SortOrder						
				)
				SELECT @ActorId_New = SCOPE_IDENTITY()
				--Fetch and insert data into tblCastingListActor_Contacts table
				INSERT INTO tblCastingListActor_Contacts
				(
					ContactType,ContactName ,ContactCompany	,ContactEmail,ContactPhone,CastingList_ActorId,CreatedOn,
					LastUpdatedDate,IsHidden,SortOrder,OriginalImdbContactRId
				)
				-- Fetch data from tblActorCard_Contacts by old CastingList_ActorId and insert with Insert with New CastingList_ActorId
				SELECT 
					ContactType,ContactName	,ContactCompany	,ContactEmail,ContactPhone	,  @ActorId_New,
					CreatedOn,LastUpdatedDate,IsHidden,SortOrder,OriginalImdbContactRId
				FROM tblCastingListActor_Contacts WHERE CastingList_ActorId=@ActorId_Prev
			
			
				-----------tblCastingListActor_KnowsFor
				INSERT INTO tblCastingListActor_KnowsFor 
				(
					Title,Link,CastingList_ActorRId,CreatedOn,IsHidden,ModifiedOn,OriginalImdbKnowsForRId,SortOrder
				)
				SELECT 
					Title,Link,@ActorId_New,CreatedOn,IsHidden,ModifiedOn,OriginalImdbKnowsForRId,SortOrder 
				FROM tblCastingListActor_KnowsFor WHERE CastingList_ActorRId=@ActorId_Prev
			
				-----------tblCastingListActor_PrivateNote
				INSERT INTO tblCastingListActor_PrivateNote 
				(
					Notes,CastingList_ActorRId,CreatedOn,LastUpdatedDate,IsHidden,SortOrder
				)
				SELECT  
					Notes,@ActorId_New,CreatedOn,LastUpdatedDate,IsHidden,SortOrder 
				FROM tblCastingListActor_PrivateNote WHERE CastingList_ActorRId=@ActorId_Prev
			
				-----------tblCastingListActorVideos
				INSERT INTO tblCastingListActorVideos
				(
					MediaRId,IsAudio,IsHidden,CastingList_ActorRId,CreatedOn,SortOrder
				)
				SELECT  
					MediaRId,IsAudio,IsHidden,@ActorId_New,CreatedOn,SortOrder 
				FROM tblCastingListActorVideos	 WHERE CastingList_ActorRId=@ActorId_Prev
				-----------tblCastingListEthnicity
				INSERT INTO tblCastingListEthnicity
				(
					EthnicityRId,CastingList_ActorRId,CreatedOn,IsHidden,SortOrder
				)
				SELECT 
					EthnicityRId,@ActorId_New,CreatedOn,IsHidden,SortOrder 
				FROM tblCastingListEthnicity WHERE CastingList_ActorRId=@ActorId_Prev
			
			FETCH NEXT FROM cursor_rawData INTO
				@Id							,
				@DisplayName				,
				@RoleRId					,
				@ProjectRId					,
				@ListRId					,
				@Notes						,
				@BOD						,
				@AgeRange					,
				@GenderRId					,
				@HeightFeet					,
				@HeightInches				,
				@MasterCast_ClientId		,
				@MasterCast_RosterId		,
				@CastingList_IMDBActorId	,
				@CreatedByUserId			,
				@CreatedByUserType			,
				@CreatedOn					,
				@LastUpdatedDate			,
				@IsHidden					,
				@SortOrder					
			END

			CLOSE cursor_rawData
			DEALLOCATE  cursor_rawData ";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                var result = conn.Query(query, param, commandType: System.Data.CommandType.Text);
            }
        }
    }
}

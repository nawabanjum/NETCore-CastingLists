﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class SocialLinkRepository : ISocialLinkRepository
    {
        private readonly ProjectManContext _context;
        public SocialLinkRepository( ProjectManContext context)
        {
            _context = context;
        }
        public tblSocialLinks AddSocialLink(tblSocialLinks c)
        {
            _context.TblSocials.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteSocialLink(int id)
        {
            var model = _context.TblSocials.Where(a => a.LinkId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblSocialLinks> GetSocialLinkByActorId(int Actorid)
        {
            return _context.TblSocials.Where(a => a.ActorRId == Actorid).ToList();
        }
        public tblSocialLinks GetSocialLinkById(int id)
        {
            return _context.TblSocials.Find(id);
        }
        public tblSocialLinks UpdateSocialLink(tblSocialLinks c)
        {
            _context.TblSocials.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

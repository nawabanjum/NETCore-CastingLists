﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorImdbArchiveRepository : IActorImdbArchiveRepository
    {
        private readonly ProjectManContext _context;
        public ActorImdbArchiveRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblActorImdbArchive AddActorImdb(tblActorImdbArchive c)
        {
            _context.TblActorImdbArchives.Add(c);
            _context.SaveChanges();
            return c;
        }
        //public void DeleteActorImdb(int id, int userid, int usertype)
        //{
        //    throw new NotImplementedException();
        //}

        //public tblActorImdbArchive GeActorImdbById(int id, int userid, int usertype)
        //{
        //    throw new NotImplementedException();
        //}

        //public IEnumerable<ActorImdbArchiveDTO> Get(int userid, int usertype, int projectid)
        //{
        //    throw new NotImplementedException();
        //}

        //public void UpdateActorImdb(tblActorImdbArchive c)
        //{
        //    throw new NotImplementedException();
        //}
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorImdbImagesRepository : IActorImdbImagesRepository
    {
        private readonly ProjectManContext _context;
        public ActorImdbImagesRepository(ProjectManContext projectManContext)
        {
            _context = projectManContext;
        }
        public tblActorImdbImages AddActorImdbImage(tblActorImdbImages c)
        {
            _context.TblActorImdbImages.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorImdbImage(int id)
        {
            var model = _context.TblActorImdbImages.Where(a => a.Id == id).FirstOrDefault();
            if (model !=null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorImdbImages> GetImagesByActorId(int Actorid)
        {
            return _context.TblActorImdbImages.Where(a => a.ActorRId == Actorid);
        }
    }
}

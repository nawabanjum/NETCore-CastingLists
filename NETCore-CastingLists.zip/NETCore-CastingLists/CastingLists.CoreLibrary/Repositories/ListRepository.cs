﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ListRepository : IListRepository
    {
        private readonly ProjectManContext _context;
        public ListRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblList AddList(tblList c)
        {
            _context.tblList.Add(c);
            _context.SaveChanges();
            return c;
        }
        public bool CheckProjectExistance(int userid, int createdByUserType, int projectId)
        {
            bool exist = false;
            var ext = _context.lstProject.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == createdByUserType && a.ProjectId == projectId);
            if (ext != null)
            {
                exist = true;
            }
            return exist;
        }
        public void DeleteList(int id)
        {
            var model = _context.tblList.Find(id);
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblList> Get(int userid, int usertype, int projectid)
        {
            return _context.tblList.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ProjectRId == projectid && a.IsActive==true ).ToList(); ;
        }
        public tblList GetListyId(int id)
        {
            return _context.tblList.Find(id);
        }
        public void UpdateList(tblList c)
        {
            _context.tblList.Update(c);
            _context.SaveChanges();
        }
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardPrivateNoteRepository : IActorCardPrivateNoteRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorCardPrivateNoteRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorCard_PrivateNote AddActorCardPrivateNote(tblActorCard_PrivateNote c)
        {
            _context.TblActorCard_PrivateNotes.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCardPrivateNote(int id)
        {
            var model = _context.TblActorCard_PrivateNotes.Where(a => a.ActorCard_PrivateNoteId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorCard_PrivateNote> Get(int CastingList_ActorId)
        {
            return _context.TblActorCard_PrivateNotes.Where(a => a.ActorCardRId == CastingList_ActorId);
        }
        public tblActorCard_PrivateNote GetById(int id)
        {
            return _context.TblActorCard_PrivateNotes.Where(a => a.ActorCard_PrivateNoteId == id).FirstOrDefault();
        }
        public tblActorCard_PrivateNote UpdateActorCardPrivateNote(tblActorCard_PrivateNote c)
        {
            _context.TblActorCard_PrivateNotes.Update(c);
            _context.SaveChanges();
            return c;
        }
        public void updateActorCardPrivateNoteSortOrder(List<ActorSortDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    query = query + $"Update tblActorCard_PrivateNote SET  SortOrder={item.SortOrder} WHERE CastingListActror_PrivateNoteId={item.Id};  ";
                }
                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
        public void UpdateActorCardPrivateNoteStatus(List<ActorStatusDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    int status = Convert.ToInt32(item.IsHidden);
                    query = query + $"Update tblActorCard_PrivateNote SET  IsHidden={status} WHERE CastingListActror_PrivateNoteId={item.Id};  ";
                }
                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
    }
}

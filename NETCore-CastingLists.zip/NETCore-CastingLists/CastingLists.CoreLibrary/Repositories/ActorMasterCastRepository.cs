﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{

    public class ActorMasterCastRepository : IActorMasterCastRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorMasterCastRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public MasterDto Get(ParamActorMasterCastSearchDTO dto)
        {
            MasterDto masterDto = new MasterDto();
            var param = new DynamicParameters();
            param.Add("@RosterRId", dto.RosterRId);
            param.Add("@ClientRId", dto.ClientRId);
            string query = string.Empty;
            query = @"
                    SELECT	 
		                    acp.rosterrid as RosterId,
                            acp.firstname + ' ' + acp.lastname as Agentname,
                            acp.firstname as Firstname,
                            acp.middlename as Middlename,
                            acp.lastname as Lastname,
		                    acp.gender as Gender,
		                    acp.heightfeet as Heightfeet,
		                    acp.heightinches as Heightinches,
		                    acp.weight as Weight,
		                    acp.birthday as Birthday,
		                    acp.agefrom as Agefrom,
		                    acp.ageto as Ageto
	               FROM clients.dbo.tblActorprofiles acp WITH (NOLOCK)
	               WHERE acp.rosterrid = @RosterRId";

            string queryCLient = @" SELECT 
		                    
                            cl.firstname + ' ' + cl.lastname as ClientName,
                            cl.firstname as Client_Firstname,
                            cl.middlename as Client_Middlename,
                            cl.lastname as Client_Lastname,
		                    cl.gender as Client_Gender,
		                    cl.heightfeet as Client_Heightfeet,
		                    cl.heightinches as Client_Heightinches,
		                    cl.weight as Client_Weight,
		                    cl.birthday as Client_Birthday
	             
				    from clients.dbo.tblclients cl  WITH (NOLOCK)
                    WHERE cl.ClientId = @ClientRId ";
            string queryActorContact = @"SELECT  
									ag.agentid as AgentId,
							ISNULL(ag.firstName,'') as Actor_FirstName,
							ISNULL(ag.lastname,'') as Actor_LastName,
							ISNULL(ag.company,'') as Actor_Company,
							ISNULL(ag.phone,'') as Actor_Phone,
							ISNULL(ag.address1,'') as Actor_Address,
							ISNULL(ag.email,'') as Actor_Email,
							ISNULL(ag.isHidden,0) as Actor_IsHidden,
							ISNULL(ag.website,'') as Actor_Website
					 FROM [clients]..tblAgents ag  WITH (NOLOCK)
					 JOIN clients.[dbo].[tblrosters] on clients.[dbo].[tblrosters].agentrid=ag.agentid
					 where clients.[dbo].[tblrosters].rosterid=@RosterRId
					 order by 1 desc";
            string queryActorImage = @" SELECT 
								clnt.Client_ID,
								clnt.JPG AS Image,
								clnt.PhotoNum,
								clnt.File_Size  
					FROM [clients]..CLIENT_JPG clnt
					 JOIN clients.[dbo].[tblrosters] on clients.[dbo].[tblrosters].defPhotoNum=clnt.PhotoNum
					where clnt.CLIENT_ID = @ClientRId  and clients.[dbo].[tblrosters].rosterid=@RosterRId ";
      
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.Clients))
            {
                ActorViaMasterDTO actorViaMasterDTO = new ActorViaMasterDTO();
                var reader =  conn.QueryMultiple(query + queryCLient+ queryActorContact+ queryActorImage, param, commandType: System.Data.CommandType.Text);
                var mastercast = reader.Read<ActorViaMasterDTO>().FirstOrDefault();
                var mastercastClient = reader.Read<ActorViaMasterClientDTO>().FirstOrDefault();
                var mastercastContact = reader.Read<ActorContactViaMasterDTO>().FirstOrDefault();
                var mastercastImages = reader.Read<ActorImageViaMasterDTO>().ToList();
                if (mastercast != null )
                {
                    actorViaMasterDTO.Agefrom = mastercast.Agefrom;
                    actorViaMasterDTO.Agentname = string.IsNullOrEmpty(mastercast.Agentname)? mastercastClient.ClientName: mastercast.Agentname;
                    actorViaMasterDTO.Ageto = mastercast.Ageto;
                    actorViaMasterDTO.Birthday = mastercast.Birthday == null ? mastercastClient.Client_Birthday : mastercast.Birthday;
                    actorViaMasterDTO.Firstname =string.IsNullOrEmpty(mastercast.Firstname)? mastercastClient.Client_Firstname: mastercast.Firstname;
                    actorViaMasterDTO.Gender = mastercast.Gender<=0? mastercastClient.Client_Gender: mastercast.Gender;
                    actorViaMasterDTO.Heightfeet = mastercast.Heightfeet<=0? mastercastClient.Client_Heightfeet : mastercast.Heightfeet;
                    actorViaMasterDTO.Heightinches = mastercast.Heightinches<=0? mastercastClient.Client_Heightinches: mastercast.Heightinches;
                    actorViaMasterDTO.Lastname = string.IsNullOrEmpty(mastercast.Lastname)? mastercastClient.Client_Lastname: mastercast.Lastname;
                    actorViaMasterDTO.Middlename = string.IsNullOrEmpty(mastercast.Middlename)? mastercastClient.Client_Middlename: mastercast.Middlename;
                    actorViaMasterDTO.Weight = mastercast.Weight<=0?mastercastClient.Client_Weight: mastercast.Weight;
                    masterDto.actorViaMasterDTO = actorViaMasterDTO;
                }
                if (mastercastContact !=null)
                {
                    masterDto.actorContactViaMasterDTO = mastercastContact;
                }
                if (mastercastImages !=null && mastercastImages.Count()>0)
                {
                    masterDto.actorImageViaMasterDTO = mastercastImages;
                }
                return masterDto;
            }
        }
    }
}

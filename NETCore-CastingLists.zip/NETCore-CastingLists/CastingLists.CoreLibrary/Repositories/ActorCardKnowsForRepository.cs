﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardKnowsForRepository : IActorCardKnowsForRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorCardKnowsForRepository(IDataConnector dataConnector, ProjectManContext projectManContext)
        {
            _dataConnector = dataConnector;
            _context = projectManContext;
        }
        public tblActorCard_KnowsFor AddActorCardKnowsFor(tblActorCard_KnowsFor c)
        {
            _context.TblActorCard_KnowsFor.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCardKnowsFor(int id)
        {
            var model = _context.TblActorCard_KnowsFor.Where(a => a.ActorCard_KnowsForId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
                _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan);
            }
        }
        public IEnumerable<tblActorCard_KnowsFor> Get(int CastingList_ActorId)
        {
            return _context.TblActorCard_KnowsFor.Where(a => a.ActorCardRId == CastingList_ActorId).ToList();
        }
        public tblActorCard_KnowsFor GetById(int id)
        {
            return _context.TblActorCard_KnowsFor.Where(a => a.ActorCard_KnowsForId == id).FirstOrDefault();
        }
        public tblActorCard_KnowsFor UpdateActorCardKnowsFor(tblActorCard_KnowsFor c)
        {
            _context.TblActorCard_KnowsFor.Update(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateActorCardKnowsForSortOrder(List<ActorSortDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    query = query + $"Update tblActorCard_KnowsFor SET  SortOrder={item.SortOrder} WHERE ActorCard_KnowsForId={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
        public void UpdateActorCardKnowsForStatus(List<ActorStatusDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    int status = Convert.ToInt32(item.IsHidden);
                    query = query + $"Update tblActorCard_KnowsFor SET  IsHidden={status} WHERE ActorCard_KnowsForId={item.Id};  ";
                }
                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
    }
}

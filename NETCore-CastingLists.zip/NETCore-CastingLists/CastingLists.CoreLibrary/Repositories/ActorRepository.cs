﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorRepository : IActorRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorImdb AddActor(tblActorImdb c)
        {
            _context.TblActorImdbs.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActor(int id, int userid, int usertype)
        {
            var model = _context.TblActorImdbs.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ActorId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorImdb> Get(int userid, int usertype)
        {
            return _context.TblActorImdbs.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype).ToList();
        }
        public tblActorImdb GetActorById(int id, int userid, int usertype)
        {
            return _context.TblActorImdbs.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ActorId == id).FirstOrDefault();
        }
        public tblActorImdb GetActorByImdbId(string ImdbId)
        {
            return _context.TblActorImdbs.Where(a => a.ImdbId == ImdbId)
                .Include(x => x.TblActorContacts).Include(x=>x.TblKnowsFors).Include(x => x.TblSocials)
                    .AsEnumerable()
                .FirstOrDefault();
        }
        public tblActorImdb GetById(int id)
        {
            return _context.TblActorImdbs.Where(a =>a.ActorId == id).FirstOrDefault();
        }
        public IEnumerable<tblActorImdb> SearchActorByName(string SearchText)
        {
            return _context.TblActorImdbs.Where(a=>a.FirstName.ToLower().Contains(SearchText.ToLower())||a.LastName.ToLower().Contains(SearchText.ToLower())).ToList();
        }

        public tblActorImdb UpdateActor(tblActorImdb c)
        {
            _context.TblActorImdbs.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

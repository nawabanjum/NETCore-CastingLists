﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class HomeRepository : IHomeRepository
    {
        private readonly IDataConnector _dataConnector;
        public HomeRepository(IDataConnector dataConnector)
        {
            _dataConnector = dataConnector;
        }
        public async Task<ListCommonListDTO> GetProjectsList(GlobalSearch paginationDTO)
        {
            var param = new DynamicParameters();
            param.Add("@CreatedByUserId", paginationDTO.CreatedByUserId);
            param.Add("@CreatedByUserType", paginationDTO.CreatedByUserType);
            param.Add("@PageNo", paginationDTO.PageNumber == 0 ? 1 : paginationDTO.PageNumber);
            param.Add("@PageSize", paginationDTO.PageSize == 0 ? 10 : Math.Min(paginationDTO.PageSize, 50));
            param.Add("@SearchKey", paginationDTO.SearchKey);
            string query = string.Empty;
            string orderBy = "ORDER BY t.CreatedOn Desc";
            query = @"
                   SELECT * INTO #TempTable  FROM (select isnull(l.ListName,'') As ListName,
                   isnull(l.CreatedOn,GetDate()) AS  CreatedOn,
                   l.ListId,
                   isnull(p.ProjectTitle,'') AS ProjectTitle,
                   p.ProjectId,
                   isnull(p.StudioName,'') AS StudioName,
		             (STUFF((SELECT ', ' + a.RoleTitle
                    FROM tblRoles a
                        where a.ProjectRId=p.ProjectId FOR XML PATH('') ), 1, 1, '') ) as RoleTitle,
                   ROW_NUMBER() Over (Order by l.ListId Desc) AS 'RowNum'
                   from [dbo].[tblList] l
                   JOIN [dbo].[tblProjectList] p on p.ProjectId= l.[ProjectRId]
                   
                    WHERE l.CreatedByUserId=@CreatedByUserId 
					AND	 l.CreatedByUserType=@CreatedByUserType 
					AND	 l.IsActive=1 
					AND	 p.IsActive=1";
            if (!string.IsNullOrEmpty(paginationDTO.SearchKey))
            {
                query = query + " AND  l.ListName like '%' + @SearchKey + '%' OR p.ProjectTitle LIKE  '%' + @SearchKey + '%' ";
                orderBy = "ORDER BY t.ListName,t.ProjectTitle ASC";
            }
            query = query + " )t Where t.RowNum Between((@PageNo - 1) * @PageSize + 1) AND(@PageNo * @pageSize) " + orderBy + "  Select * from #TempTable";

            string queryCount = @" select COUNT(1) AS TotalNumber,   @PageSize As PageSize,@PageNo AS PageNumber
                   from [dbo].[tblList] l
                   JOIN [dbo].[tblProjectList] p on p.ProjectId= l.[ProjectRId]
                   WHERE l.CreatedByUserId=@CreatedByUserId 
                    AND  l.CreatedByUserType=@CreatedByUserType  
                    AND	 l.IsActive=1 
					AND	 p.IsActive=1";

            if (!string.IsNullOrEmpty(paginationDTO.SearchKey))
            {
                queryCount = queryCount + " AND  l.ListName like '%' + @SearchKey + '%' OR p.ProjectTitle LIKE  '%' + @SearchKey + '%' ";
            }
            string queryExports = @"SELECT e.Id,e.Title 
                                    FROM  tblActorCardExports e
                                    JOIN #TempTable t ON t.ListId=e.ListId
                                    WHERE e.Listid=t.ListId 
                                    AND e.CreatedByUserId=@CreatedByUserId 
                                    AND e.CreatedByUserType=@CreatedByUserType
                                   
                                    DROP TABLE #TempTable";
            string qury = query + queryCount + queryExports;
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                ListCommonListDTO list = new ListCommonListDTO();
                var reader = await conn.QueryMultipleAsync(query + queryCount + queryExports, param, commandType: System.Data.CommandType.Text);
                list.commonListDTOs = reader.Read<CommonListDTO>().AsList();
                list.paginationDTO = reader.Read<PaginationDTO>().FirstOrDefault();
                list.exportListDTOs = reader.Read<ExportListDTO>().AsList();

                return list;
            }
        }
        private static string GetCommaSperateRoles(IEnumerable<CommonListDTO> list, StringBuilder builder, int LisId)
        {
            foreach (var item in list.Where(a => a.ListId == LisId))
            {
                builder.Append(item.RoleTitle).Append(",");
            }
            string finalString = builder.ToString();
            return finalString;
        }
        public async Task<TreeDTO> TreeList(int CreatedByUserId, int CreatedByUserType)
        {
            var param = new DynamicParameters();
            param.Add("@CreatedByUserId", CreatedByUserId);
            param.Add("@CreatedByUserType", CreatedByUserType);
            string query = string.Empty;
            query = @"
                   SELECT  isnull(l.ListName,'') As ListName,
                   isnull(l.CreatedOn,GetDate()) AS  CreatedOn,
                    isnull(l.ModifiedOn,GetDate()) AS  ModifiedOn,
                   l.ListId,
                   isnull(p.ProjectTitle,'') AS ProjectTitle,
                   p.ProjectId,
                   isnull(p.StudioName,'') AS StudioName,
                   isnull(r.RoleTitle,'') AS  RoleTitle,
                    r.RoleId,
					(select Count(*) from tblActorCard WHERE ListRId=l.ListId) as TotalActorByList,
					(select Count(*) from tblActorCard WHERE ListRId=l.ListId AND RoleRId=r.RoleId) as TotalActorByRole
                    
                   from [dbo].[tblList] l
                   JOIN [dbo].[tblProjectList] p on p.ProjectId= l.[ProjectRId]
                   JOIN tblRoles  r on p.ProjectId=r.[ProjectRId]
                    WHERE l.CreatedByUserId=@CreatedByUserId 
				    AND	 l.CreatedByUserType=@CreatedByUserType
				    AND	 l.IsActive=1 
				    AND	 p.IsActive=1";

            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                TreeDTO list = new TreeDTO();
                var result = await conn.QueryAsync<CommonListDTO>(query, param, commandType: System.Data.CommandType.Text);
                var lst = result;
                if (lst.Count() > 0)
                {
                    var distinct = lst.Select(a => a.ProjectId).Distinct();
                    StringBuilder builder = new StringBuilder();
                    foreach (var LisId in distinct)
                    {
                        var obj = new CommonLookUpDTO();
                        var rslt = lst.Where(a => a.ProjectId == LisId).FirstOrDefault();
                        list.ProjectNode.Id = rslt.ProjectId;
                        list.ProjectNode.Title = rslt.ProjectTitle;
                        list.ProjectNode.CreatedDate = rslt.CreatedOn;
                        list.ProjectNode.ModifiedDate = rslt.ModifiedOn;
                        foreach (var item in lst.Where(a => a.ProjectId == LisId))
                        {
                            var obj1 = new CommonLookUpChildNodeDTO();
                            obj1.Id = item.ListId;
                            obj1.Title = item.ListName;
                            obj1.ModifiedDate = item.ModifiedOn;
                            obj1.CreatedDate = item.CreatedOn;
                            obj1.ProjectId = rslt.ProjectId;
                            obj1.TotalCount = item.TotalActorByList;
                            foreach (var itm in lst.Where(a => a.RoleId == item.RoleId))
                            {
                                var objRole = new CommonLookUpChildNodeRoleDTO();
                                objRole.Id = itm.RoleId;
                                objRole.Title = itm.RoleTitle;
                                objRole.ModifiedDate = itm.ModifiedOn;
                                objRole.CreatedDate = itm.CreatedOn;
                                objRole.ProjectId = rslt.ProjectId;
                                objRole.TotalCount = itm.TotalActorByRole;
                                obj1.Roles.Add(objRole);
                            }
                            list.ListNode.Add(obj1);
                        }
                        foreach (var item in lst.Where(a => a.ProjectId == LisId))
                        {
                            var obj1 = new CommonLookUpChildNodeDTO();
                            obj1.Id = item.ListId;
                            obj1.Title = item.ListName;
                            obj1.ModifiedDate = item.ModifiedOn;
                            obj1.CreatedDate = item.CreatedOn;
                            obj1.ProjectId = rslt.ProjectId;
                            list.ListNode.Add(obj1);
                        }
                    }
                }
                return list;
            }
        }
    }
}

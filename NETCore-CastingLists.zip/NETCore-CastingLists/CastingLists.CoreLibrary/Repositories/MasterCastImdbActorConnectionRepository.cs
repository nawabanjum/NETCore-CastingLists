﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class MasterCastImdbActorConnectionRepository : IMasterCastImdbActorConnectionRepository
    {
        private readonly ProjectManContext _context;
        public MasterCastImdbActorConnectionRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblMasterCastImdbActorConnection AddMasterCastImdbActor(tblMasterCastImdbActorConnection c)
        {
            _context.TblMasterCastImdbActorConnections.Add(c);
            _context.SaveChanges();
            return c;
        }
    }
}

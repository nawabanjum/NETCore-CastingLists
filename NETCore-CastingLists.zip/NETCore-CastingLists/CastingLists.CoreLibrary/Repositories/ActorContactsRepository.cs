﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorContactsRepository : IActorContactsRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorContactsRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorContacts AddActorContact(tblActorContacts c)
        {
            _context.TblActorContacts.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorContact(int id)
        {
            var model = _context.TblActorContacts.Where(a => a.ContactId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public void DeleteActorContactByActorId(int Actorid)
        {
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                var param = new DynamicParameters();
                param.Add("@Actorid", Actorid);
                var sqlStatement = "Delete FROM tblActorContacts WHERE ActorRId=@Actorid";
                conn.Execute(sqlStatement, param);
            }
        }
        public IEnumerable<tblActorContacts> GetActorContactByActorId(int Actorid)
        {
            return _context.TblActorContacts.Where(a => a.ActorRId == Actorid).ToList();
        }
        public tblActorContacts GetActorContactById(int id)
        {
            return _context.TblActorContacts.Find(id);
        }
        public tblActorContacts UpdateActorContact(tblActorContacts c)
        {
            _context.TblActorContacts.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class RoleRepository : IRoleRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public RoleRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
            _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan);
        }
        public tblRoles AddRole(tblRoles c)
        {
            _context.TblRoles.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteRole(int id, int userid, int usertype)
        {
            var model = _context.TblRoles.Where(a => a.RoleId == id && a.CreatedByUserId == userid && a.CreatedByUserType == usertype).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblRoles> Get(int userid, int usertype, int projectid)
        {
            return _context.TblRoles.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ProjectRId == projectid).ToList();
        }
        public tblRoles GetRoleById(int id, int userid, int usertype)
        {
            return _context.TblRoles.Where(a => a.RoleId == id && a.CreatedByUserId == userid && a.CreatedByUserType == usertype).FirstOrDefault();
        }
        public tblRoles GetById(int id)
        {
            return _context.TblRoles.Where(a => a.RoleId == id).FirstOrDefault();
        }
        public IEnumerable<ActroRoleDTO> ValidateRoles(List<ActorRoles> list)
        {
            List<ActroRoleDTO> ActroRoles = new List<ActroRoleDTO>();
            List<int> lists = new List<int>();
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    lists.Add(item.RoleId);
                }
            }
            var roleIds = string.Join(",", lists);
            var queryActorRoles = @$"SELECT 
                                                rl_Id AS RoleId,
                                                ISNULL (rl_Name,'') AS RoleName 
                                             FROM [dbo].[role] WHERE rl_id IN ({roleIds})";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                ActroRoles = conn.Query<ActroRoleDTO>(queryActorRoles, commandType: System.Data.CommandType.Text).ToList();
            }
            return ActroRoles;
        }
        public void UpdateRole(tblRoles c)
        {
            _context.TblRoles.Update(c);
            _context.SaveChanges();
        }
    }
}

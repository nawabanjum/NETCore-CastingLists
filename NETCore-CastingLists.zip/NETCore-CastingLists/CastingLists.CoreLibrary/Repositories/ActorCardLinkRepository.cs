﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardLinkRepository : IActorCardLinkRepository
    {
        private readonly ProjectManContext _context;
        public ActorCardLinkRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblActorCardLinks AddLink(tblActorCardLinks c)
        {
            _context.TblActorCardLinks.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteLink(int id)
        {
            var model = _context.TblActorCardLinks.Where(a => a.LinkId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorCardLinks> GetLinkByActorId(int Actorid)
        {
            return _context.TblActorCardLinks.Where(a => a.ActorCardRId == Actorid).ToList();
        }
        public tblActorCardLinks GetLinkById(int id)
        {
            return _context.TblActorCardLinks.Where(a => a.LinkId == id).FirstOrDefault();
        }
        public tblActorCardLinks UpdateLink(tblActorCardLinks c)
        {
            _context.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

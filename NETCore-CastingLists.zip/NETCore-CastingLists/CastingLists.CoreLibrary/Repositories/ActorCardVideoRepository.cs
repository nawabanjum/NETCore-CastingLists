﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardVideoRepository : IActorCardVideoRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorCardVideoRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorCardVideos AddActorCardVideo(tblActorCardVideos c)
        {
            _context.TblCastingListActorVideos.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCardVideo(int id)
        {
            var model = _context.TblCastingListActorVideos.Where(a => a.ActorCard_VideoId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorCardVideos> Get(int CastingList_ActorRId)
        {
            return _context.TblCastingListActorVideos.Where(a=>a.ActorCardRId== CastingList_ActorRId).ToList();
        }
        public tblActorCardVideos GetById(int id)
        {
            return _context.TblCastingListActorVideos.Where(a => a.ActorCard_VideoId == id).FirstOrDefault();
        }
        public tblActorCardVideos UpdateActorCardVideo(tblActorCardVideos c)
        {
            _context.TblCastingListActorVideos.Update(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateActorCardVideoSortOrder(List<ActorSortDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    query = query + $"Update tblActorCardVideos SET  SortOrder={item.SortOrder} WHERE ActorCard_VideoId={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
        public void UpdateActorCardVideoStatus(List<ActorStatusDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    int status = Convert.ToInt32(item.IsHidden);
                    query = query + $"Update tblActorCardVideos SET  IsHidden={status} WHERE ActorCard_VideoId={item.Id};  ";
                }
                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
    }
}

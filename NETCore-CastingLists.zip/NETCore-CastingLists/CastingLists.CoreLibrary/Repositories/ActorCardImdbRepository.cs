﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardImdbRepository : IActorCardImdbRepository
    {
        private readonly ProjectManContext _context;
        public ActorCardImdbRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblActorImdb Get(int CastingList_IMDBActorId)
        {
            return _context.TblActorImdbs.Where(a => a.ActorId == CastingList_IMDBActorId)
                 .Include(x => x.TblActorContacts).Include(x => x.TblKnowsFors).Include(x => x.TblSocials)
                     .AsEnumerable()
                 .FirstOrDefault();
        }
        public tblActorImdb GetImdb(int CastingList_IMDBActorId)
        {
            return _context.TblActorImdbs.Where(a => a.ActorId == CastingList_IMDBActorId).FirstOrDefault();
        }
    }
}

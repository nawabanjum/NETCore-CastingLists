﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorPrivateNotesRepository : IActorPrivateNotesRepository
    {
        private readonly ProjectManContext _context;
        public ActorPrivateNotesRepository(ProjectManContext context)
        {
           
            _context = context;
        }

        public tblActorPriveNotes AddActorPrivateNotes(tblActorPriveNotes c)
        {
            _context.TblActorPriveNotes.Add(c);
            _context.SaveChanges();
            return c;
        }

        public void DeleteActorPrivateNotes(int id, int userid, int usertype)
        {
            var model = _context.TblActorPriveNotes.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.Id == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }

        public tblActorPriveNotes GeActorPrivateNotesById(int id, int userid, int usertype)
        {
            return _context.TblActorPriveNotes.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.Id == id).FirstOrDefault();
        }

        public IEnumerable<tblActorPriveNotes> Get(int userid, int usertype, int actorid)
        {
            return _context.TblActorPriveNotes.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ActorRId == actorid).ToList();
        }

        public tblActorPriveNotes UpdateActorPrivateNotes(tblActorPriveNotes c)
        {
            _context.TblActorPriveNotes.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

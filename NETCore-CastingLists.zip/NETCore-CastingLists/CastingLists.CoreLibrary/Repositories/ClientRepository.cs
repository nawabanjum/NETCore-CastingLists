﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ClientRepository : IClientRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ClientRepository( IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public async Task<IEnumerable<ClientDTO>> GetClients(GlobalSearchClient searchClient)
        {
            var list = new List<ClientDTO>();

            var FullName = searchClient.Clientname.Split(' ');

            string FirstName = string.Empty;
            string LastName = string.Empty;
            if (FullName!=null)
            {
                FirstName = FullName[0];
                LastName = FullName.Length > 1 ? FullName[1] : string.Empty;
            }

            var param = new DynamicParameters();
            param.Add("@CreatedByUserId", searchClient.CreatedByUserId);
            param.Add("@FirstName", FirstName);
            param.Add("@LastName", LastName);
            var query = @"
                    SELECT *
FROM
(
     SELECT     r.rosterid AS Rosterid,
           r.clientrid AS Clientrid,
           r.status AS Status,
           r.agentrid AS Agentrid,
           r.defphotonum AS Defphotonum,
           r.rostertype AS Rostertype,
           tblactorprofiles.actorsubtype as Subtype,
           tblactorprofiles.actorsubtype as Actorsubtype,
          
           tblclientcount.photonums as Photonums,
           tblAgents.code as Code,
           tblAgents.firstname + ' ' + tblagents.lastname as Agentname,
           tblclients.firstname as Firstname,
           tblclients.middlename as Middlename,
           tblclients.lastname as Lastname,
           isNull(lstServices.isFreemium, 0) as IsFreemium,
           tblactorprofiles.gender as Gender,
           tblclients.Clone_source_id,
		   tblActorprofiles.birthday as BirthDay,
			tblActorprofiles.agefrom as AgeFrom,
			tblActorprofiles.ageto as AgeTo,
			tblActorprofiles.heightFeet as HeightFeet,
			tblActorprofiles.heightinches as HeightInches,
		   r2.AgencyRId AS OriginalAgencyRId ,
		   age2.AgencyRId AS OriginalAgentRId ,
		   age2.company AS CompanyName ,
		   age2.FirstName as AgentFirstName,
		   age2.LastName as AgentLastName
    FROM clients.dbo.tblrosters r WITH (NOLOCK)
        INNER JOIN clients.dbo.tblActorprofiles WITH (NOLOCK)
            ON r.rosterid = tblActorprofiles.rosterrid
        INNER JOIN clients.dbo.tblclients WITH (NOLOCK)
            ON r.clientrid = tblclients.clientid
        INNER JOIN performers.dbo.lstServices WITH (NOLOCK)
            ON lstServices.serviceID = tblclients.serviceRID
        INNER JOIN clients.dbo.tblAgents WITH (NOLOCK)
            ON r.agentrid = tblAgents.agentID
        INNER JOIN clients.dbo.tblclientcount WITH (NOLOCK)
            ON tblclients.clientid = tblclientcount.clientrid
			JOIN [clients]..tblrosters r2 ON r.clone_source_id = r2.clone_source_id
			JOIN [clients]..tblAgents age2 ON r2.agentRId = age2.agentId
    WHERE (r.agentrid = @CreatedByUserId)";
            if (!string.IsNullOrEmpty(searchClient.Clientname) && searchClient.Clientname=="")
            {
                string FirstNamequery = string.Empty;
                string LastNamequery = string.Empty;
                query = query + " AND (";
                if (!string.IsNullOrEmpty(FirstName))
                {
                    FirstNamequery = " tblclients.firstname like '%' + @FirstName + '%' "; 

                }
                if (!string.IsNullOrEmpty(LastName))
                {
                    LastNamequery = FirstName.Length>0 ? " OR tblclients.lastname LIKE  '%' + @LastName + '%' " : " " ;

                }
                query = query + FirstNamequery + LastNamequery + ")";
            }
            query = query + " AND (r.rosterType IN (2,8))  ) rosters_union order by 1 desc";

            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.Clients))
            {
                var result = await conn.QueryAsync<ClientUpdatedDTO>(query, param, commandType: System.Data.CommandType.Text);

                if (result != null && result.Count() > 0)
                {
                    foreach (var item in result)
                    {
                        var obj = new ClientDTO();
                        obj.ActorSubType = item.ActorSubType;
                        obj.AgentFirstName = item.AgentFirstName;
                        obj.AgentLastName = item.AgentLastName;
                        obj.AgentName = item.AgentName;
                        obj.AgentrId = item.AgentrId;
                        if (!string.IsNullOrEmpty(item.AgeFrom) && !string.IsNullOrEmpty(item.AgeTo))
                        {
                            obj.AgeRange = item.AgeFrom + "-" + item.AgeTo;
                        }
                        else if (!string.IsNullOrEmpty(item.AgeFrom))
                        {
                            obj.AgeRange = item.AgeFrom;
                        }
                        else if (!string.IsNullOrEmpty(item.AgeTo))
                        {
                            obj.AgeRange = item.AgeTo;
                        }
                        else
                        {
                            obj.AgeRange = CalculateAge(item.BirthDay).ToString();
                        }
                        obj.Height = item.HeightFeet + "-" + item.HeightInches;
                        obj.IsFreemium = item.IsFreemium;
                        obj.ClientrId = item.ClientrId;
                        obj.Clone_Source_Id = item.Clone_Source_Id;
                        obj.Code = item.Code;
                        obj.CompanyName = item.CompanyName;
                        obj.DefPhotoum = item.DefPhotoum;
                        obj.FirstName = item.FirstName;
                        obj.Gender = item.Gender;
                        obj.IsFreemium = item.IsFreemium;
                        obj.LastName = item.LastName;
                        obj.MiddleName = item.MiddleName;
                        obj.OriginalAgencyRId = item.OriginalAgencyRId;
                        obj.OriginalAgentRId = item.OriginalAgentRId;
                        obj.Photonums = item.Photonums;
                        obj.PictureUrl = item.PictureUrl;
                        obj.RosterId = item.RosterId;
                        obj.RosterType = item.RosterType;
                        obj.Status = item.Status;
                        obj.SubType = item.SubType;
                        list.Add(obj);
                    }
                }
                return list;
            }
        }
        public async Task<IEnumerable<ClientDTO>> GetClientByImdb(string Imdb,int CreatedByUserId)
        {
            var list = new List<ClientDTO>();
            var param = new DynamicParameters();
            param.Add("@CreatedByUserId", CreatedByUserId);
            param.Add("@SearchKey", Imdb);
            var query = @"
            SELECT r.rosterid AS Rosterid,
           r.clientrid AS Clientrid,
           r.status AS Status,
           r.agentrid AS Agentrid,
           r.defphotonum AS Defphotonum,
           r.rostertype AS Rostertype,
           tblactorprofiles.actorsubtype as Subtype,
           tblactorprofiles.actorsubtype as Actorsubtype,
           tblclientcount.photonums as Photonums,
           tblAgents.code as Code,
           tblAgents.firstname + ' ' + tblagents.lastname as Agentname,
           tblclients.firstname as Firstname,
           tblclients.middlename as Middlename,
           tblclients.lastname as Lastname,
           isNull(lstServices.isFreemium, 0) as IsFreemium,
           tblclients.Clone_source_id,
			tblActorprofiles.birthday as BirthDay,
			tblActorprofiles.agefrom as AgeFrom,
			tblActorprofiles.ageto as AgeTo,
			tblActorprofiles.heightFeet as HeightFeet,
			tblActorprofiles.heightinches as HeightInches,
		   r2.AgencyRId AS OriginalAgencyRId ,
		   age2.AgencyRId AS OriginalAgentRId ,
		   age2.company AS CompanyName ,
		   age2.FirstName as AgentFirstName,
		   age2.LastName as AgentLastName
    FROM clients.dbo.tblrosters r WITH (NOLOCK)
        INNER JOIN clients.dbo.tblActorprofiles WITH (NOLOCK)
            ON r.rosterid = tblActorprofiles.rosterrid
        INNER JOIN clients.dbo.tblclients WITH (NOLOCK)
            ON r.clientrid = tblclients.clientid
        INNER JOIN performers.dbo.lstServices WITH (NOLOCK)
            ON lstServices.serviceID = tblclients.serviceRID
        INNER JOIN clients.dbo.tblAgents WITH (NOLOCK)
            ON r.agentrid = tblAgents.agentID
        INNER JOIN clients.dbo.tblclientcount WITH (NOLOCK)
            ON tblclients.clientid = tblclientcount.clientrid
			JOIN [clients]..tblrosters r2 ON r.clone_source_id = r2.clone_source_id
			JOIN [clients]..tblAgents age2 ON r2.agentRId = age2.agentId
    WHERE (r.agentrid = @CreatedByUserId)";
            if (!string.IsNullOrEmpty(Imdb))
            {
                query = query + " AND (r.imdb like '%' + @SearchKey + '%')";
            }
            query = query + " AND (r.rosterType IN (2,8))";

            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.Clients))
            {
                var result = await conn.QueryAsync<ClientUpdatedDTO>(query, param, commandType: System.Data.CommandType.Text);
               
                if (result != null && result.Count()>0)
                {
                    foreach (var item in result)
                    {
                        var obj = new ClientDTO();
                        obj.ActorSubType = item.ActorSubType;
                        obj.AgentFirstName = item.AgentFirstName;
                        obj.AgentLastName = item.AgentLastName;
                        obj.AgentName = item.AgentName;
                        obj.AgentrId = item.AgentrId;
                        if (!string.IsNullOrEmpty(item.AgeFrom) && !string.IsNullOrEmpty(item.AgeTo))
                        {
                            obj.AgeRange = item.AgeFrom + "-" + item.AgeTo;
                        }
                        else if (!string.IsNullOrEmpty(item.AgeFrom))
                        {
                            obj.AgeRange = item.AgeFrom;
                        }
                        else if (!string.IsNullOrEmpty(item.AgeTo))
                        {
                            obj.AgeRange = item.AgeTo;
                        }
                        else
                        {
                            obj.AgeRange = CalculateAge(item.BirthDay).ToString();
                        }
                        obj.Height = item.HeightFeet + "-" + item.HeightInches;
                        obj.IsFreemium = item.IsFreemium;
                        obj.ClientrId = item.ClientrId;
                        obj.Clone_Source_Id = item.Clone_Source_Id;
                        obj.Code = item.Code;
                        obj.CompanyName = item.CompanyName;
                        obj.DefPhotoum = item.DefPhotoum;
                        obj.FirstName = item.FirstName;
                        obj.Gender = item.Gender;
                        obj.IsFreemium = item.IsFreemium;
                        obj.LastName = item.LastName;
                        obj.MiddleName = item.MiddleName;
                        obj.OriginalAgencyRId = item.OriginalAgencyRId;
                        obj.OriginalAgentRId = item.OriginalAgentRId;
                        obj.Photonums = item.Photonums;
                        obj.PictureUrl = item.PictureUrl;
                        obj.RosterId = item.RosterId;
                        obj.RosterType = item.RosterType;
                        obj.Status = item.Status;
                        obj.SubType = item.SubType;
                        list.Add(obj);
                    }
                }
                return list;
            }
        }
        private static int CalculateAge(DateTime dateOfBirth)
        {
            int age = 0;
            age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
                age = age - 1;

            return age;
        }
    }
}

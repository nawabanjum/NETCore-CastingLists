﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardContactsRepository : IActorCardContactsRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorCardContactsRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorCard_Contacts AddActorCardContact(tblActorCard_Contacts c)
        {
            _context.TblActorCard_Contacts.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCardContact(int id)
        {
            var model = _context.TblActorCard_Contacts.Where(a => a.ActrorCard_ContactsId == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorCard_Contacts> Get(int CastingList_ActorId)
        {
            return _context.TblActorCard_Contacts.Where(a => a.ActorCardRId == CastingList_ActorId);
        }
        public tblActorCard_Contacts GetById(int id)
        {
            return _context.TblActorCard_Contacts.Where(a => a.ActrorCard_ContactsId == id).FirstOrDefault();
        }
        public tblActorCard_Contacts UpdateActorCardContact(tblActorCard_Contacts c)
        {
            _context.TblActorCard_Contacts.Update(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateActorCardContactSortOrder(List<ActorSortDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    query = query + $"Update tblActorCard_Contacts SET  SortOrder={item.SortOrder} WHERE ActrorCard_ContactsId={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
        public void UpdateActorCardContactStatus(List<ActorStatusDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    int status = Convert.ToInt32(item.IsHidden);
                    query = query + $"Update tblActorCard_Contacts SET  IsHidden={status} WHERE ActrorCard_ContactsId={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class KnowsForRepository : IKnowsForRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public KnowsForRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblKnowsFor AddKnowsFor(tblKnowsFor c)
        {
            _context.TblKnowsFors.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteKnowsFor(int id)
        {
            var model = _context.TblKnowsFors.Find(id);
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public void DeleteKnowsForByActorId(int Actorid)
        {
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                var param = new DynamicParameters();
                param.Add("@Actorid", Actorid);
                var sqlStatement = "Delete FROM tblKnowsFor WHERE ActorRId=@Actorid";
                conn.Execute(sqlStatement, param);
            }
        }
        public IEnumerable<tblKnowsFor> GetKnowsForByActorId(int Actorid)
        {
            return _context.TblKnowsFors.Where(a => a.ActorRId == Actorid).ToList();
        }
        public tblKnowsFor GetKnowsForById(int id)
        {
            return _context.TblKnowsFors.Find(id);
        }
        public tblKnowsFor UpdateKnowsFor(tblKnowsFor c)
        {
            _context.TblKnowsFors.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

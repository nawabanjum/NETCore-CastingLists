﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ProjectRepository : IProjectRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ProjectRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
            _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan);
        }
        public tblProjectList  AddProject(tblProjectList  c)
        {
            _context.lstProject.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteProject(int id, int userid, int usertype)
        {
            var model = _context.lstProject.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ProjectId == id).FirstOrDefault();
            if (model !=null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblProjectList> Get(int userid, int usertype)
        {
            return _context.lstProject.Where(a=>a.CreatedByUserId== userid && a.CreatedByUserType== usertype).ToList();
        }
        public tblProjectList  GetProjectById(int id, int userid, int usertype)
        {
            return _context.lstProject.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ProjectId == id).FirstOrDefault();
        }
        public tblProjectList GetById(int id)
        {
            return _context.lstProject.Where(a => a.ProjectId == id).FirstOrDefault();
        }
        public tblProjectList UpdateProject(tblProjectList  c)
        {
            _context.lstProject.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

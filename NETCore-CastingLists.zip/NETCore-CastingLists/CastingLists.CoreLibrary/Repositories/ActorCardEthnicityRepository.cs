﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardEthnicityRepository : IActorCardEthnicityRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorCardEthnicityRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public tblActorCardEthnicity AddActorCardEthnicity(tblActorCardEthnicity c)
        {
            _context.TblCastingListEthnicities.Add(c);
            _context.SaveChanges();
            return c;
        }

        public void DeleteActorCardEthnicity(int id)
        {
            var model = _context.TblCastingListEthnicities.Where(a => a.ActorCard_EthnicityId == id).FirstOrDefault();
            if (model !=null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }

        public IEnumerable<tblActorCardEthnicity> Get(int CastingList_ActorId)
        {
            return _context.TblCastingListEthnicities.Where(a => a.ActorCardRId == CastingList_ActorId).ToList();
        }

        public tblActorCardEthnicity GetById(int id)
        {
            return _context.TblCastingListEthnicities.Where(a => a.ActorCard_EthnicityId == id).FirstOrDefault();
        }

        public tblActorCardEthnicity UpdateActorCardEthnicity(tblActorCardEthnicity c)
        {
            _context.TblCastingListEthnicities.Update(c);
            _context.SaveChanges();
            return c;
        }
        public void UpdateActorCardEthnicitySortOrder(List<ActorSortDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    query = query + $"Update tblActorCardEthnicity SET  SortOrder={item.SortOrder} WHERE ActorCard_EthnicityId={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }

        }
        public void UpdateActorCardEthnicityStatus(List<ActorStatusDTO> dto)
        {
            if (dto != null && dto.Count() > 0)
            {
                string query = string.Empty;

                foreach (var item in dto)
                {
                    int status = Convert.ToInt32(item.IsHidden);
                    query = query + $"Update tblActorCardEthnicity SET  IsHidden={status} WHERE ActorCard_EthnicityId={item.Id};  ";
                }

                using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
                {
                    conn.ExecuteScalar(query, null, commandType: System.Data.CommandType.Text);
                }
            }
        }
    }
}

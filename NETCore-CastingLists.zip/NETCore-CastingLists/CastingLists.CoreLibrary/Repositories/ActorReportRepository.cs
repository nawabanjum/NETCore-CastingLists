﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorReportRepository : IActorReportRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public ActorReportRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public async Task<List<Dictionary<object, object>>> ActorList(GlobalSearchActorImdb c)
        {
            List<int> lists = new List<int>();
            if (c.ActorRoles !=null && c.ActorRoles.Count()>0)
            {
                foreach (var item in c.ActorRoles)
                {
                    lists.Add(item.RoleId);
                }
            }
            
            var roleIds = string.Join(",", lists);
            ActorReportDTO ActorReportDTO = new ActorReportDTO();
            var param = new DynamicParameters();
            param.Add("@ListId", c.ListId);
            var query = @$"SELECT Id,
		                         ISNULL(DisplayName,'') AS DisplayName,
		                         RoleRId ,
		                         ProjectRId,
		                         ListRId,
		                         ISNULL(Notes,'') AS Notes,
		                         ISNULL(BOD,GETDATE()) AS BOD,
		                         ISNULL(AgeRange,'') AS AgeRange,
		                         GenderRId,
		                         ISNULL(HeightFeet,'') AS HeightFeet,
		                         ISNULL(HeightInches,'') AS HeightInches,
		                         MasterCast_ClientId,
		                         MasterCast_RosterId,
		                         CastingList_IMDBActorId,
		                         CreatedByUserId,
		                         CreatedByUserType,
		                         ISNULL(CreatedOn,GETDATE()) AS CreatedOn,
		                         ISNULL(LastUpdatedDate,GETDATE()) AS LastUpdatedDate,
		                         ISNULL(IsHidden,0) AS IsHidden,
		                         ISNULL(SortOrder,0) AS SortOrder
                            FROM [dbo].[tblActorCard] WITH(NOLOCK) Where RoleRId IN ({roleIds}) And ListRId=@ListId";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {

                ActorReportDTO.ActorCard = conn.Query<ActorCardDTO>(query, param, commandType: System.Data.CommandType.Text).ToList();

                if (c.IsKnowsFor)
                {
                    var queryKnowsfor = @$"SELECT 
			                                    kn.ActorCard_KnowsForId,
			                                    ISNULL(kn.Title,'') AS Title,
			                                    ISNULL(kn.Link,'') AS  Link,
			                                    kn.ActorCardRId,
			                                    ISNULL(kn.CreatedOn,GETDATE()) AS CreatedOn,
			                                    ISNULL(kn.IsHidden,0) AS IsHidden,
			                                    ISNULL(kn.ModifiedOn,'') AS ModifiedOn,
			                                    kn.OriginalImdbKnowsForRId,
			                                    ISNULL(kn.SortOrder,0) AS SortOrder
	                                    FROM [dbo].[tblActorCard_KnowsFor] kn
	                                    JOIN  [dbo].[tblActorCard] ca ON ca.Id=kn.ActorCardRId
	                                    Where ca.ListRId=@ListId  And ca.RoleRId IN({roleIds})";
                    ActorReportDTO.ActorCardKnows = conn.Query<ActorCardKnowsForDTO>(queryKnowsfor, param, commandType: System.Data.CommandType.Text).ToList();

                }
                if (c.IsContact)
                {
                    var queryActorContact = @$"SELECT  
	                                            ac.ActrorCard_ContactsId,
	                                            ISNULL(ac.ContactType,'') AS ContactType,
	                                            ISNULL(ac.ContactName,'') AS ContactName,
	                                            ISNULL(ac.ContactCompany,'') AS ContactName,
	                                            ISNULL(ac.ContactEmail,'') AS ContactEmail,
	                                            ISNULL(ac.ContactPhone,'') AS ContactPhone,
	                                            ac.ActorCardRId,
	                                            ISNULL(ac.CreatedOn,GETDATE()) AS CreatedOn,
	                                            ISNULL(ac.LastUpdatedDate,GETDATE()) AS LastUpdatedDate,
	                                            ISNULL(ac.IsHidden,0) AS IsHidden,
	                                            ISNULL(ac.SortOrder,0) AS SortOrder,
	                                            ac.OriginalImdbContactRId
	                                    FROM [dbo].[tblActorCard_Contacts] ac
	                                    JOIN  [dbo].[tblActorCard] ca ON ca.Id=ac.ActorCardRId
	                                    WHERE ca.ListRId=@ListId AND RoleRId IN ({roleIds})";
                    ActorReportDTO.ActorContacts = conn.Query<ActorCardContactsDTO>(queryActorContact, param, commandType: System.Data.CommandType.Text).ToList();
                }
                if (c.IsEthnicity)
                {
                    var queryActorEthnicity = @$"SELECT 
	                                                  et.ActorCard_EthnicityId,
	                                                  et.EthnicityRId,
	                                                  et.ActorCardRId,
	                                                  ISNULL(et.CreatedOn,GETDATE()) AS CreatedOn,
	                                                  ISNULL(et.IsHidden,0) AS IsHidden,
	                                                  ISNULL(et.SortOrder,0) AS SortOrder
	                                            FROM [dbo].[tblActorCardEthnicity] et
	                                            JOIN  [dbo].[tblActorCard] ca ON ca.Id=et.ActorCardRId
	                                            WHERE ca.ListRId=@ListId AND RoleRId IN ({roleIds})";
                    ActorReportDTO.CastingListEthnicities = conn.Query<ActorCardEthnicityDTO>(queryActorEthnicity, param, commandType: System.Data.CommandType.Text).ToList();
                }
                if (c.ActorRoles !=null && c.ActorRoles.Count()>0)
                {
                    var queryActorRoles = @$"SELECT 
                                                rl_Id AS RoleId,
                                                ISNULL (rl_Name,'') AS RoleName 
                                             FROM [dbo].[role] WHERE rl_id IN ({roleIds})";
                    ActorReportDTO.ActorRoles = conn.Query<ActroRoleDTO>(queryActorRoles, commandType: System.Data.CommandType.Text).ToList();

                }

                return ListByActor(ActorReportDTO, c);
            }


        }
        private List<Dictionary<object, object>> ListByActor(ActorReportDTO dto, GlobalSearchActorImdb c)
        {
            List<Dictionary<object, object>> keyValuePairs = new List<Dictionary<object, object>>();

            var distinctIds = dto.ActorCard.Select(a => a.Id).Distinct();
            foreach (var item in distinctIds)
            {
                dynamic actors = new List<dynamic>();
                Dictionary<object, object> distObj = new Dictionary<object, object>();
                var sigleactor = dto.ActorCard.Where(a => a.Id == item).FirstOrDefault();
                if (sigleactor != null)
                {
                    dynamic actorDetail = new ExpandoObject();

                    if (c.IsHeight)
                    {
                        actorDetail.HeightFeet = sigleactor.HeightFeet;
                        actorDetail.HeightInches = sigleactor.HeightInches;
                    }
                    if (c.IsNotes)
                    {
                        actorDetail.Notes = sigleactor.Notes;
                    }
                    if (c.IsPlayage)
                    {
                        actorDetail.AgeRange = sigleactor.AgeRange;
                    }
                    if (c.IsGenender)
                    {
                        actorDetail.GenderRId = sigleactor.GenderRId;
                    }
                    actorDetail.BOD = sigleactor.BOD;
                    actorDetail.CastingList_IMDBActorId = sigleactor.CastingList_IMDBActorId;
                    actorDetail.CreatedByUserId = sigleactor.CreatedByUserId;
                    actorDetail.CreatedByUserType = sigleactor.CreatedByUserType;
                    actorDetail.CreatedOn = sigleactor.CreatedOn;
                    actorDetail.DisplayName = sigleactor.DisplayName;
                    
                    actorDetail.Id = sigleactor.Id;
                    actorDetail.IsHidden = sigleactor.IsHidden;
                    actorDetail.LastUpdatedDate = sigleactor.LastUpdatedDate;
                    actorDetail.ListRId = sigleactor.ListRId;
                    actorDetail.MasterCast_ClientId = sigleactor.MasterCast_ClientId;
                    actorDetail.MasterCast_RosterId = sigleactor.MasterCast_RosterId;
                    actorDetail.ProjectRId = sigleactor.ProjectRId;
                    actorDetail.RoleRId = sigleactor.RoleRId;
                    actorDetail.SortOrder = sigleactor.SortOrder;

                    actors.Add(actorDetail);
                    distObj.Add("Actor", actors);

                    if (c.IsKnowsFor)
                    {
                        var knowsFor = dto.ActorCardKnows.Where(a => a.ActorCardRId == item).ToList();
                        distObj.Add("KnowsFor", knowsFor);
                    }
                    if (c.IsContact)
                    {
                        var ActorCntacts = dto.ActorContacts.Where(a => a.ActorCardRId == item).ToList();
                        distObj.Add("ActorCntacts", ActorCntacts);
                    }
                    if (c.IsEthnicity)
                    {
                        var Ethnicities = dto.CastingListEthnicities.Where(a => a.ActorCardRId == item).ToList();
                        distObj.Add("Ethnicities", Ethnicities);
                    }
                    if (c.ActorRoles !=null && c.ActorRoles.Count()>0)
                    {
                        var ActorRoles = dto.ActorRoles.ToList();
                        distObj.Add("ActorRoles", ActorRoles);
                    }
                }

                keyValuePairs.Add(distObj);
            }
            return keyValuePairs;
        }
    }
}


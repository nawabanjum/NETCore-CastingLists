﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardReportExportsRepository : IActorCardReportExportsRepository
    {
        private readonly ProjectManContext _context;
        public ActorCardReportExportsRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblActorCardExports AddActorCardReportExport(tblActorCardExports c)
        {
            _context.TblCastListReportExports.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCardReportExport(int id)
        {
            var model = _context.TblCastListReportExports.Where(a => a.Id == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblActorCardExports> Get(int UserId, int UserType)
        {
            return _context.TblCastListReportExports.Where(a => a.CreatedByUserId == UserId && a.CreatedByUserType == UserType);
        }
        public tblActorCardExports GetActorCardReportExportById(int id, int UserId, int UserType)
        {
            return _context.TblCastListReportExports.Where(a => a.Id == id && a.CreatedByUserId == UserId && a.CreatedByUserType == UserType).FirstOrDefault();
        }
        public IEnumerable<tblActorCardExports> GetActorCardReportExportByListId(int ListId, int UserId, int UserType)
        {
            return _context.TblCastListReportExports.Where(a => a.CreatedByUserId == UserId && a.CreatedByUserType == UserType && a.ListId == ListId);
        }
        public tblActorCardExports GetById(int id)
        {
            return _context.TblCastListReportExports.Where(a => a.Id == id).FirstOrDefault();
        }
        public tblActorCardExports UpdateActorCardReportExport(tblActorCardExports c)
        {
            _context.TblCastListReportExports.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

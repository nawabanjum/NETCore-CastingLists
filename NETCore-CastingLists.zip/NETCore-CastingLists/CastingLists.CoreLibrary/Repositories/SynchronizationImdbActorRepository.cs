﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class SynchronizationImdbActorRepository : ISynchronizationImdbActorRepository
    {
        private readonly ProjectManContext _context;
        public SynchronizationImdbActorRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblSynchronizationImdbActors AddSynchronizationImdbActor(tblSynchronizationImdbActors c)
        {
            _context.TblSynchronizationImdbActors.Add(c);
            _context.SaveChanges();
            return c;
        }
        public IEnumerable<tblSynchronizationImdbActors> GetSynchronizationImdbActorByListId(int ListId, int UserId, int UserType)
        {
          return   _context.TblSynchronizationImdbActors.Where(a => a.ListRId == ListId && a.CreatedByUserId == UserId && a.CreatedByUserType==UserType);
        }
    }
}

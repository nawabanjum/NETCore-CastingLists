﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IListRepository
    {
        IEnumerable<tblList> Get(int userid, int usertype, int projectid);
        tblList GetListyId(int id);

        tblList AddList(tblList c);
        void UpdateList(tblList c);

        void DeleteList(int id);
        bool CheckProjectExistance(int userid, int createdByUserType, int projectId);
    }
}

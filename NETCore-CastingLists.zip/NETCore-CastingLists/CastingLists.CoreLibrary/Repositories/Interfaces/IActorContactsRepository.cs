﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorContactsRepository
    {
        IEnumerable<tblActorContacts> GetActorContactByActorId(int Actorid);
        tblActorContacts GetActorContactById(int id);

        tblActorContacts AddActorContact(tblActorContacts c);
        tblActorContacts UpdateActorContact(tblActorContacts c);

        void DeleteActorContact(int id);
        void DeleteActorContactByActorId(int Actorid);
    }
}

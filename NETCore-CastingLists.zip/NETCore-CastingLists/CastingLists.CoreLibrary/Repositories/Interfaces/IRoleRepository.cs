﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
   public interface IRoleRepository
    {
        IEnumerable<tblRoles> Get(int userid, int usertype,int projectid);
        tblRoles GetRoleById(int id,int userid, int usertype);
        tblRoles GetById(int id);

        tblRoles AddRole(tblRoles c);
        void UpdateRole(tblRoles c);

        void DeleteRole(int id, int userid, int usertype);
        IEnumerable<ActroRoleDTO> ValidateRoles(List<ActorRoles> list);
    }
}

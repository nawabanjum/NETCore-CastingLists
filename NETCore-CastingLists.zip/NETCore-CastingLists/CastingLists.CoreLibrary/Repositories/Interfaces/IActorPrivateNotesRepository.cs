﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorPrivateNotesRepository
    {
        IEnumerable<tblActorPriveNotes> Get(int userid, int usertype, int actorid);
        tblActorPriveNotes GeActorPrivateNotesById(int id, int userid, int usertype);
        tblActorPriveNotes AddActorPrivateNotes(tblActorPriveNotes c);
        tblActorPriveNotes UpdateActorPrivateNotes(tblActorPriveNotes c);
        void DeleteActorPrivateNotes(int id, int userid, int usertype);
    }
}

﻿using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IFilmographyRepository
    {
        IEnumerable<tblFilmographyImdb> GetFilmographyByActorId(int Actorid);
        tblFilmographyImdb GetFilmographyById(int id);

        tblFilmographyImdb AddFilmography(tblFilmographyImdb c);
        tblFilmographyImdb UpdateFilmography(tblFilmographyImdb c);

        void DeleteFilmography(int id);
    }
}

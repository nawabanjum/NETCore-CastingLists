﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardVideoRepository
    {
        IEnumerable<tblActorCardVideos> Get(int CastingList_ActorRId);
        tblActorCardVideos GetById(int id);
        tblActorCardVideos AddActorCardVideo(tblActorCardVideos c);
        tblActorCardVideos UpdateActorCardVideo(tblActorCardVideos c);
        void DeleteActorCardVideo(int id);
        void UpdateActorCardVideoSortOrder(List<ActorSortDTO> dto);
        void UpdateActorCardVideoStatus(List<ActorStatusDTO> dto);

    }
}

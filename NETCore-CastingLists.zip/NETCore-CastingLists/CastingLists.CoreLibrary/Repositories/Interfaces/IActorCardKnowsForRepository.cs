﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardKnowsForRepository
    {
        IEnumerable<tblActorCard_KnowsFor> Get(int CastingList_ActorId);
        tblActorCard_KnowsFor GetById(int id);
        tblActorCard_KnowsFor AddActorCardKnowsFor(tblActorCard_KnowsFor c);
        tblActorCard_KnowsFor UpdateActorCardKnowsFor(tblActorCard_KnowsFor c);
        void DeleteActorCardKnowsFor(int id);
        void UpdateActorCardKnowsForSortOrder(List<ActorSortDTO> dto);
        void UpdateActorCardKnowsForStatus(List<ActorStatusDTO> dto);

    }
}

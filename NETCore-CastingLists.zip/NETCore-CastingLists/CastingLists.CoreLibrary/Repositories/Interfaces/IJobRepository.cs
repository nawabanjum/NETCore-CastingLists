﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
 public   interface IJobRepository
    {
        Task<IEnumerable<JobDTO>> GetAvailableJob(int agencyId, bool projectDirector);
    }
}

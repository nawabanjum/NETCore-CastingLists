﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorImdbArchiveRepository
    {
        //IEnumerable<ActorImdbArchiveDTO> Get(int userid, int usertype, int projectid);
        //tblActorImdbArchive GeActorImdbById(int id, int userid, int usertype);
        tblActorImdbArchive AddActorImdb(tblActorImdbArchive c);
        //void UpdateActorImdb(tblActorImdbArchive c);
        //void DeleteActorImdb(int id, int userid, int usertype);
    }
}

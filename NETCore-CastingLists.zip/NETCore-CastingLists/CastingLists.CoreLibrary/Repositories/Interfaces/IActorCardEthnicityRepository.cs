﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardEthnicityRepository
    {
        IEnumerable<tblActorCardEthnicity> Get(int CastingList_ActorId);
        tblActorCardEthnicity GetById(int id);
        tblActorCardEthnicity AddActorCardEthnicity(tblActorCardEthnicity c);
        tblActorCardEthnicity UpdateActorCardEthnicity(tblActorCardEthnicity c);
        void DeleteActorCardEthnicity(int id);
        void UpdateActorCardEthnicitySortOrder(List<ActorSortDTO> dto);
        void UpdateActorCardEthnicityStatus(List<ActorStatusDTO> dto);
    }
}

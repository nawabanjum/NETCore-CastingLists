﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface ISocialLinkRepository
    {
        IEnumerable<tblSocialLinks> GetSocialLinkByActorId(int Actorid);
        tblSocialLinks GetSocialLinkById(int id);

        tblSocialLinks AddSocialLink(tblSocialLinks c);
        tblSocialLinks UpdateSocialLink(tblSocialLinks c);

        void DeleteSocialLink(int id);
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IClientRepository
    {
        Task<IEnumerable<ClientDTO>> GetClients(GlobalSearchClient searchClient);
        Task<IEnumerable<ClientDTO>> GetClientByImdb(string Imdb,  int CreatedByUserId);
    }
}

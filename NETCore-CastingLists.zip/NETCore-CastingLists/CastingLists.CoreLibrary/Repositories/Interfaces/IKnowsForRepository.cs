﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IKnowsForRepository
    {
        IEnumerable<tblKnowsFor> GetKnowsForByActorId(int Actorid);
        tblKnowsFor GetKnowsForById(int id);

        tblKnowsFor AddKnowsFor(tblKnowsFor c);
        tblKnowsFor UpdateKnowsFor(tblKnowsFor c);

        void DeleteKnowsFor(int id);
        void DeleteKnowsForByActorId(int Actorid);
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
   public interface IActorRepository
    {
        IEnumerable<tblActorImdb> Get(int UserId, int UserType);
        IEnumerable<tblActorImdb> SearchActorByName(string SearchText);
        tblActorImdb GetActorById(int id, int UserId, int UserType);
        tblActorImdb GetById(int id);
        tblActorImdb GetActorByImdbId(string ImdbId);

        tblActorImdb AddActor(tblActorImdb c);
        tblActorImdb UpdateActor(tblActorImdb c);

        void DeleteActor(int id, int UserId, int UserType);
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardPrivateNoteRepository
    {
        IEnumerable<tblActorCard_PrivateNote> Get(int CastingList_ActorId);
        tblActorCard_PrivateNote GetById(int id);
        tblActorCard_PrivateNote AddActorCardPrivateNote(tblActorCard_PrivateNote c);
        tblActorCard_PrivateNote UpdateActorCardPrivateNote(tblActorCard_PrivateNote c);
        void DeleteActorCardPrivateNote(int id);
        void updateActorCardPrivateNoteSortOrder(List<ActorSortDTO> dto);
        void UpdateActorCardPrivateNoteStatus(List<ActorStatusDTO> dto);

    }
}

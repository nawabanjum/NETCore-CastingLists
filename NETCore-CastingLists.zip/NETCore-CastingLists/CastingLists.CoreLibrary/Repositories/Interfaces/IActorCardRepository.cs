﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardRepository
    {
        IEnumerable<tblActorCard> Get(int UserId, int UserType);
        IEnumerable<tblActorCard> GetActorCardByListId(int ListId, int UserId, int UserType);
        tblActorCard GetActorCardById(int id, int UserId, int UserType);
        tblActorCard GetById(int id);

        tblActorCard AddActorCard(tblActorCard c);
        tblActorCard UpdateActorCard(tblActorCard c);
        IEnumerable<tblActorCard> ValidateActor(ValidateActorDTO c);
        void DeleteActorCard(int id, int UserId, int UserType);
        void UpdateActorCardSortOrder(List<ActorSortDTO> dto);
        void UpdateActorCardStatus(List<ActorStatusDTO> dto);
        void AddActorCardsByNewList(int NewListId, int ParentListId);
    }
}

﻿using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardReportExportsRepository
    {
        IEnumerable<tblActorCardExports> Get(int UserId, int UserType);
        tblActorCardExports GetActorCardReportExportById(int id, int UserId, int UserType);
        IEnumerable<tblActorCardExports> GetActorCardReportExportByListId(int ListId, int UserId, int UserType);
        tblActorCardExports GetById(int id);
        tblActorCardExports AddActorCardReportExport(tblActorCardExports c);
        tblActorCardExports UpdateActorCardReportExport(tblActorCardExports c);
        void DeleteActorCardReportExport(int id);
    }
}

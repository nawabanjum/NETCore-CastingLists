﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IProjectRepository
    {
        IEnumerable<tblProjectList> Get(int userid, int usertype);
        tblProjectList  GetProjectById(int id, int userid, int usertype);
        tblProjectList GetById(int id);

        tblProjectList  AddProject(tblProjectList  c);
        tblProjectList UpdateProject(tblProjectList  c);

        void DeleteProject(int id, int userid, int usertype);
    }
}

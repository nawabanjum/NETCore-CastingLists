﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface IActorCardContactsRepository
    {
        IEnumerable<tblActorCard_Contacts> Get(int CastingList_ActorId);
        tblActorCard_Contacts GetById(int id);
        tblActorCard_Contacts AddActorCardContact(tblActorCard_Contacts c);
        tblActorCard_Contacts UpdateActorCardContact(tblActorCard_Contacts c);
        void DeleteActorCardContact(int id);
        void UpdateActorCardContactSortOrder(List<ActorSortDTO> dto);
        void UpdateActorCardContactStatus(List<ActorStatusDTO> dto);

    }
}

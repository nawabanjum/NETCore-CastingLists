﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface ILookupRepository
    {
        IEnumerable<CommonLookUpDTO> GetProjectTypeList();
        IEnumerable<CommonLookUpDTO> GetProjectsSourceList();
        IEnumerable<CommonLookUpDTO> GetProjectsLookup(int userid, int usertype);
        IEnumerable<CommonLookUpDTO> GetListLookup(int userid, int usertype, int projectid);
        IEnumerable<CommonLookUpDTO> GetRolesLookup(int userid, int usertype,int projectid);
        IEnumerable<CommonLookUpDTO> GetGenderTypeLookup();
        IEnumerable<CommonLookUpDTO> GetEthnicitiesLookup();
        IEnumerable<FilmographyDTO> GetFilmographyLookup(string Imdbd);
        
    }
}

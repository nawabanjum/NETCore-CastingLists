﻿using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories.Interfaces
{
    public interface ISynchronizationImdbActorRepository
    {
        IEnumerable<tblSynchronizationImdbActors> GetSynchronizationImdbActorByListId(int ListId, int UserId, int UserType);
        tblSynchronizationImdbActors AddSynchronizationImdbActor(tblSynchronizationImdbActors c);
    }
}

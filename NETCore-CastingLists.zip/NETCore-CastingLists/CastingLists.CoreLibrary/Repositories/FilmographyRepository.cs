﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class FilmographyRepository : IFilmographyRepository
    {
        private readonly ProjectManContext _context;
        public FilmographyRepository(ProjectManContext context)
        {
            _context = context;
        }
        public tblFilmographyImdb AddFilmography(tblFilmographyImdb c)
        {
            _context.TblFilmographyImdbs.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteFilmography(int id)
        {
            var model = _context.TblFilmographyImdbs.Find(id);
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
        public IEnumerable<tblFilmographyImdb> GetFilmographyByActorId(int Actorid)
        {
            return _context.TblFilmographyImdbs.Where(a => a.ActorRId == Actorid);
        }
        public tblFilmographyImdb GetFilmographyById(int id)
        {
            return _context.TblFilmographyImdbs.Where(a => a.FilmographyId == id).FirstOrDefault(); ;
        }
        public tblFilmographyImdb UpdateFilmography(tblFilmographyImdb c)
        {
            _context.TblFilmographyImdbs.Update(c);
            _context.SaveChanges();
            return c;
        }
    }
}

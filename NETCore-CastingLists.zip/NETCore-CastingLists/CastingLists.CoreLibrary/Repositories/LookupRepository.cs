﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class LookupRepository : ILookupRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public LookupRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }
        public IEnumerable<CommonLookUpDTO> GetProjectsSourceList()
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var list = _context.LstProjectListSources.ToList();
            dtolist = (from item in list
                       select new CommonLookUpDTO
                       {
                           Id = item.SourceId,
                           Title = item.SourceTitle
                       }).ToList();
            return dtolist;
        }
        public IEnumerable<CommonLookUpDTO> GetProjectTypeList()
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var list = _context.LstProjectListTypes.ToList();
            dtolist = (from item in list
                       select new CommonLookUpDTO
                       {
                           Id = item.TypeId,
                           Title = item.TypeTitle
                       }).ToList();
            return dtolist;
        }
        public IEnumerable<CommonLookUpDTO> GetRolesLookup(int userid, int usertype, int projectid)
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var list = _context.TblRoles.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ProjectRId == projectid).ToList();
            dtolist = (from item in list
                       select new CommonLookUpDTO
                       {
                           Id = item.ProjectRId,
                           Title = item.RoleTitle
                       }).ToList();
            return dtolist;
        }
        public IEnumerable<CommonLookUpDTO> GetListLookup(int userid, int usertype, int projectid)
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var list = _context.tblList.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype && a.ProjectRId == projectid).ToList();
            dtolist = (from item in list
                       select new CommonLookUpDTO
                       {
                           Id = item.ListId,
                           Title = item.ListName
                       }).ToList();
            return dtolist;
        }
        public IEnumerable<CommonLookUpDTO> GetProjectsLookup(int userid, int usertype)
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var list = _context.lstProject.Where(a => a.CreatedByUserId == userid && a.CreatedByUserType == usertype).ToList();
            dtolist = (from item in list
                       select new CommonLookUpDTO
                       {
                           Id = item.ProjectId,
                           Title = item.ProjectTitle
                       }).ToList();
            return dtolist;
        }
        public IEnumerable<CommonLookUpDTO> GetGenderTypeLookup()
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var query = @"SELECT TOP 100 * FROM [clients]..lstGenderTypes";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.Clients))
            {
                var result = conn.Query<GenderTypeDTO>(query, commandType: System.Data.CommandType.Text);
                dtolist = (from item in result
                           select new CommonLookUpDTO
                           {
                               Id = item.gendertypeID,
                               Title = item.gendertype
                           }).ToList();
                return dtolist;
            }
        }
        public IEnumerable<CommonLookUpDTO> GetEthnicitiesLookup()
        {
            List<CommonLookUpDTO> dtolist = new List<CommonLookUpDTO>();
            var query = @"SELECT TOP 100 * FROM [clients]..lstethnicities";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.Clients))
            {
                var result = conn.Query<EthnicitiesDTO>(query, commandType: System.Data.CommandType.Text);
                dtolist = (from item in result
                           select new CommonLookUpDTO
                           {
                               Id = item.serial,
                               Title = item.description
                           }).ToList();
                return dtolist;
            }
        }
        public IEnumerable<FilmographyDTO> GetFilmographyLookup(string Imdbd)
        {
            var param = new DynamicParameters();
            param.Add("@ImdbId", Imdbd);
            List<FilmographyDTO> dtolist = new List<FilmographyDTO>();
            var query = @"Select * from tblFilmographyImdb WHERE ImdbId LIKE '%' + @ImdbId+'%'";
            using (var conn = _dataConnector.GetOpenConnection(DbConnectionType.ProjectMan))
            {
                var result = conn.Query<FilmographyDTO>(query, param, commandType: System.Data.CommandType.Text);
                dtolist = (from item in result
                           select new FilmographyDTO
                           {
                               ActorRId = item.ActorRId,
                               CreatedOn = item.CreatedOn,
                               EndYear = item.EndYear,
                               FilmographyId = item.FilmographyId,
                               FullDescription = item.FullDescription,
                               ImdbId = item.ImdbId,
                               IsDeleted = item.IsDeleted,
                               LastUpdatedDate = item.LastUpdatedDate,
                               Link = item.Link,
                               StartYear = item.StartYear,
                               Title = item.Title
                           }).ToList();
                return dtolist;
            }
        }
    }
}

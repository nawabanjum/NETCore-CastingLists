﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class ActorCardImageRepository : IActorCardImageRepository
    {
        private readonly ProjectManContext _context;
        public ActorCardImageRepository(ProjectManContext projectManContext)
        {
            _context = projectManContext;
        }
        public tblActorCardImages AddActorCardImage(tblActorCardImages c)
        {
            _context.TblActorCardImages.Add(c);
            _context.SaveChanges();
            return c;
        }
        public void DeleteActorCardImage(int id)
        {
            var model = _context.TblActorCardImages.Where(a => a.Id == id).FirstOrDefault();
            if (model != null)
            {
                _context.Remove(model);
                _context.SaveChanges();
            }
        }
    }
}

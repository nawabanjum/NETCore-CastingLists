﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using Core5SharedLibrary;
using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Repositories
{
    public class JobRepository : IJobRepository
    {
        private readonly IDataConnector _dataConnector;
        private readonly ProjectManContext _context;
        public JobRepository(IDataConnector dataConnector, ProjectManContext context)
        {
            _dataConnector = dataConnector;
            _context = context;
        }    
        public async Task<IEnumerable<JobDTO>> GetAvailableJob(int agencyId, bool projectDirector)
        {
            var param = new DynamicParameters();
           param.Add("@agencyId", agencyId);
            var query = @"
                    SELECT
	                 IPK As Id,
					cJobTitle AS JobTitle,
					cAltTitle As AltTitlem,
					agencyId As AgencyID,
					IsProjectDirector 
                    FROM
	                    [dbo].[lstJob]
                    WHERE
	                    @agencyId  =CASE WHEN (@agencyId IS NULL OR  @agencyId=0)  THEN @agencyId ELSE agencyId END;
                    ";

            using (var conn = _dataConnector.GetOpenConnection())
            {
                var result = await conn.QueryAsync<JobDTO>(query, param, commandType: System.Data.CommandType.Text);
                return result;
            }
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ListService : IListService
    {
        private readonly IListRepository _listRepository;
        private readonly IProjectService _projectService;
        private readonly IActorCardRepository _actorCardRepository;

        public ListService(IActorCardRepository actorCardRepository, IListRepository listRepository, IProjectService projectService)
        {
            _listRepository = listRepository;
            _projectService = projectService;
            _actorCardRepository = actorCardRepository;
        }
        public ServiceResponse Add(ListDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var exist = _projectService.GetById(c.ProjectId, c.CreatedByUserId, c.CreatedByUserType);
                if (exist == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblList model = new tblList();
                model = DTOToEntity(c);
                _listRepository.AddList(model);

                if (c.ParentListId !=null && c.ParentListId>0)
                {
                  
                    _actorCardRepository.AddActorCardsByNewList(model.ListId, c.ParentListId.Value);
                }
                aPIResponse.Id = model.ListId;

            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public void Delete(int id)
        {
            var model = _listRepository.GetListyId(id);
            if (model != null)
            {
                model.IsActive = false;
            }
            _listRepository.UpdateList(model);
            //_listRepository.DeleteList(id);
        }
        public IEnumerable<ListDTO> Get(int userid, int usertype, int projectid)
        {
            var list = _listRepository.Get(userid, usertype, projectid);
            List<ListDTO> dtolist = new List<ListDTO>();
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    var obj = new ListDTO();
                    obj = EntityToDTO(item);
                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }
        public ListDTO GetById(int id)
        {
            ListDTO model = new ListDTO();
            var c = _listRepository.GetListyId(id);
            if (c != null)
            {
                model = EntityToDTO(c);
            }
            return model;
        }
        public ServiceResponse Update(ListDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {

                var exist = _projectService.GetById(c.ProjectId, c.CreatedByUserId, c.CreatedByUserType);
                if (exist == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _listRepository.GetListyId(c.ListId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ListName = c.ListName;
                model.ModifiedOn = DateTime.Now;
                model.ParentListId = (int)c.ParentListId;
                model.ProjectRId = c.ProjectId;
                model.SortOrder = c.SortOrder;
                model.ListId = c.ListId;
                _listRepository.UpdateList(model);
                aPIResponse.Id = model.ListId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private ListDTO EntityToDTO(tblList c)
        {
            ListDTO dto = new ListDTO();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = c.CreatedOn;
                dto.IsActive = c.IsActive;
                dto.ListName = c.ListName;
                dto.ModifiedOn = c.ModifiedOn;
                dto.ParentListId = c.ParentListId;
                dto.ProjectId = c.ProjectRId;
                dto.SortOrder = c.SortOrder;
                dto.ListId = c.ListId;
            }
            return dto;

        }
        private tblList DTOToEntity(ListDTO c)
        {
            tblList model = new tblList();
            model.CreatedByUserId = c.CreatedByUserId;
            model.CreatedByUserType = c.CreatedByUserType;
            model.CreatedOn = DateTime.Now;
            model.IsActive = c.IsActive;
            model.ListName = c.ListName;
            model.ModifiedOn = DateTime.Now;
            model.ParentListId = c.ParentListId;
            model.ProjectRId = c.ProjectId;
            model.SortOrder = c.SortOrder;
            model.ListId = c.ListId;
            return model;
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardContactsService : IActorCardContactsService
    {
        private readonly IActorCardRepository _actorRepository;
        private readonly IActorCardContactsRepository _actorCardContactsRepository;
        public ActorCardContactsService(IActorCardRepository actorRepository, IActorCardContactsRepository actorCardContactsRepository)
        {
            _actorCardContactsRepository = actorCardContactsRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(ActorCardContactsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCard_Contacts obj = DTOToEntity(c);
                _actorCardContactsRepository.AddActorCardContact(obj);
                aPIResponse.Id = obj.ActrorCard_ContactsId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id)
        {
            _actorCardContactsRepository.DeleteActorCardContact(id);
        }
        public IEnumerable<ActorCardContactsDTO> Get(int CastingList_ActorId)
        {
            List<ActorCardContactsDTO> dtolist = new List<ActorCardContactsDTO>();
            var list = _actorCardContactsRepository.Get(CastingList_ActorId);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public ActorCardContactsDTO GetById(int id)
        {
            var c = _actorCardContactsRepository.GetById(id);
            return EntityToDTO(c);
        }
        public ServiceResponse Update(ActorCardContactsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardContactsRepository.GetById(c.ActrorCard_ContactsId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardContactIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActrorCard_ContactsId = c.ActrorCard_ContactsId;
                model.LastUpdatedDate = DateTime.Now;
                model.OriginalImdbContactRId = c.OriginalImdbContactRId;
                model.SortOrder = c.SortOrder;
                model.IsHidden = c.IsHidden;
                model.ContactCompany = c.ContactCompany;
                model.ContactEmail = c.ContactEmail;
                model.ContactName = c.ContactName;
                model.ContactPhone = c.ContactPhone;
                model.ContactType = c.ContactType;
                _actorCardContactsRepository.UpdateActorCardContact(model);
                aPIResponse.Id = model.ActrorCard_ContactsId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private ActorCardContactsDTO EntityToDTO(tblActorCard_Contacts c)
        {
            ActorCardContactsDTO dto = new ActorCardContactsDTO();
            if (c != null)
            {
                dto.ActrorCard_ContactsId = c.ActrorCard_ContactsId;
                dto.IsHidden = c.IsHidden;
                dto.SortOrder = c.SortOrder;
                dto.ActorCardRId = c.ActorCardRId;
                dto.ContactCompany = c.ContactCompany;
                dto.ContactEmail = c.ContactEmail;
                dto.ContactName = c.ContactName;
                dto.ContactPhone = c.ContactPhone;
                dto.ContactType = c.ContactType;
                dto.LastUpdatedDate = DateTime.Now;
                dto.OriginalImdbContactRId = c.OriginalImdbContactRId;
            }
            return dto;
        }
        private tblActorCard_Contacts DTOToEntity(ActorCardContactsDTO c)
        {
            tblActorCard_Contacts obj = new tblActorCard_Contacts();
            obj.ActrorCard_ContactsId = c.ActrorCard_ContactsId;
            obj.CreatedOn = DateTime.Now;
            obj.IsHidden = c.IsHidden;
            obj.SortOrder = c.SortOrder;
            obj.ActorCardRId = c.ActorCardRId;
            obj.ContactCompany = c.ContactCompany;
            obj.ContactEmail = c.ContactEmail;
            obj.ContactName = c.ContactName;
            obj.ContactPhone = c.ContactPhone;
            obj.ContactType = c.ContactType;
            obj.LastUpdatedDate = DateTime.Now;
            obj.OriginalImdbContactRId = c.OriginalImdbContactRId;
            return obj;
        }
        public void UpdateSortOrder(List<ActorSortDTO> dto)
        {
            _actorCardContactsRepository.UpdateActorCardContactSortOrder(dto);
        }
        public void UpdateSatus(List<ActorStatusDTO> dto)
        {
            _actorCardContactsRepository.UpdateActorCardContactStatus(dto);
        }
    }
}

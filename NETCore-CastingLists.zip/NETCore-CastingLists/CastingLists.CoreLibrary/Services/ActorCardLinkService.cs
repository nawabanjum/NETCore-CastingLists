﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardLinkService : IActorCardLinkService
    {
        private readonly IActorCardLinkRepository _actorCardLinkRepository;
        private readonly IActorCardRepository _actorRepository;
        public ActorCardLinkService(IActorCardRepository actorCardRepository, IActorCardLinkRepository actorCardLinkRepository)
        {
            _actorCardLinkRepository = actorCardLinkRepository;
            _actorRepository = actorCardRepository;
        }
        public ServiceResponse Add(ActorCardLinksDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCardLinks obj = DTOToEntity(c);
                _actorCardLinkRepository.AddLink(obj);
                aPIResponse.Id = obj.LinkId;
                return aPIResponse;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public void Delete(int id)
        {
            _actorCardLinkRepository.DeleteLink(id);
        }

        public IEnumerable<ActorCardLinksDTO> Get(int CastingList_ActorId)
        {
            List<ActorCardLinksDTO> dtolist = new List<ActorCardLinksDTO>();
            var list = _actorCardLinkRepository.GetLinkByActorId(CastingList_ActorId);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }

        public ActorCardLinksDTO GetById(int id)
        {
            var model = _actorCardLinkRepository.GetLinkById(id);
            return EntityToDTO(model);
        }

        public ServiceResponse Update(ActorCardLinksDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardLinkRepository.GetLinkById(c.LinkId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardLinkIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.Link = c.Link;
                model.LinkId = c.LinkId;
                model.SortOrder = c.SortOrder;
                model.Title = c.Title;
                model.LastUpdatedDate = DateTime.Now;
                model.IsHidden = c.IsHidden;
                model.ActorCardRId = c.ActorCardRId;
                _actorCardLinkRepository.UpdateLink(model);
                aPIResponse.Id = model.LinkId;
                return aPIResponse;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private tblActorCardLinks DTOToEntity(ActorCardLinksDTO c)
        {
            tblActorCardLinks obj = new tblActorCardLinks();
            obj.LinkId = c.LinkId;
            obj.CreatedOn = DateTime.Now;
            obj.Title = c.Title;
            obj.Link = c.Link;
            obj.IsHidden = c.IsHidden;
            obj.SortOrder = c.SortOrder;
            obj.ActorCardRId = c.ActorCardRId;
            obj.LastUpdatedDate = DateTime.Now;
            return obj;
        }
        private ActorCardLinksDTO EntityToDTO(tblActorCardLinks c)
        {
            ActorCardLinksDTO dto = new ActorCardLinksDTO();
            dto.LinkId = c.LinkId;
            dto.IsHidden = c.IsHidden;
            dto.SortOrder = c.SortOrder;
            dto.Title = c.Title;
            dto.Link = c.Link;
            dto.ActorCardRId = c.ActorCardRId;
            dto.LastUpdatedDate = DateTime.Now;
            return dto;
        }
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardImdbService : IActorCardImdbService
    {
        private readonly IActorCardImdbRepository _actorCardImdbRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IListRepository _listRepository;
        private readonly IActorCardContactsRepository _actorCardContactsRepository;
        private readonly IActorCardRepository _actorCardRepository;
        private readonly IActorCardKnowsForRepository _actorCardKnowsForRepository;
        private readonly IActorCardImageRepository _actorCardImageRepository;
        private readonly IActorCardLinkRepository  _actorCardLinkRepository;
        private UploadSettings _appSettings { get; set; }
        private IOptions<ValidateImageSizes> _validImageSize;
        private IOptions<ValidImageExtensions> _validImageExtensions;
        public ActorCardImdbService(IActorCardLinkRepository actorCardLinkRepository, IActorCardImageRepository actorCardImageRepository, IActorCardKnowsForRepository actorCardKnowsForRepository, IActorCardRepository actorCardRepository, IActorCardContactsRepository actorCardContactsRepository, IActorCardImdbRepository actorCardImdbRepository, IListRepository listRepository, IRoleRepository roleRepository,
            IOptions<UploadSettings> uploadSettings, IOptions<ValidateImageSizes> validImageSize, IOptions<ValidImageExtensions> validImageExtensions)
        {
            _actorCardImdbRepository = actorCardImdbRepository;
            _roleRepository = roleRepository;
            _listRepository = listRepository;
            _actorCardContactsRepository = actorCardContactsRepository;
            _actorCardRepository = actorCardRepository;
            _actorCardKnowsForRepository = actorCardKnowsForRepository;
            _actorCardImageRepository = actorCardImageRepository;
            _actorCardLinkRepository = actorCardLinkRepository;

            _appSettings = uploadSettings.Value;
            _validImageSize = validImageSize;
            _validImageExtensions = validImageExtensions;
        }
        public ServiceResponse Add(ParamActorImdbSearchDTO dto)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var role = _roleRepository.GetById(dto.RoleRId);
                if (role == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var list = _listRepository.GetListyId(dto.ListRId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var c = _actorCardImdbRepository.Get(dto.CastingList_IMDBActorId);
                if (c == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorImdbNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCard model = new tblActorCard();
                model.CreatedByUserId = c.CreatedByUserId;
                model.CreatedByUserType = c.CreatedByUserType;
                model.LastUpdatedDate = DateTime.Now;
                model.AgeRange = c.AgeRange;
                model.BOD = (DateTime)c.DateOfBirth;
                model.CastingList_IMDBActorId = c.ActorId;
                model.CreatedOn = DateTime.Now;
                model.DisplayName = $"{ c.FirstName }{c.LastName }";
                int height;
                bool success = int.TryParse(c.Height, out height);
                if (success)
                {
                    model.HeightFeet = height;
                    model.HeightInches = height;
                }
                model.ListRId = dto.ListRId;
                model.Notes = "";
                model.RoleRId = dto.RoleRId;
                model.ProjectRId = dto.ProjectRId;
                _actorCardRepository.AddActorCard(model);
                if (c.TblActorContacts != null && c.TblActorContacts.Count() > 0)
                {
                    SaveActorContcts(model.Id, c);
                }
                if (c.TblKnowsFors != null && c.TblKnowsFors.Count() > 0)
                {
                    SaveActorKnowsFor(model.Id, c);
                }
                if (c.TblKnowsFors != null && c.TblKnowsFors.Count() > 0)
                {
                    SaveActorLinks(model.Id, c);
                }
                if (c.PicturePath != null)
                {
                    SaveActorImages(model.Id, c, dto);
                }
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private void SaveActorContcts(int ActorCardId, tblActorImdb model)
        {
            foreach (var item in model.TblActorContacts)
            {
                var obj = new tblActorCard_Contacts();

                if (item.ContactType.ToLower().Contains("individual"))
                {
                    obj.ActorCardRId = ActorCardId;
                    obj.CreatedOn = DateTime.Now;
                    obj.LastUpdatedDate = DateTime.Now;
                    obj.ContactPhone = item.ContactPhone;
                    obj.ContactEmail = item.ContactEmail;
                    obj.ContactName = item.ContactName;
                    obj.ContactType = item.ContactType;
                    obj.IsHidden = false;
                    _actorCardContactsRepository.AddActorCardContact(obj);

                }
                if (item.ContactType.ToLower().Contains("company"))
                {
                    obj.ActorCardRId = ActorCardId;
                    obj.CreatedOn = DateTime.Now;
                    obj.LastUpdatedDate = DateTime.Now;
                    obj.ContactEmail = item.ContactCompanyEmail;
                    obj.ContactCompany = item.ContactCompany;
                    obj.ContactName = item.ContactCompany;
                    obj.ContactPhone = item.ContactCompanyPhone;
                    obj.ContactType = item.ContactType;
                    obj.IsHidden = false;
                    _actorCardContactsRepository.AddActorCardContact(obj);

                }

                if (item.ContactType.ToLower().Contains("both"))
                {

                    obj.ActorCardRId = ActorCardId;
                    obj.CreatedOn = DateTime.Now;
                    obj.LastUpdatedDate = DateTime.Now;
                    obj.ContactPhone = item.ContactPhone + " , " + item.ContactCompanyPhone;
                    obj.ContactEmail = item.ContactEmail + " , " + item.ContactCompanyEmail;
                    obj.ContactName = item.ContactName + " , " + item.ContactCompany;
                    obj.ContactType = item.ContactType;
                    obj.IsHidden = false;
                    _actorCardContactsRepository.AddActorCardContact(obj);

                }

            }

        }
        private void SaveActorKnowsFor(int ActorCardId, tblActorImdb model)
        {

            foreach (var item in model.TblKnowsFors)
            {
                var obj = new tblActorCard_KnowsFor();
                obj.ActorCardRId = ActorCardId;
                obj.CreatedOn = DateTime.Now;
                obj.ModifiedOn = DateTime.Now;
                obj.Title = item.Title;
                obj.Link = item.Link;
                obj.IsHidden = false;
                _actorCardKnowsForRepository.AddActorCardKnowsFor(obj);
            }

        }
        private void SaveActorLinks(int ActorCardId, tblActorImdb model)
        {

            foreach (var item in model.TblKnowsFors)
            {
                var obj = new tblActorCardLinks();
                obj.ActorCardRId = ActorCardId;
                obj.CreatedOn = DateTime.Now;
                obj.Title = item.Title;
                obj.Link = item.Link;
                obj.IsHidden = false;
                obj.LastUpdatedDate = DateTime.Now;
                _actorCardLinkRepository.AddLink(obj);
            }

        }

        private void SaveActorImages(int ActorCardId, tblActorImdb model, ParamActorImdbSearchDTO dto)
        {
            CommonOperations commonOperations = new CommonOperations();
            ServiceResponse response = new ServiceResponse();
            var obj = new tblActorCardImages();
            obj.ActorCardRId = ActorCardId;
            var imageSize = _validImageSize.Value.ImageSizes.ToString();
            var validImageExtensionsArray = _validImageExtensions.Value.Extensions.Split(",");
            response = commonOperations.CopyPictureFromImdbToActorCard(model.PicturePath, _appSettings, imageSize, validImageExtensionsArray).Result;
            obj.PicturePath = response.ServiceResponseMessage ;
            obj.IsDefault = true;
            _actorCardImageRepository.AddActorCardImage(obj);
        }
    }
}

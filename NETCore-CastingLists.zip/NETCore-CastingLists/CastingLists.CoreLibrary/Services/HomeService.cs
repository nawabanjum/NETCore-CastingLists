﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class HomeService : IHomeService
    {
        private readonly IHomeRepository _homeRepository;
        public HomeService(IHomeRepository homeRepository)
        {
            _homeRepository = homeRepository;
        }
        public  Task<ListCommonListDTO> GetProjectsList(GlobalSearch paginationDTO)
        {

            return _homeRepository.GetProjectsList(paginationDTO);
           
        }

        public Task<TreeDTO> GetTree(int CreatedByUserId, int CreatedByUserType)
        {
            return _homeRepository.TreeList(CreatedByUserId, CreatedByUserType);
        }
    }
}

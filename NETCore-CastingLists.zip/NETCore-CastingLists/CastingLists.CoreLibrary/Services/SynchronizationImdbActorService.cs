﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class SynchronizationImdbActorService : ISynchronizationImdbActorService
    {
        private readonly ISynchronizationImdbActorRepository _synchronizationImdbActorRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IListRepository _listRepository;
        private readonly IProjectRepository _projectRepository;
        private readonly IActorRepository _actorRepository;
        public SynchronizationImdbActorService(IActorRepository actorRepository, IProjectRepository projectRepository, IListRepository listRepository, IRoleRepository roleRepository, ISynchronizationImdbActorRepository synchronizationImdbActorRepository)
        {
            _synchronizationImdbActorRepository = synchronizationImdbActorRepository;
            _roleRepository = roleRepository;
            _listRepository = listRepository;
            _projectRepository = projectRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(SynchronizationImdbActorsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblSynchronizationImdbActors model = new tblSynchronizationImdbActors();
            try
            {
                var role = _roleRepository.GetById(c.RoleRId);
                if (role == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var list = _listRepository.GetListyId(c.ListRId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var project = _projectRepository.GetById(c.ProjectRId);
                if (project == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var actor = _actorRepository.GetById(c.ActorRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model = DTOToEntity(c);
                _synchronizationImdbActorRepository.AddSynchronizationImdbActor(model);
                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public IEnumerable<SynchronizationImdbActorsDTO> GetByListId(int listid, int userid, int usertype)
        {
            List<SynchronizationImdbActorsDTO> dtolist = new List<SynchronizationImdbActorsDTO>();
            var list = _synchronizationImdbActorRepository.GetSynchronizationImdbActorByListId(listid, userid, usertype);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    var obj = new SynchronizationImdbActorsDTO();
                    obj = EntityToDTO(item);
                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }
        private SynchronizationImdbActorsDTO EntityToDTO(tblSynchronizationImdbActors c)
        {
            SynchronizationImdbActorsDTO dto = new SynchronizationImdbActorsDTO();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = c.CreatedOn;
                dto.Id = c.Id;
                dto.ListRId = c.ListRId;
                dto.RoleRId = c.RoleRId;
                dto.ProjectRId = c.ProjectRId;
                dto.ActorRId = c.ActorRId;
                dto.Details = c.Details;
                dto.EventType = c.EventType;
                dto.IsError = c.IsError;
                dto.IsSuccess = c.IsSuccess;
                dto.Details = c.Details;
                dto.SyncCastListRId = c.SyncCastListRId;
            }
            return dto;
        }
        private tblSynchronizationImdbActors DTOToEntity(SynchronizationImdbActorsDTO c)
        {
            tblSynchronizationImdbActors dto = new tblSynchronizationImdbActors();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = DateTime.Now;
                dto.ListRId = c.ListRId;
                dto.RoleRId = c.RoleRId;
                dto.ProjectRId = c.ProjectRId;
                dto.EventType = c.EventType;
                dto.IsError = c.IsError;
                dto.IsSuccess = c.IsSuccess;
                dto.ImdbId = c.ImdbId;
                dto.Details = c.Details;
                dto.ActorRId = c.ActorRId;
                dto.SyncCastListRId = c.SyncCastListRId;
            }
            return dto;
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardPrivateNoteService : IActorCardPrivateNoteService
    {
        private readonly IActorCardRepository _actorRepository;

        private readonly IActorCardPrivateNoteRepository _actorCardPrivateNoteRepository;

        public ActorCardPrivateNoteService(IActorCardRepository actorRepository, IActorCardPrivateNoteRepository actorCardPrivateNoteRepository)
        {
            _actorCardPrivateNoteRepository = actorCardPrivateNoteRepository;
            _actorRepository = actorRepository;
        }

        public ServiceResponse Add(ActorCardPrivateNoteDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCard_PrivateNote obj = DTOToEntity(c);
                _actorCardPrivateNoteRepository.AddActorCardPrivateNote(obj);
                aPIResponse.Id = obj.ActorCard_PrivateNoteId;
            }
            catch (Exception ex)
            {
                aPIResponse.ServiceResponseMessage = ex.Message;
                aPIResponse.IsError = true;
            }
            return aPIResponse;
        }

        public void Delete(int id)
        {
            _actorCardPrivateNoteRepository.DeleteActorCardPrivateNote(id);
        }

        public IEnumerable<ActorCardPrivateNoteDTO> Get(int CastingList_ActorRId)
        {
            List<ActorCardPrivateNoteDTO> dtolist = new List<ActorCardPrivateNoteDTO>();
            var list = _actorCardPrivateNoteRepository.Get(CastingList_ActorRId);
            foreach (var item in list)
            {
                dtolist.Add(EntityToDTO(item));
            }
            return dtolist;
        }

        public ActorCardPrivateNoteDTO GetById(int id)
        {
            var c = _actorCardPrivateNoteRepository.GetById(id);
            return EntityToDTO(c);
        }

        public ServiceResponse Update(ActorCardPrivateNoteDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardPrivateNoteRepository.GetById(c.ActorCard_PrivateNoteId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardPrivatenotesIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActorCard_PrivateNoteId = c.ActorCard_PrivateNoteId;
                model.ActorCardRId = c.ActorCardRId;
                model.IsHidden = c.IsHidden;
                model.LastUpdatedDate = DateTime.Now;
                model.Notes = c.Notes;
                model.SortOrder = c.SortOrder;
                _actorCardPrivateNoteRepository.UpdateActorCardPrivateNote(model);
                aPIResponse.Id = model.ActorCard_PrivateNoteId;
            }
            catch (Exception ex)
            {
                aPIResponse.ServiceResponseMessage = ex.Message;
                aPIResponse.IsError = true;
            }
            return aPIResponse;
        }
        public void UpdateSortOrder(List<ActorSortDTO> dto)
        {
            _actorCardPrivateNoteRepository.updateActorCardPrivateNoteSortOrder(dto);
        }
        public void UpdateSatus(List<ActorStatusDTO> dto)
        {
            _actorCardPrivateNoteRepository.UpdateActorCardPrivateNoteStatus(dto);
        }

        private tblActorCard_PrivateNote DTOToEntity(ActorCardPrivateNoteDTO c)
        {
            tblActorCard_PrivateNote obj = new tblActorCard_PrivateNote();
            obj.CreatedOn = DateTime.Now;
            obj.IsHidden = c.IsHidden;
            obj.LastUpdatedDate = DateTime.Now;
            obj.ActorCardRId = c.ActorCardRId;
            obj.SortOrder = c.SortOrder;
            obj.Notes = c.Notes;
            return obj;
        }
        private ActorCardPrivateNoteDTO EntityToDTO(tblActorCard_PrivateNote c)
        {
            ActorCardPrivateNoteDTO dto = new ActorCardPrivateNoteDTO();
            if (c != null)
            {
                dto.CreatedOn = c.CreatedOn;
                dto.IsHidden = c.IsHidden;
                dto.ActorCardRId = c.ActorCardRId;
                dto.SortOrder = c.SortOrder;
                dto.LastUpdatedDate = DateTime.Now;
                dto.Notes = c.Notes;
                dto.ActorCard_PrivateNoteId = c.ActorCard_PrivateNoteId;
            }
            return dto;
        }
    }
}

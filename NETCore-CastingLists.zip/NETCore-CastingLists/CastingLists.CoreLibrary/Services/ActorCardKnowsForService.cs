﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardKnowsForService : IActorCardKnowsForService
    {
        private readonly IActorCardRepository _actorRepository;

        private readonly IActorCardKnowsForRepository _actorCardKnowsForRepository;
        public ActorCardKnowsForService(IActorCardRepository actorRepository, IActorCardKnowsForRepository actorCardKnowsForRepository)
        {
            _actorCardKnowsForRepository = actorCardKnowsForRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(ActorCardKnowsForDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCard_KnowsFor obj = DTOToEntity(c);
                _actorCardKnowsForRepository.AddActorCardKnowsFor(obj);
                aPIResponse.Id = obj.ActorCard_KnowsForId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public void Delete(int id)
        {
            _actorCardKnowsForRepository.DeleteActorCardKnowsFor(id);
        }

        public IEnumerable<ActorCardKnowsForDTO> Get(int CastingList_ActorId)
        {
            List<ActorCardKnowsForDTO> dtolist = new List<ActorCardKnowsForDTO>();
            var list = _actorCardKnowsForRepository.Get(CastingList_ActorId);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }

        public ActorCardKnowsForDTO GetById(int id)
        {
            var c = _actorCardKnowsForRepository.GetById(id);
            return EntityToDTO(c);
        }

        public ServiceResponse Update(ActorCardKnowsForDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardKnowsForRepository.GetById(c.ActorCard_KnowsForId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardKnowsForIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActorCardRId = c.ActorCardRId;
                model.IsHidden = c.IsHidden;
                model.Link = c.Link;
                model.ModifiedOn = DateTime.Now;
                model.Title = c.Title;
                _actorCardKnowsForRepository.UpdateActorCardKnowsFor(model);
                aPIResponse.Id = model.ActorCard_KnowsForId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        

        public void UpdateSortOrder(List<ActorSortDTO> dto)
        {
            _actorCardKnowsForRepository.UpdateActorCardKnowsForSortOrder(dto);
        }
        public void UpdateSatus(List<ActorStatusDTO> dto)
        {
            _actorCardKnowsForRepository.UpdateActorCardKnowsForStatus(dto);
        }
        private tblActorCard_KnowsFor DTOToEntity(ActorCardKnowsForDTO c)
        {
            tblActorCard_KnowsFor obj = new tblActorCard_KnowsFor();
            if (c != null)
            {
                obj.ActorCard_KnowsForId = c.ActorCard_KnowsForId;
                obj.ActorCardRId = c.ActorCardRId;
                obj.CreatedOn = DateTime.Now;
                obj.IsHidden = c.IsHidden;
                obj.Link = c.Link;
                obj.ModifiedOn = DateTime.Now;
                obj.OriginalImdbKnowsForRId = c.OriginalImdbKnowsForRId;
                obj.Title = c.Title;
                obj.SortOrder = c.SortOrder;
            }
            return obj;
        }
        private ActorCardKnowsForDTO EntityToDTO(tblActorCard_KnowsFor c)
        {
            ActorCardKnowsForDTO dto = new ActorCardKnowsForDTO();
            if (c != null)
            {
                dto.ActorCard_KnowsForId = c.ActorCard_KnowsForId;
                dto.ActorCardRId = c.ActorCardRId;
                dto.CreatedOn = c.CreatedOn;
                dto.IsHidden = c.IsHidden;
                dto.Link = c.Link;
                dto.ModifiedOn = c.ModifiedOn;
                dto.OriginalImdbKnowsForRId = c.OriginalImdbKnowsForRId;
                dto.Title = c.Title;
                dto.SortOrder = c.SortOrder;
            }
            return dto;
        }
    }
}

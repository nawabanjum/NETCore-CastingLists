﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardVideoSrvice : IActorCardVideoSrvice
    {
        private readonly IActorCardRepository _actorRepository;

        private readonly IActorCardVideoRepository _actorCardVideoRepository;
        public ActorCardVideoSrvice(IActorCardRepository actorRepository, IActorCardVideoRepository actorCardVideoRepository)
        {
            _actorCardVideoRepository = actorCardVideoRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(ActorCardVideoDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCardVideos obj = DTOToEntity(c);
                _actorCardVideoRepository.AddActorCardVideo(obj);
                aPIResponse.Id = obj.ActorCard_VideoId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public void Delete(int id)
        {
            _actorCardVideoRepository.DeleteActorCardVideo(id);
        }
        public IEnumerable<ActorCardVideoDTO> Get(int CastingList_ActorRId)
        {
            List<ActorCardVideoDTO> dtolist = new List<ActorCardVideoDTO>();
            var list = _actorCardVideoRepository.Get(CastingList_ActorRId);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public ActorCardVideoDTO GetById(int id)
        {
            var c = _actorCardVideoRepository.GetById(id);
            return EntityToDTO(c);
        }
        public ServiceResponse Update(ActorCardVideoDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardVideoRepository.GetById(c.ActorCard_VideoId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardPrivatenotesIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.IsAudio = c.IsAudio;
                model.IsHidden = c.IsHidden;
                model.IsStudio = c.IsStudio;
                model.MediaRId = c.MediaRId;
                model.SortOrder = c.SortOrder;
                _actorCardVideoRepository.UpdateActorCardVideo(model);
                aPIResponse.Id = model.ActorCard_VideoId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public void UpdateSatus(List<ActorStatusDTO> dto)
        {
            _actorCardVideoRepository.UpdateActorCardVideoStatus(dto);

        }

        public void UpdateSortOrder(List<ActorSortDTO> dto)
        {
            _actorCardVideoRepository.UpdateActorCardVideoSortOrder(dto);
        }

        private tblActorCardVideos DTOToEntity(ActorCardVideoDTO c)
        {
            tblActorCardVideos obj = new tblActorCardVideos();
            obj.ActorCard_VideoId = c.ActorCard_VideoId;
            obj.CreatedOn = DateTime.Now;
            obj.IsHidden = c.IsHidden;
            obj.ActorCardRId = c.ActorCardRId;
            obj.IsAudio = c.IsAudio;
            obj.IsStudio = c.IsStudio;
            obj.MediaRId = c.MediaRId;
            obj.SortOrder = c.SortOrder;
            return obj;
        }
        private ActorCardVideoDTO EntityToDTO(tblActorCardVideos c)
        {
            ActorCardVideoDTO dto = new ActorCardVideoDTO();
            if (c != null)
            {
                dto.ActorCard_VideoId = c.ActorCard_VideoId;
                dto.CreatedOn = DateTime.Now;
                dto.IsHidden = c.IsHidden;
                dto.ActorCardRId = c.ActorCardRId;
                dto.IsAudio = c.IsAudio;
                dto.IsStudio = c.IsStudio;
                dto.MediaRId = c.MediaRId;
                dto.SortOrder = c.SortOrder;
            }
            return dto;
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class RoleService : IRoleService
    {
        private readonly IRoleRepository _roleRepository;
        private readonly IProjectService _projectService;
        public RoleService(IRoleRepository roleRepository, IProjectService projectService)
        {
            _roleRepository = roleRepository;
            _projectService = projectService;
        }
        public ServiceResponse Add(RoleDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {

                var exist = _projectService.GetById(c.ProjectRId, c.CreatedByUserId, c.CreatedByUserType);
                if (exist == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblRoles obj = new tblRoles();

                obj = DTOToEntity(c);
                _roleRepository.AddRole(obj);
                aPIResponse.Id = obj.RoleId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id, int userid, int usertype)
        {
            _roleRepository.DeleteRole(id, userid, usertype);
        }
        public IEnumerable<RoleDTO> Get(int userid, int usertype, int projectid)
        {
            List<RoleDTO> dtolist = new List<RoleDTO>();
            var list = _roleRepository.Get(userid, usertype, projectid);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public RoleDTO GetById(int id, int userid, int usertype)
        {
            RoleDTO obj = new RoleDTO();

            var c = _roleRepository.GetRoleById(id, userid, usertype);
            if (c != null)
            {
                obj.CreatedByUserId = c.CreatedByUserId;
                obj.CreatedByUserType = c.CreatedByUserType;
                obj.CreatedOn = c.CreatedOn;
                obj.IsActive = c.IsActive;
                obj.RoleId = c.RoleId;
                obj.RoleTitle = c.RoleTitle;
                obj.RoleDesc = c.RoleDesc;
                obj.ModifiedOn = c.ModifiedOn;
                obj.ProjectRId = c.ProjectRId;
                obj.SortOrder = c.SortOrder;
            }
            return obj;
        }
        public ServiceResponse Update(RoleDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {

                var exist = _projectService.GetById(c.ProjectRId, c.CreatedByUserId, c.CreatedByUserType);
                if (exist == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _roleRepository.GetRoleById(c.RoleId, c.CreatedByUserId, c.CreatedByUserType);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.IsActive = c.IsActive;
                model.RoleId = c.RoleId;
                model.RoleTitle = c.RoleTitle;
                model.RoleDesc = c.RoleDesc;
                model.ModifiedOn = DateTime.Now;
                model.ProjectRId = c.ProjectRId;
                model.SortOrder = c.SortOrder;
                _roleRepository.UpdateRole(model);
                aPIResponse.Id = model.RoleId;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private RoleDTO EntityToDTO(tblRoles c)
        {
            RoleDTO dto = new RoleDTO();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = c.CreatedOn;
                dto.IsActive = c.IsActive;
                dto.RoleId = c.RoleId;
                dto.RoleTitle = c.RoleTitle;
                dto.RoleDesc = c.RoleDesc;
                dto.ModifiedOn = c.ModifiedOn;
                dto.ProjectRId = c.ProjectRId;
                dto.SortOrder = c.SortOrder;
            }
            return dto;
        }
        private tblRoles DTOToEntity(RoleDTO c)
        {
            tblRoles dto = new tblRoles();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = DateTime.Now;
                dto.IsActive = c.IsActive;
                dto.RoleId = c.RoleId;
                dto.RoleTitle = c.RoleTitle;
                dto.RoleDesc = c.RoleDesc;
                dto.ModifiedOn = DateTime.Now;
                dto.ProjectRId = c.ProjectRId;
                dto.SortOrder = c.SortOrder;
            }
            return dto;
        }
    }
}

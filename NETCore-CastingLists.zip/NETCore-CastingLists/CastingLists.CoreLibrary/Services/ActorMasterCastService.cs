﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorMasterCastService : IActorMasterCastService
    {
        private readonly IActorMasterCastRepository _actorMasterCastRepository;
        private readonly IActorRepository _actorRepository;
        private readonly IMasterCastImdbActorConnectionRepository _masterCastImdbActorConnectionRepository;
        private readonly IActorContactsRepository _actorContactsRepository;
        private readonly IHttpClientFactory _clientFactory;
        private UploadSettings _appSettings { get; set; }
        private IOptions<ValidImageExtensions> _validImageExtensions;
        private IOptions<CWBActorPhotoSetting> _cwBActorPhotoSetting;
        private IOptions<ValidateImageSizes> _validImageSize;
        public ActorMasterCastService(IHttpClientFactory httpClientFactory, IActorContactsRepository actorContactsRepository, IMasterCastImdbActorConnectionRepository masterCastImdbActorConnectionRepository, IActorRepository actorRepository
            , IOptions<CWBActorPhotoSetting> cwBActorPhotoSetting, IActorMasterCastRepository actorMasterCastRepository, IOptions<UploadSettings> uploadSettings, IOptions<ValidImageExtensions> validImageExtensions, IOptions<ValidateImageSizes> validImageSize)
        {
            _actorMasterCastRepository = actorMasterCastRepository;
            _actorRepository = actorRepository;
            _masterCastImdbActorConnectionRepository = masterCastImdbActorConnectionRepository;
            _actorContactsRepository = actorContactsRepository;
            _appSettings = uploadSettings.Value;

            _clientFactory = httpClientFactory;
            _validImageExtensions = validImageExtensions;
            _cwBActorPhotoSetting = cwBActorPhotoSetting;
            _validImageSize = validImageSize;
        }
        public ServiceResponse Add(ParamActorMasterCastSearchDTO dto)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var model = _actorMasterCastRepository.Get(dto);
                if (model != null)
                {
                    var response = SaveActor(model, dto.CreatedByUserId, dto.CreatedByUserType);
                    if (response != null)
                    {
                        aPIResponse.Id = response.ActorId;
                        SaveActorContacts(model.actorContactViaMasterDTO, response.ActorId);
                        SaveMasterCastImdbActorConnection(dto, response.ActorId);
                    }
                }
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }


        private tblActorImdb SaveActor(MasterDto obj, int CreatedByUserId, int CreatedByUserType)
        {
            tblActorImdb model = new tblActorImdb();
            if (obj.actorViaMasterDTO != null)
            {
                CommonOperations commonOperations = new CommonOperations();
                List<ImageViaMasterDTO> images = new List<ImageViaMasterDTO>();
                var dto = obj.actorViaMasterDTO;
                model.AgeRange = dto.Agefrom + "-" + dto.Ageto;
                model.CreatedOn = DateTime.Now;
                model.FirstName = dto.Firstname;
                model.LastName = dto.Lastname;
                model.LastUpdatedDate = DateTime.Now;
                model.Gender = Convert.ToString(dto.Gender);
                model.Weigth = Convert.ToString(dto.Weight);
                model.Height = dto.Heightfeet + "'" + dto.Heightinches;
                model.IsDeleted = false;
                model.DateOfBirth = dto.Birthday;
                model.CreatedByUserId = CreatedByUserId;
                model.CreatedByUserType = CreatedByUserType;
                model.LastUpdatedPlatform = DateTime.Now;
                model.ImageSourceUrl = "";
                model.ImdbId = "";
                model.PicturePath = "";
                model.Ranking = "";
                model.RanKStarMeeter = 0;
                model.Ethnicity = "";
                var validImageExtensionsArray = _validImageExtensions.Value.Extensions.Split(",");
                var imagesSize = _validImageSize.Value.ImageSizes.ToString();
                if (obj.actorImageViaMasterDTO != null && obj.actorImageViaMasterDTO.Count() > 0)
                {
                    foreach (var item in obj.actorImageViaMasterDTO)
                    {
                        var imagePath = $"{_cwBActorPhotoSetting.Value.HttpActorImagesLocation}?ct={item.Client_ID}&fn={model.FirstName}&i={item.PhotoNum}&thj=t&ro={dto.RosterId}/{item.Image}";
                      // save picture in the actor card configuration folder
                       var response = commonOperations.UploadImageActorCard(imagePath, _appSettings, _clientFactory.CreateClient(), validImageExtensionsArray, imagesSize).Result;
                        var  imgObj = new ImageViaMasterDTO();
                        imgObj.Image = response.ServiceResponseMessage;
                        imgObj.ImageUrl = imagePath;
                        images.Add(imgObj);
                    }
                    if (images != null )
                    {
                        var img = images.FirstOrDefault();
                        model.ImageSourceUrl = img.ImageUrl;
                        model.PicturePath = img.Image;

                    }
                 
                }

                
                _actorRepository.AddActor(model);
            }
            return model;
        }
        private void SaveActorContacts(ActorContactViaMasterDTO dto, int ImdbActorId)
        {
            if (dto != null)
            {
                tblActorContacts model = new tblActorContacts();
                model.ActorRId = ImdbActorId;
                model.ContactCompany = dto.Actor_Company;
                model.ContactCompanyAddress = dto.Actor_Address;
                model.ContactCompanyEmail = model.ContactEmail = dto.Actor_Email;
                model.ContactCompanyPhone = model.ContactPhone = dto.Actor_Phone;
                model.ContactCompanyWebSite = model.ContactWebSite = dto.Actor_Website;
                model.CreatedOn = DateTime.Now;
                model.IsDeleted = false;
                model.ContactName = dto.Actor_FirstName + " " + dto.Actor_LastName;
                model.LastUpdatedDate = DateTime.Now;
                model.ContactType = "";
                model.ContactCountry = "";
                model.ContactGroup = "";
                model.ContactImdbLink = model.ContactCompanyImdb = "";
                _actorContactsRepository.AddActorContact(model);
            }

        }
        private void SaveMasterCastImdbActorConnection(ParamActorMasterCastSearchDTO dto, int ImdbActorId)
        {
            tblMasterCastImdbActorConnection model = new tblMasterCastImdbActorConnection();
            if (dto != null && ImdbActorId > 0)
            {
                model.ClientRId = dto.ClientRId;
                model.CreatedByUserId = dto.CreatedByUserId;
                model.CreatedByUserType = dto.CreatedByUserType;
                model.ImdbActorRId = ImdbActorId;
                model.ListRId = dto.ListRId;
                model.projectRId = dto.ListRId;
                model.RoleRId = dto.RoleRId;
                model.RosterId = dto.RosterRId;
                _masterCastImdbActorConnectionRepository.AddMasterCastImdbActor(model);
            }
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class FilmographyService : IFilmographyService
    {
        private readonly IActorRepository _actorRepository;

        private readonly IFilmographyRepository _filmographyRepository;
        public FilmographyService(IActorRepository actorRepository, IFilmographyRepository filmographyRepository)
        {
            _filmographyRepository = filmographyRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(FilmographyDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblFilmographyImdb obj = DTOToEntity(c);
                _filmographyRepository.AddFilmography(obj);
                aPIResponse.Id = obj.FilmographyId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id)
        {
            _filmographyRepository.DeleteFilmography(id);
        }
        public IEnumerable<FilmographyDTO> GetByActorId(int actorid)
        {
            List<FilmographyDTO> dtolist = new List<FilmographyDTO>();
            var list = _filmographyRepository.GetFilmographyByActorId(actorid);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public FilmographyDTO GetById(int id)
        {
            var c = _filmographyRepository.GetFilmographyById(id);
            return EntityToDTO(c);
        }
        public ServiceResponse Update(FilmographyDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                tblFilmographyImdb model = new tblFilmographyImdb();
                var actor = _actorRepository.GetById(c.ActorRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model = _filmographyRepository.GetFilmographyById(c.FilmographyId);

                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.FilmographyIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActorRId = c.ActorRId;
                model.IsDeleted = c.IsDeleted;
                model.LastUpdatedDate = DateTime.Now;
                model.StartYear = c.StartYear;
                model.EndYear = c.EndYear;
                model.FullDescription = c.FullDescription;
                model.Link = c.Link;
                model.ImdbId = c.ImdbId;
                model.FilmographyId = c.FilmographyId;
                _filmographyRepository.UpdateFilmography(model);
                aPIResponse.Id = model.FilmographyId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private FilmographyDTO EntityToDTO(tblFilmographyImdb c)
        {
            FilmographyDTO dto = new FilmographyDTO();
            if (c != null)
            {
                dto.ActorRId = c.ActorRId;
                dto.CreatedOn = c.CreatedOn;
                dto.IsDeleted = c.IsDeleted;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.StartYear = c.StartYear;
                dto.EndYear = c.EndYear;
                dto.FullDescription = c.FullDescription;
                dto.FilmographyId = c.FilmographyId;
                dto.Title = c.Title;
                dto.Link = c.Link;
                dto.ImdbId = c.ImdbId;
            }
            return dto;

        }
        private tblFilmographyImdb DTOToEntity(FilmographyDTO c)
        {
            tblFilmographyImdb obj = new tblFilmographyImdb();
            if (c != null)
            {
                obj.ActorRId = c.ActorRId;
                obj.CreatedOn = DateTime.Now;
                obj.IsDeleted = c.IsDeleted;
                obj.LastUpdatedDate = DateTime.Now;
                obj.FilmographyId = c.FilmographyId;
                obj.StartYear = c.StartYear;
                obj.EndYear = c.EndYear;
                obj.FullDescription = c.FullDescription;
                obj.Title = c.Title;
                obj.Link = c.Link;
               obj.ImdbId = ExtractImdbId(c.ImdbId);
            }
            return obj;
        }
        private string ExtractImdbId(string ImdbId)
        {
            string imdbid = string.Empty;
            var imdb = ImdbId.Split('/');
            if (imdb != null)
            {
                imdbid = imdb[4];
            }
            return imdbid;
        }
    }
}

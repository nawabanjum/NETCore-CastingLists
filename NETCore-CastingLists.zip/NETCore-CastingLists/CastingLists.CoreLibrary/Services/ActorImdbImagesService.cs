﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorImdbImagesService : IActorImdbImagesService
    {
        private readonly IActorRepository _actorRepository;
        private readonly IActorImdbImagesRepository _actorImdbImagesRepository;
        private UploadSettings _appSettings { get; set; }
        public ActorImdbImagesService(IActorRepository actorRepository, IActorImdbImagesRepository actorImdbImagesRepository, IOptions<UploadSettings> uploadSettings)
        {
            _actorImdbImagesRepository = actorImdbImagesRepository;
            _actorRepository = actorRepository;
            _appSettings = uploadSettings.Value;
        }
        public ServiceResponse Add(ActorImdbImagesDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorImdbImages model = DTOToEntity(c);
                _actorImdbImagesRepository.AddActorImdbImage(model);
                aPIResponse.Id = model.Id;

            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.ToString();
            }
            return aPIResponse;
        }

        public void Delete(int Id)
        {
            _actorImdbImagesRepository.DeleteActorImdbImage(Id);
        }

        public IEnumerable<ActorImdbImagesListDTO> Get(int actorid)
        {
            var list = _actorImdbImagesRepository.GetImagesByActorId(actorid);
            List<ActorImdbImagesListDTO> dtolist = new List<ActorImdbImagesListDTO>();
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        private tblActorImdbImages DTOToEntity(ActorImdbImagesDTO c)
        {
            tblActorImdbImages obj = new tblActorImdbImages();
            if (c != null)
            {
                obj.ActorRId = c.ActorRId;
                obj.CreatedByUserId = c.CreatedByUserId;
                obj.CreatedByUserType = c.CreatedByUserType;
                obj.CreatedOn = DateTime.Now;
                obj.ImageSourceUrl = c.ImageSourceUrl;
                obj.ImageType = c.ImageType;
                obj.LastUpdatedDate = DateTime.Now;
            }
            return obj;
        }
        private ActorImdbImagesListDTO EntityToDTO(tblActorImdbImages c)
        {
            ActorImdbImagesListDTO dto = new ActorImdbImagesListDTO();
            var folderLocation = _appSettings.ImdbSaveUrlLocation;
            if (c != null)
            {
                dto.ActorRId = c.ActorRId;
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = c.CreatedOn;
                dto.ImageSourceUrl = c.ImageSourceUrl;
                dto.ImageType = c.ImageType;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.ImageTarget = $"{folderLocation}\\{c.ImageSourceUrl}";
            }
            return dto;
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorReportService : IActorReportService
    {
        private readonly IActorReportRepository _actorReportRepository;
        private readonly IListRepository _listRepository;
        private readonly IRoleRepository _roleRepository;
        public ActorReportService(IRoleRepository roleRepository, IListRepository listRepository, IActorReportRepository actorReportRepository)
        {
            _actorReportRepository = actorReportRepository;
            _listRepository = listRepository;
            _roleRepository = roleRepository;
        }
        public async Task<List<Dictionary<object, object>>> GetActorList(GlobalSearchActorImdb c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            List<Dictionary<object, object>> keyValuePairs = new List<Dictionary<object, object>>();
            Dictionary<object, object> distObj = new Dictionary<object, object>();
            var exist = _listRepository.GetListyId(c.ListId);
            if (exist == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                aPIResponse.IsError = true;
                distObj.Add("ErroMessage", aPIResponse);
                keyValuePairs.Add(distObj);
                return keyValuePairs;
            }
            if (c.ActorRoles == null || c.ActorRoles.Count() <= 0)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIds;
                aPIResponse.IsError = true;
                distObj.Add("ErroMessage", aPIResponse);
                keyValuePairs.Add(distObj);
                return keyValuePairs;
            }
            var RoleExists = _roleRepository.ValidateRoles(c.ActorRoles);
            if (RoleExists == null || RoleExists.Count() <= 0)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                aPIResponse.IsError = true;
                distObj.Add("ErroMessage", aPIResponse);
                keyValuePairs.Add(distObj);
                return keyValuePairs;
            }
            return await _actorReportRepository.ActorList(c);
        }
    }
}

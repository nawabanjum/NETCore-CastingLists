﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardService : IActorCardService
    {
        private readonly IActorRepository _actorRepository;
        private readonly IActorCardRepository _actorCardRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IListRepository _listRepository;
        private readonly IProjectRepository _projectRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IActorCardImdbRepository _actorCardImdbRepository;
        private UploadSettings _appSettings { get; set; }
        public ActorCardService(IActorCardImdbRepository actorCardImdbRepository, IActorRepository actorRepository, IClientRepository clientRepository, IProjectRepository projectRepository, IListRepository listRepository,
            IRoleRepository roleRepository, IActorCardRepository actorCardRepository, IOptions<UploadSettings> uploadSettings)
        {
            _actorCardRepository = actorCardRepository;
            _roleRepository = roleRepository;
            _listRepository = listRepository;
            _projectRepository = projectRepository;
            _clientRepository = clientRepository;
            _actorRepository = actorRepository;
            _appSettings = uploadSettings.Value;
            _actorCardImdbRepository = actorCardImdbRepository;
        }

        public ServiceResponse Add(ActorCardDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorCard model = new tblActorCard();
            try
            {
                var role = _roleRepository.GetById(c.RoleRId);
                if (role == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var list = _listRepository.GetListyId(c.ListRId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var project = _projectRepository.GetById(c.ProjectRId);
                if (project == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model = DTOToEntity(c);
                _actorCardRepository.AddActorCard(model);

                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }



        public void Delete(int id, int userid, int usertype)
        {
            _actorCardRepository.DeleteActorCard(id, userid, usertype);
        }

        public IEnumerable<ActorCardDTO> Get(int userid, int usertype)
        {
            List<ActorCardDTO> dtolist = new List<ActorCardDTO>();
            var list = _actorCardRepository.Get(userid, usertype);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    var obj = new ActorCardDTO();
                    obj = EntityToDTO(item);
                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }

        public ActorCardDTO GetById(int id, int userid, int usertype)
        {
            ActorCardDTO obj = new ActorCardDTO();
            var c = _actorCardRepository.GetActorCardById(id, userid, usertype);
            if (c != null)
            {
                obj = EntityToDTO(c);
            }
            return obj;
        }

        public ServiceResponse Update(CastingListActorUpdateDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var model = _actorCardRepository.GetActorCardById(c.Id, c.CreatedByUserId, c.CreatedByUserType);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var role = _roleRepository.GetById(c.RoleRId);
                if (role == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var list = _listRepository.GetListyId(c.ListRId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var project = _projectRepository.GetById(c.ProjectRId);
                if (project == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.AgeRange = c.AgeRange;
                model.BOD = c.BOD;
                model.CastingList_IMDBActorId = c.CastingList_IMDBActorId;
                model.DisplayName = c.DisplayName;
                model.GenderRId = c.GenderRId;
                model.HeightFeet = c.HeightFeet;
                model.HeightInches = c.HeightInches;
                model.IsHidden = c.IsHidden;
                model.LastUpdatedDate = DateTime.Now;
                model.ListRId = c.ListRId;
                model.MasterCast_ClientId = c.MasterCast_ClientId;
                model.MasterCast_RosterId = c.MasterCast_RosterId;
                model.Notes = c.Notes;
                model.ProjectRId = c.ProjectRId;
                model.RoleRId = c.RoleRId;
                model.SortOrder = c.SortOrder;
                _actorCardRepository.UpdateActorCard(model);
                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private ActorCardDTO EntityToDTO(tblActorCard c)
        {
            ActorCardDTO dto = new ActorCardDTO();
            if (c != null)
            {
                var actorImdb = _actorCardImdbRepository.Get(dto.CastingList_IMDBActorId);
                if (actorImdb != null)
                {
                    dto.ImdbId = !string.IsNullOrEmpty(actorImdb.ImdbId) ? actorImdb.ImdbId : " ";
                    dto.RankStarMeeter = actorImdb.RanKStarMeeter;
                }
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.AgeRange = c.AgeRange;
                dto.BOD = c.BOD;
                dto.CastingList_IMDBActorId = c.CastingList_IMDBActorId;
                dto.CreatedOn = c.CreatedOn;
                dto.DisplayName = c.DisplayName;
                dto.GenderRId = c.GenderRId;
                dto.HeightFeet = c.HeightFeet;
                dto.HeightInches = c.HeightInches;
                dto.Id = c.Id;
                dto.IsHidden = c.IsHidden;
                dto.ListRId = c.ListRId;
                dto.MasterCast_ClientId = c.MasterCast_ClientId;
                dto.MasterCast_RosterId = c.MasterCast_RosterId;
                dto.Notes = c.Notes;
                dto.RoleRId = c.RoleRId;
                dto.ProjectRId = c.ProjectRId;
                dto.SortOrder = c.SortOrder;
                if (c.TblActorCard_KnowsFor != null && c.TblActorCard_KnowsFor.Count() > 0)
                {
                    dto.KnowsFors = (from item in c.TblActorCard_KnowsFor
                                     select new ActorCardKnowsForDTO
                                     {
                                         ActorCard_KnowsForId = item.ActorCard_KnowsForId,
                                         ActorCardRId = item.ActorCardRId,
                                         CreatedOn = item.CreatedOn,
                                         IsHidden = item.IsHidden,
                                         Link = item.Link,
                                         Title = item.Title,
                                         ModifiedOn = item.ModifiedOn,
                                         OriginalImdbKnowsForRId = item.OriginalImdbKnowsForRId,
                                         SortOrder = item.SortOrder
                                     }).ToList();
                }
                if (c.TblCastingListActorVideos != null && c.TblCastingListActorVideos.Count() > 0)
                {
                    dto.ActorVideos = (from item in c.TblCastingListActorVideos
                                       select new ActorCardVideoDTO
                                       {
                                           ActorCardRId = item.ActorCardRId,
                                           CreatedOn = item.CreatedOn,
                                           IsHidden = item.IsHidden,
                                           SortOrder = item.SortOrder,
                                           ActorCard_VideoId = item.ActorCard_VideoId,
                                           IsAudio = item.IsAudio,
                                           IsStudio = item.IsStudio,
                                           MediaRId = item.MediaRId
                                       }).ToList();
                }
                if (c.TblCastingListActor_PrivateNotes != null && c.TblCastingListActor_PrivateNotes.Count() > 0)
                {
                    dto.PrivateNotes = (from item in c.TblCastingListActor_PrivateNotes
                                        select new ActorCardPrivateNoteDTO
                                        {
                                            ActorCardRId = item.ActorCardRId,
                                            CreatedOn = item.CreatedOn,
                                            IsHidden = item.IsHidden,
                                            SortOrder = item.SortOrder,
                                            ActorCard_PrivateNoteId = item.ActorCard_PrivateNoteId,
                                            LastUpdatedDate = item.LastUpdatedDate,
                                            Notes = item.Notes
                                        }).ToList();
                }
                if (c.TblActorCard_Contacts != null && c.TblActorCard_Contacts.Count() > 0)
                {
                    dto.ActorContacts = (from item in c.TblActorCard_Contacts
                                         select new ActorCardContactsDTO
                                         {
                                             ActrorCard_ContactsId = item.ActrorCard_ContactsId,
                                             ActorCardRId = item.ActorCardRId,
                                             ContactCompany = item.ContactCompany,
                                             ContactEmail = item.ContactEmail,
                                             ContactName = item.ContactName,
                                             ContactPhone = item.ContactPhone,
                                             ContactType = item.ContactType,
                                             CreatedOn = item.CreatedOn,
                                             IsHidden = item.IsHidden,
                                             LastUpdatedDate = item.LastUpdatedDate,
                                             OriginalImdbContactRId = item.OriginalImdbContactRId,
                                             SortOrder = item.SortOrder
                                         }).ToList();
                }
                var folderLocation = _appSettings.ActorCardSaveUrlLocation;
               
                if (c.TblActorCardImages != null && c.TblActorCardImages.Count() > 0)
                {
                    dto.ActorCardImages = ((List<ActorCardImagesDTO>)(from item in c.TblActorCardImages
                                           select new ActorCardImagesDTO
                                           {
                                               ActorCardRId = item.ActorCardRId,
                                               Id = item.Id,
                                               IsDefault = item.IsDefault,
                                               PicturePath = item.PicturePath,
                                               ImageTarget = $"{folderLocation}\\{item.PicturePath}",
                                           }).ToList());
                }
                if (c.TblActorCardLinks != null && c.TblActorCardLinks.Count() > 0)
                {
                    dto.ActorCardLinks = (from item in c.TblActorCardLinks
                                          select new ActorCardLinksDTO
                                          {
                                              ActorCardRId = item.ActorCardRId,
                                              CreatedOn = item.CreatedOn,
                                              IsHidden = item.IsHidden,
                                              LastUpdatedDate = item.LastUpdatedDate,
                                              Link = item.Link,
                                              LinkId = item.LinkId,
                                              SortOrder = item.SortOrder,
                                              Title = item.Title
                                          }).ToList();
                }
                if (c.TblActorCardEthnicities != null && c.TblActorCardEthnicities.Count() > 0)
                {
                    dto.ActorCardEthnicities = (from item in c.TblActorCardEthnicities
                                          select new ActorCardEthnicityDTO
                                          {
                                              ActorCardRId = item.ActorCardRId,
                                              CreatedOn = item.CreatedOn,
                                              IsHidden = item.IsHidden,
                                               SortOrder=item.SortOrder,
                                          }).ToList();
                }
            }
            return dto;

        }
        private ActorCardSimplifiedDTO EntityToDTOSimplified(tblActorCard c)
        {
            ActorCardSimplifiedDTO dto = new ActorCardSimplifiedDTO();
            if (c != null)
            {
                var actorImdb = _actorCardImdbRepository.Get(dto.CastingList_IMDBActorId);
                if (actorImdb != null )
                {
                    dto.ImdbId =!string.IsNullOrEmpty(actorImdb.ImdbId) ? actorImdb.ImdbId:" ";
                    dto.RankStarMeeter = actorImdb.RanKStarMeeter;
                }
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.AgeRange = c.AgeRange;
                dto.BOD = c.BOD;
                dto.CastingList_IMDBActorId = c.CastingList_IMDBActorId;
                dto.CreatedOn = c.CreatedOn;
                dto.DisplayName = c.DisplayName;
                dto.GenderRId = c.GenderRId;
                dto.HeightFeet = c.HeightFeet;
                dto.HeightInches = c.HeightInches;
                dto.Id = c.Id;
                dto.IsHidden = c.IsHidden;
                dto.ListRId = c.ListRId;
                dto.MasterCast_ClientId = c.MasterCast_ClientId;
                dto.MasterCast_RosterId = c.MasterCast_RosterId;
                dto.Notes = c.Notes;
                dto.RoleRId = c.RoleRId;
                dto.ProjectRId = c.ProjectRId;
                dto.SortOrder = c.SortOrder;
               
                
            }
            return dto;

        }
        private tblActorCard DTOToEntity(ActorCardDTO c)
        {
            tblActorCard dto = new tblActorCard();
            dto.CreatedByUserId = c.CreatedByUserId;
            dto.CreatedByUserType = c.CreatedByUserType;
            dto.LastUpdatedDate = DateTime.Now;
            dto.AgeRange = c.AgeRange;
            dto.BOD = c.BOD;
            dto.CastingList_IMDBActorId = c.CastingList_IMDBActorId;
            dto.CreatedOn = DateTime.Now;
            dto.DisplayName = c.DisplayName;
            dto.GenderRId = c.GenderRId;
            dto.HeightFeet = c.HeightFeet;
            dto.HeightInches = c.HeightInches;
            dto.Id = c.Id;
            dto.IsHidden = c.IsHidden;
            dto.ListRId = c.ListRId;
            dto.MasterCast_ClientId = c.MasterCast_ClientId;
            dto.MasterCast_RosterId = c.MasterCast_RosterId;
            dto.Notes = c.Notes;
            dto.RoleRId = c.RoleRId;
            dto.ProjectRId = c.ProjectRId;
            dto.SortOrder = c.SortOrder;
            return dto;
        }

        public void UpdateSortOrder(List<ActorSortDTO> dto)
        {
            _actorCardRepository.UpdateActorCardSortOrder(dto);
        }

        public void UpdateSatus(List<ActorStatusDTO> dto)
        {
            _actorCardRepository.UpdateActorCardStatus(dto);
        }

        public async Task<ValidateActorResponse> ValidateActor(ValidateActorDTO c)
        {
            ValidateActorResponse validate = new ValidateActorResponse();
            var exists = _actorCardRepository.ValidateActor(c);
            if (exists != null && exists.Count() > 0)
            {
                validate.AlreadyExists = true;

            }
            var duplicateList = await _clientRepository.GetClientByImdb(c.ImdbActorId, c.CreatedByUserId);
            if (duplicateList != null && duplicateList.Count() > 0)
            {
                validate.TalentMatchingFound = true;

                validate.Duplicates = duplicateList;
            }
            else
            {
                var ExistActorImdb = _actorRepository.GetById(c.ActorId);

                if (ExistActorImdb != null)
                {
                    string fullname = ExistActorImdb.FirstName + " " + ExistActorImdb.LastName;
                    GlobalSearchClient globalSearchClient = new GlobalSearchClient();
                    globalSearchClient.CreatedByUserId = c.CreatedByUserId;
                    globalSearchClient.Clientname = fullname;
                    var duplicateExists = await _clientRepository.GetClients(globalSearchClient);
                    if (duplicateExists != null && duplicateExists.Count() > 0)
                    {
                        validate.TalentMatchingFound = true;
                        validate.Duplicates = duplicateExists.ToList();
                    }
                    else
                    {
                        validate.IsValid = true;
                    }

                }


            }
            return validate;
        }

        public IEnumerable<ActorCardDTO> GetByListId(int listid, int userid, int usertype)
        {
            List<ActorCardDTO> dtolist = new List<ActorCardDTO>();
            var list = _actorCardRepository.GetActorCardByListId(listid, userid, usertype);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    var obj = new ActorCardDTO();

                    obj = EntityToDTO(item);

                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }

        public IEnumerable<ActorCardSimplifiedDTO> GetByListSimplified(int listid, int userid, int usertype)
        {
            List<ActorCardSimplifiedDTO> dtolist = new List<ActorCardSimplifiedDTO>();
            var list = _actorCardRepository.GetActorCardByListId(listid, userid, usertype);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    var obj = new ActorCardSimplifiedDTO();

                    obj = EntityToDTOSimplified(item);

                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }
    }
}

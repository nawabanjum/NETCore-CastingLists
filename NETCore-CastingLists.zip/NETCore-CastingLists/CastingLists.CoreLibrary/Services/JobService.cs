﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class JobService : IJobService
    {
        private readonly ProjectManContext _context;
        private readonly IJobRepository _jobRepository;
        private readonly ILogger<JobService> _logger;
        public JobService(ProjectManContext context, IJobRepository jobRepository, ILogger<JobService> logger)
        {
            _context = context;
            _jobRepository = jobRepository;
            _logger = logger;
        }
        public Task<IEnumerable<JobDTO>> GetAvailableJob(int agencyId, bool projectDirector)
        {
            try
            {
              return  _jobRepository.GetAvailableJob(agencyId, projectDirector);
                
            }
            catch (Exception e)
            {
               _logger.LogError(e, $"GetAvailableJob for {nameof(agencyId)}:{projectDirector} - {e.Message}", e);
                throw;
            }
        }
    }
}

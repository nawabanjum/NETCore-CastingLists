﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorService : IActorService
    {
        private readonly IActorRepository _actorRepository;
        private readonly IActorContactsRepository _actorContactsRepository;
        private readonly ISocialLinkRepository _socialLinkRepository;
        private readonly IKnowsForRepository _knowsForRepository;
        private readonly IActorImdbArchiveRepository _actorImdbArchiveRepository;
        private readonly IFilmographyRepository _filmographyRepository;
        IHostingEnvironment _env;
        private readonly IHttpClientFactory _clientFactory;
        private UploadSettings _appSettings { get; set; }
        private IOptions<ValidImageExtensions> _validImageExtensions;
        public ActorService(IHostingEnvironment env, IHttpClientFactory clientFactory, IOptions<UploadSettings> uploadSettings, IOptions<ValidImageExtensions> validImageExtensions, IFilmographyRepository filmographyRepository, IActorImdbArchiveRepository actorImdbArchiveRepository, IKnowsForRepository knowsForRepository, ISocialLinkRepository socialLinkRepository,
            IActorRepository actorRepository, IActorContactsRepository actorContactsRepository)
        {
            _actorRepository = actorRepository;
            _actorContactsRepository = actorContactsRepository;
            _socialLinkRepository = socialLinkRepository;
            _knowsForRepository = knowsForRepository;
            _actorImdbArchiveRepository = actorImdbArchiveRepository;
            _appSettings = uploadSettings.Value;
            _env = env;
            _clientFactory = clientFactory;
            _validImageExtensions = validImageExtensions;
            _filmographyRepository = filmographyRepository;
        }
        public ServiceResponse Add(ActorImportDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();

            tblActorImdb model = new tblActorImdb();
            try
            {
                var ActorByImdbIdExists = GetActorByImdbId(c.ImdbId);
                if (ActorByImdbIdExists != null)
                {
                    ActorByImdbIdExists.FirstName = !string.IsNullOrEmpty(c.FirstName) ? c.FirstName : ActorByImdbIdExists.FirstName;
                    ActorByImdbIdExists.LastName = !string.IsNullOrEmpty(c.LastName) ? c.LastName : ActorByImdbIdExists.LastName;
                    ActorByImdbIdExists.AgeRange = !string.IsNullOrEmpty(c.AgeRange) ? c.AgeRange : ActorByImdbIdExists.AgeRange;
                    ActorByImdbIdExists.CreatedByUserId = c.CreatedByUserId > 0 ? c.CreatedByUserId : ActorByImdbIdExists.CreatedByUserId;
                    ActorByImdbIdExists.CreatedByUserType = c.CreatedByUserType > 0 ? c.CreatedByUserType : ActorByImdbIdExists.CreatedByUserType;
                    ActorByImdbIdExists.DateOfBirth = c.DateOfBirth != null ? c.DateOfBirth : ActorByImdbIdExists.DateOfBirth;
                    ActorByImdbIdExists.LastUpdatedDate = DateTime.Now;
                    ActorByImdbIdExists.Gender = !string.IsNullOrEmpty(c.Gender) ? c.Gender : ActorByImdbIdExists.Gender;
                    ActorByImdbIdExists.Ethnicity = !string.IsNullOrEmpty(c.Ethnicity) ? c.Ethnicity : ActorByImdbIdExists.Ethnicity;
                    ActorByImdbIdExists.Ranking = !string.IsNullOrEmpty(c.Ranking) ? c.Ranking : ActorByImdbIdExists.Ranking;
                    ActorByImdbIdExists.Weigth = !string.IsNullOrEmpty(c.Weigth) ? c.Weigth : ActorByImdbIdExists.Weigth;
                    //ActorByImdbIdExists.PictureUrl = !string.IsNullOrEmpty(c.PictureUrl) ? c.PictureUrl : ActorByImdbIdExists.PictureUrl;
                    ActorByImdbIdExists.OriginalPlatform = !string.IsNullOrEmpty(c.OriginalPlatform) ? c.OriginalPlatform : ActorByImdbIdExists.OriginalPlatform;

                    var response = Update(ActorByImdbIdExists);
                    c.ActorId = ActorByImdbIdExists.ActorId;
                    aPIResponse.Id = c.ActorId;
                    if (c.ActorContacts != null && c.ActorContacts.Count() > 0)
                    {
                        SaveContcts(c, model);
                    }
                    if (c.SocialLinks != null && c.SocialLinks.Count() > 0)
                    {
                        SaveSocialLinks(c, model);
                    }
                    if (c.KnowsFors != null && c.KnowsFors.Count() > 0)
                    {
                        SaveKnowsfor(c, model);
                    }
                    if (c.Filmography != null && c.Filmography.Count() > 0)
                    {
                        SaveFilmographyImdb(c, model);
                    }
                    return response;
                }

                model = DTOToEntity(c);
                _actorRepository.AddActor(model);
                c.ActorId = model.ActorId;
                aPIResponse.Id = c.ActorId;
                if (c.ActorContacts != null && c.ActorContacts.Count() > 0)
                {
                    SaveContcts(c, model);
                }
                if (c.SocialLinks.Count() > 0 && c.SocialLinks != null)
                {
                    SaveSocialLinks(c, model);
                }
                if (c.KnowsFors.Count() > 0 && c.KnowsFors != null)
                {
                    SaveKnowsfor(c, model);
                }
                if (c.Filmography.Count() > 0 && c.Filmography != null)
                {
                    SaveFilmographyImdb(c, model);
                }
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;

        }
        public void Delete(int id, int userid, int usertype)
        {
            _actorRepository.DeleteActor(id, userid, usertype);
        }
        public IEnumerable<ActorDTO> Get(int userid, int usertype)
        {
            List<ActorDTO> dtolist = new List<ActorDTO>();
            var list = _actorRepository.Get(userid, usertype);
            var folderLocation = _appSettings.ImdbSaveUrlLocation;
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    var obj = new ActorDTO();
                    obj.ActorId = item.ActorId;
                    obj.CreatedByUserId = item.CreatedByUserId;
                    obj.CreatedByUserType = item.CreatedByUserType;
                    obj.CreatedOn = item.CreatedOn;
                    obj.FirstName = item.FirstName;
                    obj.LastName = item.LastName;
                    obj.AgeRange = item.AgeRange;
                    obj.DateOfBirth = item.DateOfBirth;
                    obj.Ethnicity = item.Ethnicity;
                    obj.Gender = item.Gender;
                    obj.Height = item.Height;
                    obj.ImdbId = item.ImdbId;
                    obj.IsDeleted = item.IsDeleted;
                    obj.LastUpdatedDate = item.LastUpdatedDate;
                    obj.LastUpdatedPlatform = item.LastUpdatedPlatform;
                    obj.OriginalPlatform = item.OriginalPlatform;
                    obj.PictureUrl = item.PicturePath;
                    obj.ImageSourceUrl = item.ImageSourceUrl;
                    obj.Ranking = item.Ranking;
                    obj.Weigth = item.Weigth;
                    obj.ImageTarget = $"{folderLocation}\\{item.PicturePath}";
                    dtolist.Add(obj);

                }
            }
            return dtolist;
        }
        public IEnumerable<ActorDTO> GetByActor(string SearchText)
        {
            List<ActorDTO> dtolist = new List<ActorDTO>();
            var list = _actorRepository.SearchActorByName(SearchText);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public ActorDTO GetActorByImdbId(string ImdbId)
        {
            ActorDTO dto = null;
            var c = _actorRepository.GetActorByImdbId(ImdbId);
            if (c != null)
            {
                dto = new ActorDTO();
                dto = SaveActorImdbArchive(c);

            }
            return dto;
        }
        public ActorDTO GetById(int id, int userid, int usertype)
        {
            ActorDTO dto = new ActorDTO();
            var c = _actorRepository.GetActorById(id, userid, usertype);
            if (c != null)
            {
                dto = EntityToDTO(c);
            }
            return dto;
        }
        private ActorDTO EntityToDTO(tblActorImdb c)
        {
            ActorDTO dto = new ActorDTO();
            var folderLocation = _appSettings.ImdbSaveUrlLocation;
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = c.CreatedOn;
                dto.FirstName = c.FirstName;
                dto.LastName = c.LastName;
                dto.AgeRange = c.AgeRange;
                dto.DateOfBirth = c.DateOfBirth;
                dto.Ethnicity = c.Ethnicity;
                dto.Gender = c.Gender;
                dto.RankStarMeeter = c.RanKStarMeeter;
                dto.Height = c.Height;
                dto.ImdbId = c.ImdbId;
                dto.IsDeleted = c.IsDeleted;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.LastUpdatedPlatform = c.LastUpdatedPlatform;
                dto.OriginalPlatform = c.OriginalPlatform;
                dto.PictureUrl = c.PicturePath;
                dto.ImageSourceUrl = c.ImageSourceUrl;
                dto.Ranking = c.Ranking;
                dto.Weigth = c.Weigth;
                dto.ActorId = c.ActorId;
                dto.ImageTarget = $"{folderLocation}\\{c.PicturePath}";
            }
            return dto;

        }
        private tblActorImdb DTOToEntity(ActorImportDTO c)
        {
            tblActorImdb dto = new tblActorImdb();
            dto.CreatedByUserId = c.CreatedByUserId;
            dto.CreatedByUserType = c.CreatedByUserType;
            dto.CreatedOn = DateTime.Now;
            dto.FirstName = c.FirstName;
            dto.LastName = c.LastName;
            dto.AgeRange = c.AgeRange;
            dto.DateOfBirth = c.DateOfBirth;
            dto.Ethnicity = c.Ethnicity;
            dto.Gender = c.Gender;
            dto.Height = c.Height;
            if (!string.IsNullOrEmpty(c.ImageSourceUrl))
            {
                dto.PicturePath = SaveImage(c.ImageSourceUrl);
                dto.ImageSourceUrl = c.ImageSourceUrl;
            }

            dto.ImdbId = c.ImdbId;
            dto.IsDeleted = c.IsDeleted;
            dto.LastUpdatedDate = DateTime.Now;
            dto.LastUpdatedPlatform = DateTime.Now;
            dto.OriginalPlatform = c.OriginalPlatform;
            dto.Ranking = c.Ranking;
            dto.Weigth = c.Weigth;
            dto.ActorId = c.ActorId;
            return dto;
        }
        public ServiceResponse Update(ActorDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorImdb model = new tblActorImdb();
            try
            {
                model = _actorRepository.GetActorById(c.ActorId, c.CreatedByUserId, c.CreatedByUserType);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActorId = c.ActorId;
                model.FirstName = c.FirstName;
                model.LastName = c.LastName;
                model.AgeRange = c.AgeRange;
                model.DateOfBirth = c.DateOfBirth;
                model.Ethnicity = c.Ethnicity;
                model.Gender = c.Gender;
                model.Height = c.Height;
                model.ImdbId = c.ImdbId;
                model.IsDeleted = c.IsDeleted;
                model.LastUpdatedDate = DateTime.Now;
                model.LastUpdatedPlatform = DateTime.Now;
                model.OriginalPlatform = c.OriginalPlatform;
                model.PicturePath = c.PictureUrl;
                model.ImageSourceUrl = c.ImageSourceUrl;
                model.Ranking = c.Ranking;
                model.Weigth = c.Weigth;
                _actorRepository.UpdateActor(model);
                aPIResponse.Id = model.ActorId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private void SaveContcts(ActorImportDTO c, tblActorImdb model)
        {
            _actorContactsRepository.DeleteActorContactByActorId(c.ActorId);
            foreach (var item in c.ActorContacts)
            {
                var obj = new tblActorContacts();
                obj.ActorRId = c.ActorId;
                obj.CreatedOn = DateTime.Now;
                obj.IsDeleted = item.IsDeleted;
                obj.LastUpdatedDate = DateTime.Now;
                obj.ContactPhone = item.ContactPhone;
                obj.ContactCompany = item.ContactCompany;
                obj.ContactCompanyAddress = item.ContactCompanyAddress;
                obj.ContactCompanyEmail = item.ContactCompanyEmail;
                obj.ContactCompanyImdb = item.ContactCompanyImdb;
                obj.ContactCompanyPhone = item.ContactCompanyPhone;
                obj.ContactCompanyWebSite = item.ContactCompanyWebSite;
                obj.ContactCountry = item.ContactCountry;
                obj.ContactEmail = item.ContactEmail;
                obj.ContactGroup = item.ContactGroup;
                obj.ContactImdbLink = item.ContactImdbLink;
                obj.ContactName = item.ContactName;
                obj.ContactWebSite = item.ContactWebSite;
                obj.ContactType = item.ContactType;
                obj.ContactId = item.ContactId;
                _actorContactsRepository.AddActorContact(obj);
            }
        }
        private void SaveSocialLinks(ActorImportDTO c, tblActorImdb model)
        {
            foreach (var item in c.SocialLinks)
            {
                var existsList = _socialLinkRepository.GetSocialLinkByActorId(c.ActorId);
                if (existsList != null && existsList.Count() > 0)
                {
                    var exists = existsList.Where(a => a.Link == item.Link && a.Title == item.Title).FirstOrDefault();
                    if (exists != null)
                    {
                        exists.LastUpdatedDate = DateTime.Now;
                        _socialLinkRepository.UpdateSocialLink(exists);
                        continue;
                    }
                }
                var obj = new tblSocialLinks();
                obj.ActorRId = c.ActorId;
                obj.Link = item.Link;
                obj.Title = item.Title;
                obj.CreatedOn = DateTime.Now;
                obj.LastUpdatedDate = DateTime.Now;
                _socialLinkRepository.AddSocialLink(obj);
            }
        }
        private void SaveKnowsfor(ActorImportDTO c, tblActorImdb model)
        {
            _knowsForRepository.DeleteKnowsForByActorId(c.ActorId);
            foreach (var item in c.KnowsFors)
            {
                var obj = new tblKnowsFor();
                obj.ActorRId = c.ActorId;
                obj.Link = item.Link;
                obj.Title = item.Title;
                obj.StartYear = item.StartYear;
                obj.EndYear = item.EndYear;
                obj.FullDescription = item.FullDescription;
                obj.CreatedOn = DateTime.Now;
                obj.LastUpdatedDate = DateTime.Now;
                _knowsForRepository.AddKnowsFor(obj);
            }
        }
        private ActorDTO SaveActorImdbArchive(tblActorImdb c)
        {
            ActorDTO dto = EntityToDTO(c);
            var model = new tblActorImdbArchive();
            model.ActorRId = c.ActorId;
            model.CreatedByUserId = c.CreatedByUserId;
            model.CreatedByUserType = c.CreatedByUserType;
            model.CreatedOn = DateTime.Now;
            model.ImdbId = c.ImdbId;

            //model.Json = JsonConvert.SerializeObject(c);
            model.Json = JsonConvert.SerializeObject(c, Formatting.None,
                        new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        });
            _actorImdbArchiveRepository.AddActorImdb(model);
            return dto;
        }
        private void SaveFilmographyImdb(ActorImportDTO c, tblActorImdb model)
        {

            foreach (var item in c.Filmography)
            {
                tblFilmographyImdb obj = new tblFilmographyImdb();
                obj.ActorRId = c.ActorId;
                obj.CreatedOn = DateTime.Now;
                obj.EndYear = item.EndYear;
                obj.FullDescription = item.FullDescription;
                obj.ImdbId = ExtractImdbId(item.ImdbId);
                obj.IsDeleted = item.IsDeleted;
                obj.LastUpdatedDate = DateTime.Now;
                obj.Link = item.Link;
                obj.StartYear = item.StartYear;
                obj.Title = item.Title;
                _filmographyRepository.AddFilmography(obj);
            }

        }
        public ServiceResponse UpdateRanking(ActorRankDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorImdb model = new tblActorImdb();
            model = _actorRepository.GetById(c.ActorId);
            if (model == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model.RanKStarMeeter = c.RankStarMeeter;
            _actorRepository.UpdateActor(model);
            return aPIResponse;
        }
        public ServiceResponse UpdateImage(ActorImageDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorImdb model = new tblActorImdb();
            model = _actorRepository.GetById(c.ActorId);
            if (model == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model.PicturePath = c.ImageLink;
            model.ImageSourceUrl = c.ImageSourceUrl;
            model.LastUpdatedDate = DateTime.Now;
            _actorRepository.UpdateActor(model);
            return aPIResponse;
        }
        private string ExtractImdbId(string ImdbId)
        {
            string imdbid = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(ImdbId))
                {
                    var imdb = ImdbId.Split('/');
                    if (imdb != null)
                    {
                        imdbid = imdb[4];
                    }
                }
            }
            catch (Exception ex)
            {
                imdbid = "";
            }
            return imdbid;
        }
        private string SaveImage(string ImageSourceUrl)
        {
            string fileName = string.Empty;
            CommonOperations commonOperations = new CommonOperations();
            var validImageExtensionsArray = _validImageExtensions.Value.Extensions.Split(",");

            // save picture in the actor imdb configuration folder
            var response = commonOperations.UploadImageImdb(ImageSourceUrl, _appSettings, _clientFactory.CreateClient(), validImageExtensionsArray).Result;
            if (response.IsError == false)
            {
                fileName = response.ServiceResponseMessage;
            }
            return fileName;
        }
    }
}

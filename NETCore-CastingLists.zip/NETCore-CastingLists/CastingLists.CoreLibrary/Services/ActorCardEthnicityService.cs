﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardEthnicityService : IActorCardEthnicityService
    {
        private readonly IActorCardRepository _actorRepository;
        private readonly IActorCardEthnicityRepository _actorCardEthnicityRepository;
        public ActorCardEthnicityService(IActorCardRepository actorCardRepository, IActorCardEthnicityRepository actorCardEthnicityRepository)
        {
            _actorRepository = actorCardRepository;
            _actorCardEthnicityRepository = actorCardEthnicityRepository;
        }
        public ServiceResponse Add(ActorCardEthnicityDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorCardEthnicity obj = DTOToEntity(c);
                _actorCardEthnicityRepository.AddActorCardEthnicity(obj);
                aPIResponse.Id = obj.ActorCard_EthnicityId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id)
        {
            _actorCardEthnicityRepository.DeleteActorCardEthnicity(id);
        }
        public IEnumerable<ActorCardEthnicityDTO> Get(int CastingList_ActorId)
        {
            List<ActorCardEthnicityDTO> dtolist = new List<ActorCardEthnicityDTO>();
            var list = _actorCardEthnicityRepository.Get(CastingList_ActorId);
            if (list !=null && list.Count()>0)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public ActorCardEthnicityDTO GetById(int id)
        {
            ActorCardEthnicityDTO obj = new ActorCardEthnicityDTO();
            var model= _actorCardEthnicityRepository.GetById(id);
            return EntityToDTO(model);
        }
        public ServiceResponse Update(ActorCardEthnicityDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardEthnicityRepository.GetById(c.ActorCard_EthnicityId);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardEthnicityIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActorCard_EthnicityId = c.ActorCard_EthnicityId;
                model.ActorCardRId = c.ActorCardRId;
                model.EthnicityRId = c.EthnicityRId;
                model.IsHidden = c.IsHidden;
                model.SortOrder = c.SortOrder;
                _actorCardEthnicityRepository.UpdateActorCardEthnicity(model);
                aPIResponse.Id = model.ActorCard_EthnicityId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private ActorCardEthnicityDTO EntityToDTO(tblActorCardEthnicity c)
        {
            ActorCardEthnicityDTO dto = new ActorCardEthnicityDTO();
            if (c != null)
            {
                dto.ActorCard_EthnicityId = c.ActorCard_EthnicityId;
                dto.ActorCardRId = c.ActorCardRId;
                dto.CreatedOn = c.CreatedOn;
                dto.EthnicityRId = c.EthnicityRId;
                dto.IsHidden = c.IsHidden;
                dto.SortOrder = c.SortOrder;
            }
            return dto;
        }
        private tblActorCardEthnicity DTOToEntity(ActorCardEthnicityDTO c)
        {
            tblActorCardEthnicity obj = new tblActorCardEthnicity();
            if (c != null)
            {
                obj.ActorCard_EthnicityId = c.ActorCard_EthnicityId;
                obj.ActorCardRId = c.ActorCardRId;
                obj.CreatedOn = DateTime.Now;
                obj.EthnicityRId = c.EthnicityRId;
                obj.IsHidden = c.IsHidden;
                obj.SortOrder = c.SortOrder;
            }
            return obj;
        }
        public void UpdateSortOrder(List<ActorSortDTO> dto)
        {
            _actorCardEthnicityRepository.UpdateActorCardEthnicitySortOrder(dto);
        }
        public void UpdateSatus(List<ActorStatusDTO> dto)
        {
            _actorCardEthnicityRepository.UpdateActorCardEthnicityStatus(dto);
        }
    }
}

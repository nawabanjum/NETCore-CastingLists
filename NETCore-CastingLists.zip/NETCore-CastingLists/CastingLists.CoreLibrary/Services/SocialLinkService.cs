﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class SocialLinkService : ISocialLinkService
    {
        private readonly IActorRepository _actorRepository;
        private readonly ISocialLinkRepository _socialLinkRepository;
        public SocialLinkService(IActorRepository actorRepository, ISocialLinkRepository socialLinkRepository)
        {
            _socialLinkRepository = socialLinkRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(SocialLinkDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {


                var actor = _actorRepository.GetById(c.ActorRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblSocialLinks obj = new tblSocialLinks();
                obj = DTOToEntity(c);
                _socialLinkRepository.AddSocialLink(obj);
                aPIResponse.Id = obj.LinkId;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id)
        {
            _socialLinkRepository.DeleteSocialLink(id);
        }
        public IEnumerable<SocialLinkDTO> GetByActorId(int actorid)
        {
            List<SocialLinkDTO> dtolist = new List<SocialLinkDTO>();
            var list = _socialLinkRepository.GetSocialLinkByActorId(actorid);
            foreach (var item in list)
            {
                dtolist.Add(EntityToDTO(item));
            }
            return dtolist;
        }
        public SocialLinkDTO GetById(int id)
        {
            SocialLinkDTO dto = new SocialLinkDTO();
            var c = _socialLinkRepository.GetSocialLinkById(id);
            if (c != null)
            {
                dto.ActorRId = c.ActorRId;
                dto.CreatedOn = c.CreatedOn;
                dto.IsDeleted = c.IsDeleted;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.Link = c.Link;
                dto.LinkId = c.LinkId;
                dto.Title = c.Title;
            }
            return dto;
        }
        public ServiceResponse Update(SocialLinkDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblSocialLinks model = new tblSocialLinks();
            try
            {

            
            var actor = _actorRepository.GetById(c.ActorRId);
            if (actor == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model = _socialLinkRepository.GetSocialLinkById(c.LinkId);

            if (model == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.SocialLinkIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model.ActorRId = c.ActorRId;
            model.IsDeleted = c.IsDeleted;
            model.LastUpdatedDate = DateTime.Now;
            model.Link = c.Link;
            model.LinkId = c.LinkId;
            model.Title = c.Title;
            _socialLinkRepository.UpdateSocialLink(model);
                aPIResponse.Id = model.LinkId;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private SocialLinkDTO EntityToDTO(tblSocialLinks c)
        {
            SocialLinkDTO dto = new SocialLinkDTO();
            if (c != null)
            {
                dto.ActorRId = c.ActorRId;
                dto.CreatedOn = c.CreatedOn;
                dto.IsDeleted = c.IsDeleted;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.Link = c.Link;
                dto.LinkId = c.LinkId;
                dto.Title = c.Title;
            }
            return dto;
        }
        private tblSocialLinks DTOToEntity(SocialLinkDTO c)
        {
            tblSocialLinks obj = new tblSocialLinks();
            obj.ActorRId = c.ActorRId;
            obj.CreatedOn = DateTime.Now;
            obj.IsDeleted = c.IsDeleted;
            obj.LastUpdatedDate = DateTime.Now;
            obj.Link = c.Link;
            obj.LinkId = c.LinkId;
            obj.Title = c.Title;
            return obj;
        }
    }
}

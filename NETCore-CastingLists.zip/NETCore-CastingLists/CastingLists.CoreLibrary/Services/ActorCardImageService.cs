﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardImageService : IActorCardImageService
    {
        private readonly IActorCardRepository  _actorCardRepository;
        private readonly IActorCardImageRepository   _actorCardImageRepository;
        public ActorCardImageService(IActorCardImageRepository  actorCardImageRepository, IActorCardRepository  actorCardRepository)
        {
            _actorCardRepository = actorCardRepository;
            _actorCardImageRepository = actorCardImageRepository;
        }
        public ServiceResponse Add(ActorCardImagesDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorCardRepository.GetById(c.ActorCardRId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var obj = DTOToEntity(c);
                _actorCardImageRepository.AddActorCardImage(obj);
                aPIResponse.Id = obj.Id;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int Id)
        {
            _actorCardImageRepository.DeleteActorCardImage(Id);
        }
        private tblActorCardImages DTOToEntity(ActorCardImagesDTO c)
        {
            tblActorCardImages obj = new tblActorCardImages();
            obj.PicturePath = c.PicturePath;
            obj.ActorCardRId = c.ActorCardRId;
            obj.Id = c.Id;
            return obj;
        }
    }
}

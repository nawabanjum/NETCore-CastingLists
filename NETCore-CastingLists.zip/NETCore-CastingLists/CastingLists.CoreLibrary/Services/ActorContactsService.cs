﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorContactsService : IActorContactsService
    {
        private readonly IActorRepository _actorRepository;
        private readonly IActorContactsRepository _actorContactsRepository;
        public ActorContactsService(IActorRepository actorRepository, IActorContactsRepository actorContactsRepository)
        {
            _actorContactsRepository = actorContactsRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(ActorContactsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorContacts obj = DTOToEntity(c);
                _actorContactsRepository.AddActorContact(obj);
                aPIResponse.Id = obj.ContactId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id)
        {
            _actorContactsRepository.DeleteActorContact(id);
        }
        public IEnumerable<ActorContactsDTO> GetByActorId(int actorid)
        {
            List<ActorContactsDTO> dtolist = new List<ActorContactsDTO>();
            var list = _actorContactsRepository.GetActorContactByActorId(actorid);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public ActorContactsDTO GetById(int id)
        {
            var c = _actorContactsRepository.GetActorContactById(id);
            return EntityToDTO(c);
        }
        public ServiceResponse Update(ActorContactsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorContacts model = new tblActorContacts();
            var actor = _actorRepository.GetById(c.ActorId);
            if (actor == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model = _actorContactsRepository.GetActorContactById(c.ContactId);
            if (model == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorContactIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model.ActorRId = c.ActorId;
            model.IsDeleted = c.IsDeleted;
            model.LastUpdatedDate = c.LastUpdatedDate;
            model.ContactCompanyPhone = c.ContactCompanyPhone;
            model.ContactName = c.ContactName;
            model.ContactEmail = c.ContactEmail;
            model.ContactCompany = c.ContactCompany;
            model.ContactType = c.ContactType;
            model.ContactCompanyAddress = c.ContactCompanyAddress;
            model.ContactCompanyEmail = c.ContactCompanyEmail;
            model.ContactCompanyImdb = c.ContactCompanyImdb;
            model.ContactCompanyWebSite = c.ContactCompanyWebSite;
            model.ContactCountry = c.ContactCountry;
            model.ContactGroup = c.ContactGroup;
            model.ContactImdbLink = c.ContactImdbLink;
            model.ContactPhone = c.ContactPhone;
            model.ContactWebSite = c.ContactWebSite;
            model.ContactId = c.ContactId;
            _actorContactsRepository.UpdateActorContact(model);
            return aPIResponse;
        }
        private ActorContactsDTO EntityToDTO(tblActorContacts c)
        {
            ActorContactsDTO dto = new ActorContactsDTO();
            if (c != null)
            {
                dto.ActorId = c.ActorRId;
                dto.CreatedOn = c.CreatedOn;
                dto.IsDeleted = c.IsDeleted;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.ContactPhone = c.ContactPhone;
                dto.ContactCompany = c.ContactCompany;
                dto.ContactCompanyAddress = c.ContactCompanyAddress;
                dto.ContactCompanyEmail = c.ContactCompanyEmail;
                dto.ContactCompanyImdb = c.ContactCompanyImdb;
                dto.ContactCompanyPhone = c.ContactCompanyPhone;
                dto.ContactCompanyWebSite = c.ContactCompanyWebSite;
                dto.ContactCountry = c.ContactCountry;
                dto.ContactEmail = c.ContactEmail;
                dto.ContactGroup = c.ContactGroup;
                dto.ContactImdbLink = c.ContactImdbLink;
                dto.ContactName = c.ContactName;
                dto.ContactWebSite = c.ContactWebSite;
                dto.ContactType = c.ContactType;
                dto.ContactId = c.ContactId;
            }
            return dto;
        }
        private tblActorContacts DTOToEntity(ActorContactsDTO c)
        {
            tblActorContacts obj = new tblActorContacts();
            obj.ActorRId = c.ActorId;
            obj.CreatedOn = DateTime.Now;
            obj.IsDeleted = c.IsDeleted;
            obj.LastUpdatedDate = DateTime.Now;
            obj.ContactPhone = c.ContactPhone;
            obj.ContactCompany = c.ContactCompany;
            obj.ContactCompanyAddress = c.ContactCompanyAddress;
            obj.ContactCompanyEmail = c.ContactCompanyEmail;
            obj.ContactCompanyImdb = c.ContactCompanyImdb;
            obj.ContactCompanyPhone = c.ContactCompanyPhone;
            obj.ContactCompanyWebSite = c.ContactCompanyWebSite;
            obj.ContactCountry = c.ContactCountry;
            obj.ContactEmail = c.ContactEmail;
            obj.ContactGroup = c.ContactGroup;
            obj.ContactImdbLink = c.ContactImdbLink;
            obj.ContactName = c.ContactName;
            obj.ContactWebSite = c.ContactWebSite;
            obj.ContactType = c.ContactType;
            obj.ContactId = c.ContactId;
            return obj;
        }
       

    }
}

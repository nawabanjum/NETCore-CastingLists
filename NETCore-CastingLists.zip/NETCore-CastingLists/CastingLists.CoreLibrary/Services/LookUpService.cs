﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class LookUpService : ILookUpService
    {
        private readonly ILookupRepository _lookupRepository;
        public LookUpService(ILookupRepository lookupRepository)
        {
            _lookupRepository = lookupRepository;
        }
        public IEnumerable<CommonLookUpDTO> GetListLookup(int userid, int usertype, int projectid)
        {
            return _lookupRepository.GetListLookup(userid, usertype, projectid);
        }
        public IEnumerable<CommonLookUpDTO> GetProjectsLookup(int userid, int usertype)
        {
            return _lookupRepository.GetProjectsLookup(userid, usertype);
        }
        public IEnumerable<CommonLookUpDTO> GetProjectsSource()
        {
            return _lookupRepository.GetProjectsSourceList();
        }
        public IEnumerable<CommonLookUpDTO> GetProjectType()
        {
            return _lookupRepository.GetProjectTypeList();
        }
        public IEnumerable<CommonLookUpDTO> GetRolesLookup(int userid, int usertype, int projectid)
        {
            return _lookupRepository.GetRolesLookup(userid, usertype, projectid);
        }
        public IEnumerable<CommonLookUpDTO> GetGenderType()
        {
            return _lookupRepository.GetGenderTypeLookup();
        }
        public IEnumerable<CommonLookUpDTO> GetEthnicities()
        {
            return _lookupRepository.GetEthnicitiesLookup();
        }
        public IEnumerable<FilmographyDTO> GetFilmography(string ImdbId)
        {
            return _lookupRepository.GetFilmographyLookup(ImdbId);
        }
    }
}

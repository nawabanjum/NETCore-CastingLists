﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorPrivateNotesService : IActorPrivateNotesService
    {
        private readonly IActorRepository _actorRepository;

        private readonly IActorPrivateNotesRepository _actorPrivateNotesRepository;

        public ActorPrivateNotesService(IActorRepository actorRepository, IActorPrivateNotesRepository actorPrivateNotes)
        {
            _actorPrivateNotesRepository = actorPrivateNotes;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(ActorPrivateNotesDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {

                var actor = _actorRepository.GetById(c.ActorId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblActorPriveNotes obj = DTOToEntity(c);
                _actorPrivateNotesRepository.AddActorPrivateNotes(obj);
                aPIResponse.Id = obj.Id;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id, int userid, int usertype)
        {
            _actorPrivateNotesRepository.DeleteActorPrivateNotes(id, userid, usertype);
        }
        public IEnumerable<ActorPrivateNotesDTO> Get(int userid, int usertype, int actorid)
        {
            var list = _actorPrivateNotesRepository.Get(userid, usertype, actorid);
            List<ActorPrivateNotesDTO> dtolist = new List<ActorPrivateNotesDTO>();
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public ActorPrivateNotesDTO GetById(int id, int userid, int usertype)
        {
            var c = _actorPrivateNotesRepository.GeActorPrivateNotesById(id, userid, usertype);
            return EntityToDTO(c);
        }
        public ServiceResponse Update(ActorPrivateNotesDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorPriveNotes model = new tblActorPriveNotes();
            try
            {
                var actor = _actorRepository.GetById(c.ActorId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model = _actorPrivateNotesRepository.GeActorPrivateNotesById(c.Id, c.CreatedByUserId, c.CreatedByUserType);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorPrivatenotesIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.ActorRId = c.ActorId;
                model.Id = c.Id;
                model.Note = c.Note;
                _actorPrivateNotesRepository.UpdateActorPrivateNotes(model);
                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private ActorPrivateNotesDTO EntityToDTO(tblActorPriveNotes c)
        {
            ActorPrivateNotesDTO dto = new ActorPrivateNotesDTO();
            if (c != null)
            {
                dto.ActorId = c.ActorRId;
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.Note = c.Note;
                dto.Id = c.Id;
            }
            return dto;

        }
        private tblActorPriveNotes DTOToEntity(ActorPrivateNotesDTO c)
        {
            tblActorPriveNotes obj = new tblActorPriveNotes();
            obj.ActorRId = c.ActorId;
            obj.CreatedByUserId = c.CreatedByUserId;
            obj.CreatedByUserType = c.CreatedByUserType;
            obj.Note = c.Note;
            obj.Id = c.Id;
            return obj;
        }
    }
}

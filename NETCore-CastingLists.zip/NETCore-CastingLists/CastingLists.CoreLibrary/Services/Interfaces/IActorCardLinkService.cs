﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorCardLinkService
    {
        IEnumerable<ActorCardLinksDTO> Get(int CastingList_ActorId);
        ActorCardLinksDTO GetById(int id);
        ServiceResponse Add(ActorCardLinksDTO c);
        ServiceResponse Update(ActorCardLinksDTO c);
        void Delete(int id);
    }
}

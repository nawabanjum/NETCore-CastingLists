﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorPrivateNotesService
    {
        IEnumerable<ActorPrivateNotesDTO> Get(int userid, int usertype,int actorid);
        ActorPrivateNotesDTO GetById(int id, int userid, int usertype);
        ServiceResponse Add(ActorPrivateNotesDTO c);
        ServiceResponse Update(ActorPrivateNotesDTO c);

        void Delete(int id, int userid, int usertype);
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorCardImageService
    {
        ServiceResponse Add(ActorCardImagesDTO c);
        void Delete(int Id);
    }
}

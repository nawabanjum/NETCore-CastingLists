﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorImdbImagesService
    {
        IEnumerable<ActorImdbImagesListDTO> Get(int actorid);

        ServiceResponse Add(ActorImdbImagesDTO c);
        void Delete(int Id);
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorCardContactsService
    {
        IEnumerable<ActorCardContactsDTO> Get(int CastingList_ActorId);
        ActorCardContactsDTO GetById(int id);
        ServiceResponse Add(ActorCardContactsDTO c);
        ServiceResponse Update(ActorCardContactsDTO c);
        void Delete(int id);
        void UpdateSortOrder(List<ActorSortDTO> dto);
        void UpdateSatus(List<ActorStatusDTO> dto);

    }
}

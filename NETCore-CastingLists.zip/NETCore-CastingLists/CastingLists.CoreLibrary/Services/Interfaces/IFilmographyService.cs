﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IFilmographyService
    {
        IEnumerable<FilmographyDTO> GetByActorId(int actorid);
        FilmographyDTO GetById(int id);
        ServiceResponse Add(FilmographyDTO c);
        ServiceResponse Update(FilmographyDTO c);
        void Delete(int id);
    }
}

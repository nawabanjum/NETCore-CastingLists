﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorService
    {

        IEnumerable<ActorDTO> Get(int userid, int usertype);
        IEnumerable<ActorDTO> GetByActor(string SearchText);
        ActorDTO GetById(int id, int userid, int usertype);
        ActorDTO GetActorByImdbId(string ImdbId);
        ServiceResponse Add(ActorImportDTO c);
        ServiceResponse Update(ActorDTO c);
        ServiceResponse UpdateRanking(ActorRankDTO c);
        ServiceResponse UpdateImage(ActorImageDTO c);

        void Delete(int id, int userid, int usertype);
    }
}

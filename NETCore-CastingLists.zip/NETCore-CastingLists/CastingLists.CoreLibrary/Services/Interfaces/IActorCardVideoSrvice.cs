﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
   public interface IActorCardVideoSrvice
    {
        IEnumerable<ActorCardVideoDTO> Get(int CastingList_ActorRId);
        ActorCardVideoDTO GetById(int id);
        ServiceResponse Add(ActorCardVideoDTO c);
        ServiceResponse Update(ActorCardVideoDTO c);
        void Delete(int id);
        void UpdateSortOrder(List<ActorSortDTO> dto);
        void UpdateSatus(List<ActorStatusDTO> dto);

    }
}

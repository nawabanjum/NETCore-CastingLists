﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IProjectService
    {
        IEnumerable<ProjectDTO> Get(int userid,int usertype);
        ProjectDTO GetById(int id, int userid, int usertype);

        ServiceResponse Add(ProjectDTO c);
        ServiceResponse Update(ProjectDTO c);

        void Delete(int id, int userid, int usertype);
    }
}

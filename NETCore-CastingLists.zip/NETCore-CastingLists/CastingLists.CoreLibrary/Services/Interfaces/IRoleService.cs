﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IRoleService
    {
        IEnumerable<RoleDTO> Get(int userid, int usertype, int projectid);
        RoleDTO GetById(int id, int userid, int usertype);
        ServiceResponse Add(RoleDTO c);
        ServiceResponse Update(RoleDTO c);

        void Delete(int id, int userid, int usertype);
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorContactsService
    {
        IEnumerable<ActorContactsDTO> GetByActorId(int actorid);
        ActorContactsDTO GetById(int id);

        ServiceResponse Add(ActorContactsDTO c);
        ServiceResponse Update(ActorContactsDTO c);

        void Delete(int id);
       
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IHomeService
    {
        Task<ListCommonListDTO> GetProjectsList(GlobalSearch paginationDTO );
        Task<TreeDTO> GetTree(int CreatedByUserId, int CreatedByUserType);
    }
}

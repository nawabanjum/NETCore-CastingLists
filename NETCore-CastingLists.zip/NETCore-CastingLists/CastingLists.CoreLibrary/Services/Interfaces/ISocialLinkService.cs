﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface ISocialLinkService
    {
        IEnumerable<SocialLinkDTO> GetByActorId(int actorid);
        SocialLinkDTO GetById(int id);

        ServiceResponse Add(SocialLinkDTO c);
        ServiceResponse Update(SocialLinkDTO c);

        void Delete(int id);
    }
}

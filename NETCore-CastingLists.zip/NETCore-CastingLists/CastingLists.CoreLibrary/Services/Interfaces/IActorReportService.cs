﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorReportService
    {
        Task<List<Dictionary<object, object>>> GetActorList(GlobalSearchActorImdb c);
    }
}

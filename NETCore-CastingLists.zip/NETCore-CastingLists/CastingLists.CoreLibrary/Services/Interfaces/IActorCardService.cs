﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IActorCardService
    {
        IEnumerable<ActorCardDTO> Get(int userid, int usertype);
        IEnumerable<ActorCardDTO> GetByListId(int listid, int userid, int usertype);
        IEnumerable<ActorCardSimplifiedDTO> GetByListSimplified(int listid, int userid, int usertype);
        ActorCardDTO GetById(int id, int userid, int usertype);
        ServiceResponse Add(ActorCardDTO c);
        ServiceResponse Update(CastingListActorUpdateDTO c);
        Task<ValidateActorResponse> ValidateActor(ValidateActorDTO c);
        void Delete(int id, int userid, int usertype);
        void UpdateSortOrder(List<ActorSortDTO> dto);
        void UpdateSatus(List<ActorStatusDTO> dto);

    }
    
}

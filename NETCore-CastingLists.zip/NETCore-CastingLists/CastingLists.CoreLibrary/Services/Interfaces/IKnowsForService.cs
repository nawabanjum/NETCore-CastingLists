﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface IKnowsForService
    {
        IEnumerable<KnowsForDTO> GetByActorId(int actorid);
        KnowsForDTO GetById(int id);
        ServiceResponse Add(KnowsForDTO c);
        ServiceResponse Update(KnowsForDTO c);
        void Delete(int id);
    }
}

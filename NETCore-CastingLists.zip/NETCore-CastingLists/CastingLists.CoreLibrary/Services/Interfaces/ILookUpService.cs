﻿using CastingLists.CoreLibrary.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services.Interfaces
{
    public interface ILookUpService
    {
        IEnumerable<CommonLookUpDTO> GetProjectType();
        IEnumerable<CommonLookUpDTO> GetProjectsSource();
        IEnumerable<CommonLookUpDTO> GetProjectsLookup(int userid, int usertype);
        IEnumerable<CommonLookUpDTO> GetListLookup(int userid, int usertype, int projectid);
        IEnumerable<CommonLookUpDTO> GetRolesLookup(int userid, int usertype,int projectid);
        IEnumerable<CommonLookUpDTO> GetGenderType();
        IEnumerable<CommonLookUpDTO> GetEthnicities();
        IEnumerable<FilmographyDTO> GetFilmography(string ImdbId);

        
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ProjectService : IProjectService
    {
        private readonly IProjectRepository _projectRepository;
        public ProjectService(IProjectRepository projectRepository)
        {
            _projectRepository = projectRepository;
        }
        public ServiceResponse Add(ProjectDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                tblProjectList model = new tblProjectList();
                model = DTOToEntity(c);
                _projectRepository.AddProject(model);
                aPIResponse.Id = model.ProjectId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id, int userid, int usertype)
        {
            _projectRepository.DeleteProject(id, userid, usertype);
        }
        public IEnumerable<ProjectDTO> Get(int userid, int usertype)
        {
            List<ProjectDTO> dtolist = new List<ProjectDTO>();
            var list = _projectRepository.Get(userid, usertype);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    ProjectDTO obj = new ProjectDTO();
                    obj = EntityToDTO(item);
                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }
        public ProjectDTO GetById(int id, int userid, int usertype)
        {
            ProjectDTO dto = new ProjectDTO();
            var c = _projectRepository.GetProjectById(id, userid, usertype);
            if (c != null)
            {
                dto = EntityToDTO(c);
            }
            return dto;
        }
        public ServiceResponse Update(ProjectDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblProjectList model = new tblProjectList();
            try
            {


                model = _projectRepository.GetProjectById(c.ProjectId, c.CreatedByUserId, c.CreatedByUserType);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.AgencyId = c.AgencyId;
                model.IsActive = c.IsActive;
                model.ModifiedOn = DateTime.Now;
                model.ProjectListSourceRId = c.ProjectListSourceRId;
                model.ProjectListTypeRId = c.ProjectListTypeRId;
                model.ProjectTitle = c.ProjectTitle;
                model.SortOrder = c.SortOrder;
                model.StudioName = c.StudioName;
                model.ProjectId = c.ProjectId;
                _projectRepository.UpdateProject(model);
                aPIResponse.Id = model.ProjectId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private ProjectDTO EntityToDTO(tblProjectList c)
        {
            ProjectDTO dto = new ProjectDTO();
            if (c != null)
            {
                dto.AgencyId = c.AgencyId;
                dto.IsActive = c.IsActive;
                dto.ModifiedOn = c.ModifiedOn;
                dto.CreatedOn = c.CreatedOn;
                dto.ProjectListSourceRId = c.ProjectListSourceRId;
                dto.ProjectListTypeRId = c.ProjectListTypeRId;
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.ProjectTitle = c.ProjectTitle;
                dto.SortOrder = c.SortOrder;
                dto.StudioName = c.StudioName;
                dto.ProjectId = c.ProjectId;
            }
            return dto;
        }
        private tblProjectList DTOToEntity(ProjectDTO c)
        {
            tblProjectList obj = new tblProjectList();
            obj.AgencyId = c.AgencyId;
            obj.CreatedByUserId = c.CreatedByUserId;
            obj.CreatedByUserType = c.CreatedByUserType;
            obj.CreatedOn = DateTime.Now;
            obj.IsActive = c.IsActive;
            obj.ModifiedOn = DateTime.Now;
            obj.ProjectListSourceRId = c.ProjectListSourceRId;
            obj.ProjectListTypeRId = c.ProjectListTypeRId;
            obj.ProjectTitle = c.ProjectTitle;
            obj.SortOrder = c.SortOrder;
            obj.StudioName = c.StudioName;
            return obj;
        }
    }
}

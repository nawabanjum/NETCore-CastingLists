﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientRepository _clientRepository;
        private IOptions<CWBActorPhotoSetting> _cwBActorPhotoSetting;

        public ClientService(IOptions<CWBActorPhotoSetting> cwBActorPhotoSetting, IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
            _cwBActorPhotoSetting = cwBActorPhotoSetting;
        }
        public async Task<IEnumerable<ClientDTO>> GetCLientList(GlobalSearchClient searchClient)
        {
            var list = await _clientRepository.GetClients(searchClient);
            List<ClientDTO> ClientListDTOs = new List<ClientDTO>();
            if (list != null && list.Count() > 0)
            {
                ClientListDTOs = (from item in list
                                  select new ClientDTO
                                  {
                                      ActorSubType = item.ActorSubType,
                                      AgentName = item.AgentName,
                                      AgentrId = item.AgentrId,
                                      ClientrId = item.ClientrId,
                                      Clone_Source_Id = item.Clone_Source_Id,
                                      Code = item.Code,
                                      DefPhotoum = item.DefPhotoum,
                                      FirstName = item.FirstName,
                                      Gender = item.Gender,
                                      IsFreemium = item.IsFreemium,
                                      RosterId = item.RosterId,
                                      LastName = item.LastName,
                                      MiddleName = item.MiddleName,
                                      Photonums = item.Photonums,
                                      RosterType = item.RosterType,
                                      Status = item.Status,
                                      SubType = item.SubType,
                                      PictureUrl = $"{_cwBActorPhotoSetting.Value.ActorImagesLocation}?ct={item.ClientrId}&fn={item.FirstName}&i={item.DefPhotoum}&thj=t&ro={item.RosterId}",
                                      AgentFirstName = item.AgentFirstName,
                                      AgentLastName = item.AgentLastName,
                                      AgeRange = item.AgeRange,
                                      CompanyName = item.CompanyName,
                                  }).ToList();
            }
            return ClientListDTOs;
        }


        public async Task<IEnumerable<ClientDTO>> GetCLientListByImdb(GlobalSearchImdb searchClient)
        {
            var list = await _clientRepository.GetClientByImdb(searchClient.Imdb, searchClient.CreatedByUserId);
            List<ClientDTO> ClientListDTOs = new List<ClientDTO>();
            if (list != null && list.Count() > 0)
            {
                ClientListDTOs = (from item in list
                                  select new ClientDTO
                                  {
                                      ActorSubType = item.ActorSubType,
                                      AgentName = item.AgentName,
                                      AgentrId = item.AgentrId,
                                      ClientrId = item.ClientrId,
                                      Clone_Source_Id = item.Clone_Source_Id,
                                      Code = item.Code,
                                      DefPhotoum = item.DefPhotoum,
                                      FirstName = item.FirstName,
                                      Gender = item.Gender,
                                      IsFreemium = item.IsFreemium,
                                      RosterId = item.RosterId,
                                      LastName = item.LastName,
                                      MiddleName = item.MiddleName,
                                      Photonums = item.Photonums,
                                      RosterType = item.RosterType,
                                      Status = item.Status,
                                      SubType = item.SubType,
                                      PictureUrl = $"{_cwBActorPhotoSetting.Value.ActorImagesLocation}?ct={item.ClientrId}&fn={item.FirstName}&i={item.DefPhotoum}&thj=t&ro={item.RosterId}",
                                      AgentFirstName = item.AgentFirstName,
                                      AgentLastName = item.AgentLastName,
                                      AgeRange = item.AgeRange,
                                      CompanyName = item.CompanyName,
                                      Height = item.Height,
                                      OriginalAgencyRId = item.OriginalAgencyRId,
                                      OriginalAgentRId = item.OriginalAgentRId
                                  }).ToList();
            }
            return ClientListDTOs;
        }
    }
}

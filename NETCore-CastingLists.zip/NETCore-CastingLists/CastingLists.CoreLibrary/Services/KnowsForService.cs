﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class KnowsForService : IKnowsForService
    {
        private readonly IActorRepository _actorRepository;

        private readonly IKnowsForRepository _knowsForRepository;
        public KnowsForService(IActorRepository actorRepository, IKnowsForRepository knowsForRepository)
        {
            _knowsForRepository = knowsForRepository;
            _actorRepository = actorRepository;
        }
        public ServiceResponse Add(KnowsForDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var actor = _actorRepository.GetById(c.ActorId);
                if (actor == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                tblKnowsFor obj = DTOToEntity(c);
                _knowsForRepository.AddKnowsFor(obj);
                aPIResponse.Id = obj.KnowsId;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        public void Delete(int id)
        {
            _knowsForRepository.DeleteKnowsFor(id);
        }
        public IEnumerable<KnowsForDTO> GetByActorId(int actorid)
        {
            List<KnowsForDTO> dtolist = new List<KnowsForDTO>();
            var list = _knowsForRepository.GetKnowsForByActorId(actorid);
            if (list.Count() > 0 && list != null)
            {
                foreach (var item in list)
                {
                    dtolist.Add(EntityToDTO(item));
                }
            }
            return dtolist;
        }
        public KnowsForDTO GetById(int id)
        {
            var c = _knowsForRepository.GetKnowsForById(id);
            return EntityToDTO(c);
        }
        public ServiceResponse Update(KnowsForDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblKnowsFor model = new tblKnowsFor();
            var actor = _actorRepository.GetById(c.ActorId);
            if (actor == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorIdNotExists;
                return aPIResponse;
            }
            model = _knowsForRepository.GetKnowsForById(c.KnowsId);

            if (model == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.KnowsForIdNotExists;
                aPIResponse.IsError = true;
                return aPIResponse;
            }
            model.ActorRId = c.ActorId;
            model.IsDeleted = c.IsDeleted;
            model.LastUpdatedDate = c.LastUpdatedDate;
            model.StartYear = c.StartYear;
            model.EndYear = c.EndYear;
            model.FullDescription = c.FullDescription;
            model.Link = c.Link;
            model.KnowsId = c.KnowsId;
            _knowsForRepository.UpdateKnowsFor(model);
            return aPIResponse;
        }
        private tblKnowsFor DTOToEntity(KnowsForDTO c)
        {
            tblKnowsFor obj = new tblKnowsFor();
            obj.ActorRId = c.ActorId;
            obj.CreatedOn = DateTime.Now;
            obj.IsDeleted = c.IsDeleted;
            obj.LastUpdatedDate = DateTime.Now;
            obj.KnowsId = c.KnowsId;
            obj.StartYear = c.StartYear;
            obj.EndYear = c.EndYear;
            obj.FullDescription = c.FullDescription;
            obj.Title = c.Title;
            obj.Link = c.Link;
            obj.ImdbId = ExtractImdbId(c.ImdbId);
            return obj;
        }
        private KnowsForDTO EntityToDTO(tblKnowsFor c)
        {
            KnowsForDTO dto = new KnowsForDTO();
            if (c != null)
            {
                dto.ActorId = c.ActorRId;
                dto.CreatedOn = c.CreatedOn;
                dto.IsDeleted = c.IsDeleted;
                dto.LastUpdatedDate = c.LastUpdatedDate;
                dto.StartYear = c.StartYear;
                dto.EndYear = c.EndYear;
                dto.FullDescription = c.FullDescription;
                dto.KnowsId = c.KnowsId;
                dto.Title = c.Title;
                dto.Link = c.Link;
                dto.ImdbId = c.ImdbId;
            }
            return dto;

        }

        private string ExtractImdbId(string ImdbId)
        {
           
            string id = "";
            if (ImdbId.Split('/')[ImdbId.Split('/').Length - 1].Split('=').Length > 1)
            {
                id = ImdbId.Split('/')[ImdbId.Split('/').Length - 1].Split('=')[1];
            }
            else
            {
                id = ImdbId.Split('/')[ImdbId.Split('/').Length - 1];
            }
            return id;
        }
    }
}

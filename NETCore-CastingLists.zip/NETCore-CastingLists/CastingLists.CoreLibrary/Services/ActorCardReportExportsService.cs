﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class ActorCardReportExportsService : IActorCardReportExportsService
    {
        private readonly IActorCardReportExportsRepository _actorCardReportExportsRepository;
        private readonly IListRepository _listRepository;

        public ActorCardReportExportsService(IListRepository listRepository, IActorCardReportExportsRepository actorCardReportExportsRepository)
        {
            _actorCardReportExportsRepository = actorCardReportExportsRepository;
            _listRepository = listRepository;
        }
        public ServiceResponse Add(ActorCardReportExportsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblActorCardExports model = new tblActorCardExports();
            try
            {
                var list = _listRepository.GetListyId(c.ListId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model = DTOToEntity(c);
                _actorCardReportExportsRepository.AddActorCardReportExport(model);
                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {

                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public void Delete(int id)
        {
            _actorCardReportExportsRepository.DeleteActorCardReportExport(id);
        }

        public IEnumerable<ActorCardReportExportsDTO> Get(int userid, int usertype)
        {
            List<ActorCardReportExportsDTO> dtolist = new List<ActorCardReportExportsDTO>();
            var list = _actorCardReportExportsRepository.Get(userid, usertype);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    var obj = new ActorCardReportExportsDTO();
                    obj = EntityToDTO(item);
                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }

        public ActorCardReportExportsDTO GetById(int id, int userid, int usertype)
        {
            ActorCardReportExportsDTO obj = new ActorCardReportExportsDTO();
            var model = _actorCardReportExportsRepository.GetActorCardReportExportById(id, userid, usertype);
            if (model != null)
            {
                obj = EntityToDTO(model);
            }
            return obj;
        }

        public IEnumerable<ActorCardReportExportsListDTO> GetByListId(int ListId, int UserId, int UserType)
        {

            List<ActorCardReportExportsListDTO> dtoList = new List<ActorCardReportExportsListDTO>();
            var list = _actorCardReportExportsRepository.GetActorCardReportExportByListId(ListId, UserId, UserType);

            if (list != null && list.Count() > 0)
            {
                dtoList = (from item in list
                           select new ActorCardReportExportsListDTO
                           {
                               Id = item.Id,
                               ListId = item.ListId,
                               CreatedByUserId = item.CreatedByUserId,
                               CreatedByUserType = item.CreatedByUserType,
                               CreatedOn = item.CreatedOn,
                               Title = item.Title
                           }).ToList();
            }
            return dtoList;
        }

        public ServiceResponse Update(ActorCardReportExportsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            try
            {
                var list = _listRepository.GetListyId(c.ListId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var model = _actorCardReportExportsRepository.GetById(c.Id);
                if (model == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ActorCardReportExportIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model.Id = c.Id;
                model.JsonData = JsonConvert.SerializeObject(c.JsonData);
                model.ListId = c.ListId;
                model.Title = c.Title;
                _actorCardReportExportsRepository.UpdateActorCardReportExport(model);
                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }
        private tblActorCardExports DTOToEntity(ActorCardReportExportsDTO c)
        {
            tblActorCardExports dto = new tblActorCardExports();
            dto.CreatedByUserId = c.CreatedByUserId;
            dto.CreatedByUserType = c.CreatedByUserType;
            dto.JsonData = c.JsonData;
            dto.ListId = c.ListId;
            dto.Title = c.Title;
            dto.CreatedOn = DateTime.Now;
            return dto;
        }
        private ActorCardReportExportsDTO EntityToDTO(tblActorCardExports c)
        {
            ActorCardReportExportsDTO obj = new ActorCardReportExportsDTO();
            if (c != null)
            {

                obj.Id = c.Id;
                obj.CreatedByUserId = c.CreatedByUserId;
                obj.CreatedByUserType = c.CreatedByUserType;
                obj.JsonData = c.JsonData;
                obj.CreatedOn = c.CreatedOn;
                obj.ListId = c.ListId;
                obj.Title = c.Title;

            }
            return obj;

        }


    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastingLists.CoreLibrary.Services
{
    public class SynchronizationCastListService : ISynchronizationCastListService
    {
        private readonly ISynchronizationCastListRepository  _synchronizationCastListRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IListRepository _listRepository;
        private readonly IProjectRepository _projectRepository;
        public SynchronizationCastListService(IProjectRepository projectRepository, IListRepository listRepository, IRoleRepository roleRepository, ISynchronizationCastListRepository  synchronizationCastListRepository)
        {
            _synchronizationCastListRepository = synchronizationCastListRepository;
            _roleRepository = roleRepository;
            _listRepository = listRepository;
            _projectRepository = projectRepository;

        }
        public ServiceResponse Add(SynchronizationCastListsDTO c)
        {
            ServiceResponse aPIResponse = new ServiceResponse();
            tblSynchronizationCastLists model = new tblSynchronizationCastLists();
            try
            {
                var role = _roleRepository.GetById(c.RoleRId);
                if (role == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.RoleIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var list = _listRepository.GetListyId(c.ListRId);
                if (list == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ListIdNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                var project = _projectRepository.GetById(c.ProjectRId);
                if (project == null)
                {
                    aPIResponse.ServiceResponseMessage = StaticMessages.StaticMessages.ProjectNotExists;
                    aPIResponse.IsError = true;
                    return aPIResponse;
                }
                model = DTOToEntity(c);
                _synchronizationCastListRepository.AddSynchronizationCast(model);

                aPIResponse.Id = model.Id;
            }
            catch (Exception ex)
            {
                aPIResponse.IsError = true;
                aPIResponse.ServiceResponseMessage = ex.Message;
            }
            return aPIResponse;
        }

        public IEnumerable<SynchronizationCastListsDTO> GetByListId(int listid, int userid, int usertype)
        {
            List<SynchronizationCastListsDTO> dtolist = new List<SynchronizationCastListsDTO>();
            var list = _synchronizationCastListRepository.GetSynchronizationCastByListId(listid,userid,usertype);
            if (list != null && list.Count() > 0)
            {
                foreach (var item in list)
                {
                    var obj = new SynchronizationCastListsDTO();
                    obj = EntityToDTO(item);
                    dtolist.Add(obj);
                }
            }
            return dtolist;
        }
        private SynchronizationCastListsDTO EntityToDTO(tblSynchronizationCastLists c)
        {
            SynchronizationCastListsDTO dto = new SynchronizationCastListsDTO();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = c.CreatedOn;
                dto.Id = c.Id;
                dto.ListRId = c.ListRId;
                dto.RoleRId = c.RoleRId;
                dto.ProjectRId = c.ProjectRId;
                dto.Details = c.Details;
                dto.EventType = c.EventType;
                dto.IsError = c.IsError;
                dto.IsSuccess = c.IsSuccess;
                dto.NumberOfRecords = c.NumberOfRecords;
                dto.QtyProcessed = c.QtyProcessed;
            }
            return dto;

        }
        private tblSynchronizationCastLists DTOToEntity(SynchronizationCastListsDTO c)
        {
            tblSynchronizationCastLists dto = new tblSynchronizationCastLists();
            if (c != null)
            {
                dto.CreatedByUserId = c.CreatedByUserId;
                dto.CreatedByUserType = c.CreatedByUserType;
                dto.CreatedOn = DateTime.Now;
                dto.ListRId = c.ListRId;
                dto.RoleRId = c.RoleRId;
                dto.ProjectRId = c.ProjectRId;
                dto.Details = c.Details;
                dto.EventType = c.EventType;
                dto.IsError = c.IsError;
                dto.IsSuccess = c.IsSuccess;
                dto.NumberOfRecords = c.NumberOfRecords;
                dto.QtyProcessed = c.QtyProcessed;
            }
            return dto;

        }
    }
}

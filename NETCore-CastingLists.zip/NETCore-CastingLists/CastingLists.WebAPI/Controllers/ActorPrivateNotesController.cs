﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorPrivateNotesController : ControllerBase
    {
        private readonly IActorPrivateNotesService _actorPrivateNotesService;
        private readonly ILogger<ActorPrivateNotesController> _logger;
        public ActorPrivateNotesController(IActorPrivateNotesService actorPrivateNotesService, ILogger<ActorPrivateNotesController> logger)
        {
            _actorPrivateNotesService = actorPrivateNotesService;
            _logger = logger;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<List<ActorPrivateNotesDTO>>> Get(ParamActorDTO dto)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                var list = _actorPrivateNotesService.Get(createdByUserId, createdByUserType, dto.ActorId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Private Notes List for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorPrivateNotesDTO>> Get(int id)
        {
            ActorPrivateNotesDTO model = new ActorPrivateNotesDTO();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                model = _actorPrivateNotesService.GetById(id, createdByUserId, createdByUserType);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Private Notes By Id for Get {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<ActorPrivateNotesDTO>> Add([FromBody] ActorPrivateNotesDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _actorPrivateNotesService.Add(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Save Actor Private Notes for Add {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Update")]
        public async Task<ActionResult<ActorPrivateNotesDTO>> Update([FromBody] ActorPrivateNotesDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _actorPrivateNotesService.Update(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update Actor Private Notes for Update {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                _actorPrivateNotesService.Delete(id, createdByUserId, createdByUserType);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete Actor Private notes for Delete {e.Message}", e);
                throw;
            }
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class FilmographyController : ControllerBase
    {
        private readonly IFilmographyService  _filmographyService;
        private readonly ILogger<FilmographyController> _logger;
        public FilmographyController(IFilmographyService  filmographyService, ILogger<FilmographyController> logger)
        {
            _filmographyService = filmographyService;
            _logger = logger;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<List<FilmographyDTO>>> Get(ParamActorDTO dto)
        {
            try
            {
                var list = _filmographyService.GetByActorId(dto.ActorId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Filmography For List for Get {e.Message}", e);
                throw;
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<FilmographyDTO>> Get(int id)
        {
            FilmographyDTO model = new FilmographyDTO();
            try
            {
                model = _filmographyService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Filmography  By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<FilmographyDTO>> Add([FromBody] FilmographyDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _filmographyService.Add(dto);
                if (!result.IsError)
                {
                    dto.FilmographyId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Save Filmography  for Add {e.Message}", e);
                throw;
            }
        }

        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult<FilmographyDTO>> Update([FromBody] FilmographyDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _filmographyService.Update(dto);
                if (!result.IsError)
                {
                    dto.FilmographyId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"UpdateFilmography for Update {e.Message}", e);

                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _filmographyService.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"DeleteFilmography for {e.Message}", e);
                throw;
            }
        }
    }
}

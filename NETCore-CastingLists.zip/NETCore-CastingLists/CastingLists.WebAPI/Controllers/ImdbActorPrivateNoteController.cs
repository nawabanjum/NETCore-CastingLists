﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ImdbActorPrivateNoteController : ControllerBase
    {
        private readonly IActorCardPrivateNoteService _actorCardPrivateNoteService;

        private readonly ILogger<ImdbActorPrivateNoteController> _logger;
        public ImdbActorPrivateNoteController(IActorCardPrivateNoteService actorCardPrivateNoteService, ILogger<ImdbActorPrivateNoteController> logger)
        {
            _logger = logger;
            _actorCardPrivateNoteService = actorCardPrivateNoteService;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<ActorCardPrivateNoteDTO>> Get(ParamCastingActorDTO dto)
        {
            try
            {
                var list = _actorCardPrivateNoteService.Get(dto.ActorCardId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get CastingListActor PrivateNote for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardPrivateNoteDTO>> Get(int id)
        {
            try
            {
                ActorCardPrivateNoteDTO model = new ActorCardPrivateNoteDTO();
                model = _actorCardPrivateNoteService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard PrivateNote By Id for Get  {e.Message}", e);

                throw;
            }
        }

        [HttpPost]
        public async Task<ActionResult<ActorCardPrivateNoteDTO>> Post([FromBody] ActorCardPrivateNoteDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _actorCardPrivateNoteService.Add(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_PrivateNoteId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"SaveActorCard PrivateNote for Post {e.Message}", e);
                throw;
            }
        }

        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult> Update([FromBody] ActorCardPrivateNoteDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _actorCardPrivateNoteService.Update(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_PrivateNoteId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard PrivateNote for Update {e.Message}", e);

                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _actorCardPrivateNoteService.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorCard PrivateNote for Delete {e.Message}", e);
                throw;
            }
        }


        [HttpPost]
        [Route("ChangeSortOrder")]
        public async Task<ActionResult> ChangeSortOrder([FromBody] List<ActorSortDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                _actorCardPrivateNoteService.UpdateSortOrder(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard PrivateNote for ChangeSortOrder  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeHiddenStatus")]
        public async Task<ActionResult> ChangeHiddenStatus([FromBody] List<ActorStatusDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                _actorCardPrivateNoteService.UpdateSatus(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard PrivateNote for ChangeHiddenStatus  {e.Message}", e);
                throw;
            }
        }
    }
}


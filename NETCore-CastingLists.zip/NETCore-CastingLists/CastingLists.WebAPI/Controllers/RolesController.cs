﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class RolesController : ControllerBase
    {
        private readonly IRoleService  _roleService;
        private readonly ILogger<RolesController> _logger;
        public RolesController(IRoleService  roleService, ILogger<RolesController> logger)
        {
            _roleService = roleService;
            _logger = logger;
        }

        [HttpPost]
        [Route("GetRolesByProject")]
        public async Task<ActionResult<List<RoleDTO>>> GetRolesByProject(ParamListDTO dto)
        {
            List<RoleDTO> list = new List<RoleDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<RoleDTO>)_roleService.Get(createdByUserId, createdByUserType, dto.ProjectId);
                return Ok(list);

            }
            catch (Exception e)
            {

                _logger.LogError(e, $"Get Role List for  {e.Message}", e);
                throw;
            }
        }

        
        [HttpGet("{id}")]
        public async Task<ActionResult<RoleDTO>> Get(int id)
        {
            RoleDTO model = new RoleDTO();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                model = _roleService.GetById(id,createdByUserId,createdByUserType);
                return Ok(model);
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"GetRoleById for  {e.Message}", e);
                throw;
            }
        }

 
        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<RoleDTO>> Add([FromBody] RoleDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();

                var result = _roleService.Add(dto);
                if (!result.IsError)
                {
                    dto.RoleId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"SaveRoles for {e.Message}", e);
                throw;
            }
        }

        
        [HttpPost]
        [Route("Update")]
        public async Task<ActionResult<RoleDTO>> Update([FromBody] RoleDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
              var result=  _roleService.Update(dto);
                if (!result.IsError)
                {
                    dto.RoleId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"UpdateRoles for {e.Message}", e);
                throw;
            }
        }

       
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                _roleService.Delete(id,createdByUserId,createdByUserType);
                return Ok();
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"DeleteRole for {e.Message}", e);
                throw;
            }
        }
    }
}

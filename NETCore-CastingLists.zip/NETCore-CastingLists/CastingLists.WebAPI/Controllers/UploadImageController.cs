﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Services.Interfaces;
using CastingLists.CoreLibrary.StaticMessages;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadImageController : ControllerBase
    {
        private readonly IActorCardRepository _actorCardRepository;
        private readonly IActorCardImageService _actorCardImageService;
        private readonly ILogger<UploadImageController> _logger;
        IHostingEnvironment _env;
        private readonly IHttpClientFactory _clientFactory;
        private UploadSettings _appSettings { get; set; }
        private IOptions<ValidateImageSizes> _validImageSize;
        private IOptions<ValidImageExtensions> _validImageExtensions;
        public UploadImageController(IActorCardRepository actorCardRepository, IHostingEnvironment env, IHttpClientFactory clientFactory, IOptions<UploadSettings> uploadSettings, IOptions<ValidateImageSizes> validImageSize, IActorCardImageService actorCardImageService, ILogger<UploadImageController> logger, IOptions<ValidImageExtensions> validImageExtensions)
        {
            _actorCardImageService = actorCardImageService;
            _logger = logger;
            _appSettings = uploadSettings.Value;
            _env = env;
            _clientFactory = clientFactory;
            _validImageSize = validImageSize;
            _validImageExtensions = validImageExtensions;
            _actorCardRepository = actorCardRepository;
        }
        [HttpPost]
        public async Task<ActionResult> UploadDocument(
        [FromHeader][FromForm] int ActorCardId, IFormFile file,bool IsDefault=true )
        {
            CommonOperations commonOperations = new CommonOperations();
            ServiceResponse aPIResponse = new ServiceResponse();

            var actor = _actorCardRepository.GetById(ActorCardId);
            if (actor == null)
            {
                aPIResponse.ServiceResponseMessage = StaticMessages.ActorIdNotExists;
                aPIResponse.IsError = true;
                return Ok(aPIResponse);
            }
            var images = _validImageSize.Value.ImageSizes.ToString();
            var validImageExtensionsArray = _validImageExtensions.Value.Extensions.Split(",");
            var response = commonOperations.UploadPictureActorCard(file, _appSettings, _clientFactory.CreateClient(), images, validImageExtensionsArray).Result;
            if (response.IsError == true)
            {
                return Ok(response);
            }
            ActorCardImagesDTO dto = new ActorCardImagesDTO();
            dto.PicturePath = response.ServiceResponseMessage;
            dto.ActorCardRId = ActorCardId;
            var result = _actorCardImageService.Add(dto);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {

                _actorCardImageService.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorCard Image for Delete {e.Message}", e);
                throw;
            }
        }


    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class LookupController : ControllerBase
    {
        private readonly ILookUpService _lookUpService;
        private readonly ILogger<LookupController> _logger;
        public LookupController(ILookUpService lookUpService, ILogger<LookupController> logger)
        {
            _lookUpService = lookUpService;
            _logger = logger;
        }
        // GET: api/<LookupController>
        [HttpGet]
        [Route("GetTypelist")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> GetTypelist()
        {
            List<CommonLookUpDTO> list = new List<CommonLookUpDTO>();
            try
            {
                list = (List<CommonLookUpDTO>)_lookUpService.GetProjectType();
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Project Type list for GetTypelist {e.Message}", e);
                throw;
            }
        }
        [HttpGet]
        [Route("GetSourcelist")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> GetSourcelist()
        {
            try
            {
                var rslt = (List<CommonLookUpDTO>)_lookUpService.GetProjectsSource();
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Source list for GetSourcelist  {e.Message}", e);
                throw;
            }
        }
        [HttpGet]
        [Route("Project")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> ProjectLookup()
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                var rslt = _lookUpService.GetProjectsLookup(createdByUserId, createdByUserType);
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Project for ProjectLookup {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("List")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> ListLookup(ParamListDTO dto)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                var rslt = _lookUpService.GetListLookup(createdByUserId, createdByUserType, dto.ProjectId);
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get list By Project  for ListLookup {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("Role")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> RoleLookup(ParamListDTO dto)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                var rslt = _lookUpService.GetRolesLookup(createdByUserId, createdByUserType, dto.ProjectId);
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get  Roles by Project for RoleLookup {e.Message}", e);
                throw;
            }
        }
        [HttpGet]
        [Route("GenderLookup")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> GenderLookup()
        {
            try
            {
                var rslt = (List<CommonLookUpDTO>)_lookUpService.GetGenderType();
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get  list for GenderLookup  {e.Message}", e);
                throw;
            }
        }
        [HttpGet]
        [Route("EthnicitiesLookup")]
        public async Task<ActionResult<List<CommonLookUpDTO>>> EthnicitiesLookup()
        {
            try
            {
                var rslt = (List<CommonLookUpDTO>)_lookUpService.GetEthnicities();
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get  list for EthnicitiesLookup  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("FilmographyLookup")]
        public async Task<ActionResult<List<FilmographyDTO>>> FilmographyLookup(GlobalSearchImdb imdb)
        {
            try
            {
                var rslt = (List<FilmographyDTO>)_lookUpService.GetFilmography(imdb.Imdb);
                return Ok(rslt);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get  list for FilmographyLookup  {e.Message}", e);
                throw;
            }
        }
    }
}

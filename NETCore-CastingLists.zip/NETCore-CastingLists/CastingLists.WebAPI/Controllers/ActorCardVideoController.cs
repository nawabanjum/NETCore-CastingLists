﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorCardVideoController : ControllerBase
    {
        private readonly IActorCardVideoSrvice  _actorCardVideoSrvice;

        private readonly ILogger<ActorCardVideoController> _logger;
        public ActorCardVideoController(IActorCardVideoSrvice actorCardService, ILogger<ActorCardVideoController> logger)
        {
            _logger = logger;
            _actorCardVideoSrvice = actorCardService;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<ActorCardVideoDTO>> Get(ParamCastingActorDTO dto)
        {
            try
            {
                var list = _actorCardVideoSrvice.Get(dto.ActorCardId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get CastingListActor Video for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardDTO>> Get(int id)
        {
            ActorCardVideoDTO model = new ActorCardVideoDTO();
            try
            {
                model = _actorCardVideoSrvice.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard Video By Id for Get  {e.Message}", e);
                throw;
            }
        }


        [HttpPost]
        public async Task<ActionResult<ActorCardVideoDTO>> Post([FromBody] ActorCardVideoDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardVideoSrvice.Add(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_VideoId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Video for Post {e.Message}", e);
                throw;
            }
        }


        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult> Update([FromBody] ActorCardVideoDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardVideoSrvice.Update(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_VideoId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update ActorCard Video for Update {e.Message}", e);
                throw;
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _actorCardVideoSrvice.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorCard Video for Delete {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeSortOrder")]
        public async Task<ActionResult> ChangeSortOrder([FromBody] List<ActorSortDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                _actorCardVideoSrvice.UpdateSortOrder(dto);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Video for ChangeSortOrder  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeHiddenStatus")]
        public async Task<ActionResult> ChangeHiddenStatus([FromBody] List<ActorStatusDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                _actorCardVideoSrvice.UpdateSatus(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Video for ChangeHiddenStatus  {e.Message}", e);
                throw;
            }
        }
    }
}

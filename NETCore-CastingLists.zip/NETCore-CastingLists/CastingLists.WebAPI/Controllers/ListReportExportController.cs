﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ListReportExportController : ControllerBase
    {
        private readonly IActorCardReportExportsService _actorCardReportExportsService;

        private readonly ILogger<ListReportExportController> _logger;
        public ListReportExportController(IActorCardReportExportsService actorCardReportExportsService, ILogger<ListReportExportController> logger)
        {
            _logger = logger;
            _actorCardReportExportsService = actorCardReportExportsService;
        }
        [HttpGet]
        [Route("ByList")]
        public async Task<ActionResult<List<ActorCardReportExportsListDTO>>> GetActorReportByList(int listId)
        {
            List<ActorCardReportExportsListDTO> list = new List<ActorCardReportExportsListDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<ActorCardReportExportsListDTO>)_actorCardReportExportsService.GetByListId(listId, createdByUserId, createdByUserType);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard Report Export By List Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [RequestSizeLimit(209715200)]
        public async Task<ActionResult<ActorCardReportExportsDTO>> Post([FromBody] ActorCardReportExportsDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _actorCardReportExportsService.Add(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Report Exports for Post {e.Message}", e);
                throw;
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardReportExportsDTO>> Get(int id)
        {
            ActorCardReportExportsDTO model = new ActorCardReportExportsDTO();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                model = _actorCardReportExportsService.GetById(id, createdByUserId, createdByUserType);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard Report Export By Id for Get  {e.Message}", e);
                throw;
            }
        }
    }
}

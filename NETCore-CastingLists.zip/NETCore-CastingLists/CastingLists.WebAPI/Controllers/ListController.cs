﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ListController : ControllerBase
    {
        private readonly IListService _listService;
        private readonly ILogger<ListController> _logger;
        public ListController(IListService listService, ILogger<ListController> logger)
        {
            _listService = listService;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetListsByProject")]
        public async Task<ActionResult<List<ListDTO>>> GetListsByProject(int ProjectId)
        {
            List<ListDTO> list = new List<ListDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<ListDTO>)_listService.Get(createdByUserId, createdByUserType, ProjectId);
                return Ok(list);

            }
            catch (Exception e)
            {

                _logger.LogError(e, $"GetList for  {e.Message}", e);
                throw;
            }
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<ListDTO>> Get(int id)
        {
            ListDTO model = new ListDTO();
            try
            {
                model = _listService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"GetListById for  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<ListDTO>> Add([FromBody] ListDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();

                var result = _listService.Add(dto);
                if (!result.IsError)
                {
                    dto.ListId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"SaveList for {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Update")]
        public async Task<ActionResult<ListDTO>> Update([FromBody] ListDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _listService.Update(dto);
                if (!result.IsError)
                {
                    dto.ListId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"UpdateList for {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _listService.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"DeleteList for {e.Message}", e);
                throw;
            }
        }
    }
}

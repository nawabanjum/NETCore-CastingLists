﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MatchingActorController : ControllerBase
    {
        private readonly IActorCardService _actorCardService;

        private readonly ILogger<MatchingActorController> _logger;
        public MatchingActorController(IActorCardService actorCardService, ILogger<MatchingActorController> logger)
        {
            _logger = logger;
            _actorCardService = actorCardService;
        }
       

        [HttpPost]
        [Route("Validate")]
        public async Task<ActionResult<ValidateActorResponse>> Validate([FromBody] ValidateActorDTO dto)
        {
            try
            {
                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                var result = await _actorCardService.ValidateActor(dto);
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"MatchingActor for Post {e.Message}", e);
                throw;
            }
        }

        
    }
}

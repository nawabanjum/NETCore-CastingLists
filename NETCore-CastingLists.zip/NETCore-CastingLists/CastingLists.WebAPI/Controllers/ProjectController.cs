﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectService _projectService;
        private readonly ILogger<ProjectController> _logger;
        public ProjectController(IProjectService projectService, ILogger<ProjectController> logger)
        {
            _projectService = projectService;
            _logger = logger;
        }
       
        [HttpGet]
        [Route("All")]
        public async Task<ActionResult<List<ProjectDTO>>> GetAll()
        {
            List<ProjectDTO> list = new List<ProjectDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<ProjectDTO>)_projectService.Get(createdByUserId, createdByUserType);
                return Ok(list);

            }
            catch (Exception e)
            {

                _logger.LogError(e, $"GetProjectList for  {e.Message}", e);
                throw;
            }
        }

       
        [HttpGet("{id}")]
        public async Task<ActionResult<ProjectDTO>> Get(int id)
        {
            ProjectDTO model = new ProjectDTO();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                model = _projectService.GetById(id, createdByUserId, createdByUserType);
                return Ok(model);
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"GetProjectListById for  {e.Message}", e);
                throw;
            }
        }


        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<ProjectDTO>> Add([FromBody] ProjectDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                dto.AgencyId = Convert.ToInt32(claimsIdentity.FindFirst("AgencyId")?.Value);

                var result = _projectService.Add(dto);
                if (!result.IsError)
                {
                    dto.ProjectId = (int)result.Id;
                    return Ok(dto); 
                }
                return (new ObjectResult(result) {StatusCode=500 });
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"SaveProjectList for {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Update")]
        public async Task<ActionResult<ProjectDTO>> Update([FromBody] ProjectDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();

                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                dto.AgencyId = Convert.ToInt32(claimsIdentity.FindFirst("AgencyId")?.Value);

                var result= _projectService.Update(dto);
                if (!result.IsError)
                {
                    dto.ProjectId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"UpdateProjectList for {e.Message}", e);
                throw;
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                _projectService.Delete(id, createdByUserId, createdByUserType);
                return Ok();
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"DeleteProject for {e.Message}", e);
                throw;
            }
        }
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorCardEthnicityController : ControllerBase
    {
        private readonly IActorCardEthnicityService  _actorCardEthnicityService;
        private readonly ILogger<ActorCardEthnicityController> _logger;
        public ActorCardEthnicityController(IActorCardEthnicityService  actorCardEthnicityService, ILogger<ActorCardEthnicityController> logger)
        {
            _logger = logger;
            _actorCardEthnicityService = actorCardEthnicityService;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<ActorCardEthnicityDTO>> Get(ParamCastingActorDTO dto)
        {
            try
            {
                var list = _actorCardEthnicityService.Get(dto.ActorCardId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard Ethnicity for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardEthnicityDTO>> Get(int id)
        {
            ActorCardEthnicityDTO model = new ActorCardEthnicityDTO();
            try
            {
                model = _actorCardEthnicityService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard Ethnicity By Id for Get  {e.Message}", e);
                throw;
            }
        }


        [HttpPost]
        public async Task<ActionResult<ActorCardEthnicityDTO>> Post([FromBody] ActorCardEthnicityDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardEthnicityService.Add(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_EthnicityId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Ethnicity for Post {e.Message}", e);
                throw;
            }
        }


        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult<ActorCardEthnicityDTO>> Update([FromBody] ActorCardEthnicityDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardEthnicityService.Update(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_EthnicityId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update ActorCard Ethnicity for Update {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _actorCardEthnicityService.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorCard Ethnicity for Delete {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeSortOrder")]
        public async Task<ActionResult> ChangeSortOrder([FromBody] List<ActorSortDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                _actorCardEthnicityService.UpdateSortOrder(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Ethnicity for ChangeSortOrder  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeHiddenStatus")]
        public async Task<ActionResult> ChangeHiddenStatus([FromBody] List<ActorStatusDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                _actorCardEthnicityService.UpdateSatus(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Ethnicity for ChangeHiddenStatus  {e.Message}", e);
                throw;
            }
        }
    }
}



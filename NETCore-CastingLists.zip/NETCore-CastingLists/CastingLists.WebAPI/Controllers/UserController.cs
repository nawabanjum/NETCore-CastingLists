﻿using CastingLists.CoreLibrary.Models.DTO;
using Core5SharedLibrary.Helpers;
using Core5SharedLibrary.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;



namespace CastingLists.WebAPI.Controllers
{
   [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private JwtConfigurableOptions _appSettings { get; set; }
        public UserController(IOptions<JwtConfigurableOptions> appSettings)
        {
            _appSettings = appSettings.Value;
        }
        [HttpPost]
        [Route("me")]
        public async Task<IActionResult> Me()
        {
            try
            {
               
                MeDTO meDTO = new MeDTO();
                meDTO.UserId = this.User.GetAuthenticatedUserId().ToString();
                meDTO.UserType = this.User.GetAuthenticatedUserTypeId().ToString();
                var claimsIdentity = this.User.Identity as ClaimsIdentity;               
                meDTO.Login = claimsIdentity.FindFirst("Login")?.Value;
                meDTO.AgencyId = claimsIdentity.FindFirst("AgencyId")?.Value;
                meDTO.WebSessionKey = claimsIdentity.FindFirst("WebSessionKey")?.Value;
                meDTO.WebSessionKey = claimsIdentity.FindFirst("WebSessionKey")?.Value;
                meDTO.FirstName = claimsIdentity.FindFirst("FirstName")?.Value;
                meDTO.LastName = claimsIdentity.FindFirst("LastName")?.Value;
                meDTO.SellerId = claimsIdentity.FindFirst("SellerId")?.Value;

                
                return Ok(meDTO);
            }
            catch (Exception e)
            {

                //_logger.LogError(e, $"GetAvailableJob for {nameof(agencyId)}:{projectDirector} - {e.Message}", e);
                throw;
            }
        }

      

      
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class SynchronizationCastListController : ControllerBase
    {
        private readonly ISynchronizationCastListService _synchronizationCastListService;
        private readonly ILogger<SynchronizationCastListController> _logger;
        public SynchronizationCastListController(ILogger<SynchronizationCastListController> logger, ISynchronizationCastListService synchronizationCastListService)
        {
            _synchronizationCastListService = synchronizationCastListService;
            _logger = logger;
        }
        [HttpGet]
        [Route("ByList")]
        public async Task<ActionResult<List<SynchronizationCastListsDTO>>> GetByList(int listId)
        {
            List<SynchronizationCastListsDTO> list = new List<SynchronizationCastListsDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<SynchronizationCastListsDTO>)_synchronizationCastListService.GetByListId(listId, createdByUserId, createdByUserType);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Synchronization Cast List By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]

        public async Task<ActionResult<SynchronizationCastListsDTO>> Post([FromBody] SynchronizationCastListsDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();

                var result = _synchronizationCastListService.Add(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $" Synchronization Cast List for Post {e.Message}", e);
                throw;
            }
        }
    }
}

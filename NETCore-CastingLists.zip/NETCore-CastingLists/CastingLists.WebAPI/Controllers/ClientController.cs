﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly IClientService _clientService;
        private readonly ILogger<ClientController> _logger;
        public ClientController(IClientService clientService, ILogger<ClientController> logger)
        {
            _clientService = clientService;
            _logger = logger;
        }
        [HttpPost]
        [Route("MasterCastSearch")]
        public async Task<ActionResult<List<ClientDTO>>> MasterCastSearch(GlobalSearchClient parm)
        {
            try
            {
                parm.CreatedByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                //if (createdByUserType == 2)
                //{
                    var list = await _clientService.GetCLientList(parm);
                    return Ok(list);
                //}
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Client List for ClientSearch {e.Message}", e);
                throw;
            }
        }
    }
}

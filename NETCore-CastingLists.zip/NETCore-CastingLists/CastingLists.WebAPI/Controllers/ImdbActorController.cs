﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;



namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ImdbActorController : ControllerBase
    {
        private readonly IActorService _actorService;
        private readonly ILogger<ImdbActorController> _logger;
        IHostingEnvironment _env;
        private readonly IHttpClientFactory _clientFactory;
        private UploadSettings _appSettings { get; set; }
        private IOptions<ValidImageExtensions> _validImageExtensions;
        public ImdbActorController(IHostingEnvironment env, IHttpClientFactory clientFactory, IOptions<UploadSettings> uploadSettings, IOptions<ValidImageExtensions> validImageExtensions, IActorService actorService, ILogger<ImdbActorController> logger)
        {
            _actorService = actorService;
            _logger = logger;
            _appSettings = uploadSettings.Value;
            _env = env;
            _clientFactory = clientFactory;
            _validImageExtensions = validImageExtensions;
        }
        [HttpPost]
        [Route("SearchByActorName")]
        public async Task<ActionResult<List<ActorDTO>>> Get(GlobalSearchActor parm)
        {
            try
            {
                var list = _actorService.GetByActor(parm.ActorName);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor List for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorDTO>> Get(int id)
        {
            ActorDTO model = new ActorDTO();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                model = _actorService.GetById(id, createdByUserId, createdByUserType);
                return Ok(model);
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"Get Actor By Id for Get {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Import")]
        public async Task<ActionResult<ActorImportDTO>> Import([FromBody] ActorImportDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();

                var result = _actorService.Add(dto);
                if (!result.IsError)
                {
                    dto.ActorId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActor for Post {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Update")]
        public async Task<ActionResult> Update([FromBody] ActorDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _actorService.Update(dto);
                if (!result.IsError)
                {
                    dto.ActorId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update Actor for Update {e.Message}", e);
                throw;
            }
        }
        [HttpPut]
        [Route("UpdateRanking")]
        public async Task<ActionResult> UpdateRanking([FromBody] ActorRankDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorService.UpdateRanking(dto);
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update Actor Ranking for Put {e.Message}", e);
                throw;
            }
        }

        [HttpPut]
        [Route("ImageUpdate")]
        public async Task<ActionResult> ImageUpdate([FromBody] ActorImageDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                CommonOperations commonOperations = new CommonOperations();
                var validImageExtensionsArray = _validImageExtensions.Value.Extensions.Split(",");
                dto.ImageSourceUrl = dto.ImageLink;
                  // save picture in the actor imdb configuration folder
                var response = commonOperations.UploadImageImdb(dto.ImageLink, _appSettings, _clientFactory.CreateClient(), validImageExtensionsArray).Result;
                if (response.IsError == true)
                {
                    return Ok(response);
                }
                dto.ImageLink = response.ServiceResponseMessage;
               
                var result = _actorService.UpdateImage(dto);
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update Actor Image for ImageUpdate {e.Message}", e);
                throw;
            }
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                _actorService.Delete(id, createdByUserId, createdByUserType);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete Actor for Delete {e.Message}", e);
                throw;
            }
        }

    }
}

﻿using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        private readonly IJobService _JobService;
        private readonly ILogger<JobController> _logger;
        public JobController(IJobService JobService, ILogger<JobController> logger)
        {
            _JobService = JobService;
            _logger = logger;
        }
        [HttpPost]
        [Route("GetAvailableJob")]
        public async Task<IActionResult> GetAvailableJob([FromHeader] string accessToken, [FromQuery] int agencyId, bool projectDirector)
        {
            try
            {
                var result = await _JobService.GetAvailableJob(agencyId, projectDirector);
                return Ok(result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"GetAvailableJob for {nameof(agencyId)}:{projectDirector} - {e.Message}", e);
                throw;
            }
        }
    }
}

﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorImdbImagesController : ControllerBase
    {
        private readonly IActorImdbImagesService _actorImdbImagesService;
        private readonly ILogger<ImdbActorController> _logger;
        IHostingEnvironment _env;
        private readonly IHttpClientFactory _clientFactory;
        private IOptions<ValidImageExtensions> _validImageExtensions;
        private UploadSettings _appSettings { get; set; }
        public ActorImdbImagesController(IActorImdbImagesService actorImdbImagesService, ILogger<ImdbActorController>  logger, IHttpClientFactory httpClientFactory,
            IHostingEnvironment env, IOptions<ValidImageExtensions> validImageExtensions, IOptions<UploadSettings> uploadSettings)
        {
            _actorImdbImagesService = actorImdbImagesService;
            _logger = logger;
            _env = env;
            _appSettings = uploadSettings.Value;
            _clientFactory = httpClientFactory;
            _validImageExtensions = validImageExtensions;
        }
        [HttpPost]
        [Route("List")]
        public async Task<ActionResult<List<ActorImdbImagesListDTO>>> ActorImdbImagesList(ParamImdbActorDTO dto)
        {
            List<ActorImdbImagesListDTO> list = new List<ActorImdbImagesListDTO>();
            try
            {
                list = (List<ActorImdbImagesListDTO>)_actorImdbImagesService.Get(dto.ImdbActorId);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ImdbActor Images By Actor Id for Get  {e.Message}", e);
                throw;
            }
            return list;
        }

        [HttpPost]
        public async Task<ActionResult<ActorImdbImagesDTO>> Post([FromBody] ActorImdbImagesDTO dto)
        {
            try
            {
                CommonOperations commonOperations = new CommonOperations();
                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
               dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var validImageExtensionsArray = _validImageExtensions.Value.Extensions.Split(",");
                // save picture in the actor imdb configuration folder
                var response = commonOperations.UploadImageImdb(dto.ImageSourceUrl, _appSettings, _clientFactory.CreateClient(), validImageExtensionsArray).Result;
                if (response.IsError == true)
                {
                    return Ok(response);
                }
                dto.ImageSourceUrl = response.ServiceResponseMessage;
                var result = _actorImdbImagesService.Add(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ImdbActor Images for Post  {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _actorImdbImagesService.Delete(id);

                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorImdb Image for Delete {e.Message}", e);
                throw;
            }
        }
    }
}

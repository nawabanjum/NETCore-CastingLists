﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ImdbActorContactController : ControllerBase
    {
        private readonly IActorContactsService _actorContactsService;
        private readonly ILogger<ImdbActorContactController> _logger;
        public ImdbActorContactController(IActorContactsService actorContactsService, ILogger<ImdbActorContactController> logger)
        {
            _actorContactsService = actorContactsService;
            _logger = logger;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<List<ActorContactsDTO>>> Get(ParamActorDTO dto)
        {
            try
            {
                var list = _actorContactsService.GetByActorId(dto.ActorId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Contact List for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorContactsDTO>> Get(int id)
        {
            ActorContactsDTO model = new ActorContactsDTO();
            try
            {
                model = _actorContactsService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Contact By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<ActorContactsDTO>> Add([FromBody] ActorContactsDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _actorContactsService.Add(dto);
                if (!result.IsError)
                {
                    dto.ContactId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActor Contact for Post {e.Message}", e);
                throw;
            }
        }

        //[HttpPost]
        //[Route("Update")]
        //public async Task<ActionResult> Update([FromBody] ActorContactsDTO dto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
        //        }
        //        var response=_actorContactsService.Update(dto);
        //        return Ok(response);
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e, $"Update Actor Contact for Update {e.Message}", e);
        //        throw;
        //    }
        //}

        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    try
        //    {
        //        _actorContactsService.Delete(id);
        //        return Ok();
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e, $"Delete Actor Contact for Delete {e.Message}", e);
        //        throw;
        //    }
        //}
    }
}

﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Models.Entities;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class SocialLinkController : ControllerBase
    {
        private readonly ISocialLinkService  _socialLinkService;
        private readonly ILogger<SocialLinkController> _logger;
        public SocialLinkController(ISocialLinkService  socialLinkService, ILogger<SocialLinkController> logger)
        {
            _socialLinkService = socialLinkService;
            _logger = logger;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<List<SocialLinkDTO>>> Get(ParamActorDTO dto)
        {
            try
            {
                var list = _socialLinkService.GetByActorId(dto.ActorId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Social link List for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<SocialLinkDTO>> Get(int id)
        {
            SocialLinkDTO model = new SocialLinkDTO();
            try
            {
                model = _socialLinkService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Social Link  By Id for Get  {e.Message}", e);
                throw;
            }
        }


        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<SocialLinkDTO>> Add([FromBody] SocialLinkDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _socialLinkService.Add(dto);
                if (!result.IsError)
                {
                    dto.LinkId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveSocialLink  for Add {e.Message}", e);
                throw;
            }
        }

        //[HttpPost]
        //[Route("Update")]
        //public async Task<ActionResult> Update([FromBody] SocialLinkDTO dto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
        //        }
        //        var response = _socialLinkService.Update(dto);
        //        return Ok(response);
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e, $"Update SocialLink for Update {e.Message}", e);
        //        throw;
        //    }
        //}

        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    try
        //    {
        //        _socialLinkService.Delete(id);
        //        return Ok();
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e, $"Delete Social Link for Delete {e.Message}", e);
        //        throw;
        //    }
        //}
    }
}

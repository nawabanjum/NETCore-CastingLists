﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly IHomeService _homeService;
        private readonly ILookUpService _lookUpService;
        private readonly ILogger<HomeController> _logger;
        public HomeController(ILookUpService lookUpService, IHomeService homeService, ILogger<HomeController> logger)
        {
            _homeService = homeService;
            _logger = logger;
            _lookUpService = lookUpService;
        }

        [HttpPost]
        [Route("List")]
        public async Task<ActionResult<ListCommonListDTO>> Get(GlobalSearch paginationDTO)
        {

            try
            {
                paginationDTO.CreatedByUserId = this.User.GetAuthenticatedUserId();
                paginationDTO.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var rslt = await _homeService.GetProjectsList(paginationDTO);
                return Ok(rslt);

            }
            catch (Exception e)
            {

                _logger.LogError(e, $"Get Project,list ,Roles for  {e.Message}", e);
                throw;
            }
        }

        [HttpGet]
        [Route("Tree")]
        public async Task<ActionResult<TreeDTO>> Tree()
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                var rslt = await _homeService.GetTree(createdByUserId, createdByUserType);
                return Ok(rslt);

            }
            catch (Exception e)
            {

                _logger.LogError(e, $"Get Tree Child Node, for  {e.Message}", e);
                throw;
            }
        }

    }
}

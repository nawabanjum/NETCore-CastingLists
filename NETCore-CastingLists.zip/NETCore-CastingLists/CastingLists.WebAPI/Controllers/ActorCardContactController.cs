﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorCardContactController : ControllerBase
    {
        private readonly IActorCardContactsService  _actorCardContactsService;
        private readonly ILogger<ActorCardContactController> _logger;
        public ActorCardContactController(IActorCardContactsService actorCardContactsService, ILogger<ActorCardContactController> logger)
        {
            _logger = logger;
            _actorCardContactsService = actorCardContactsService;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<ActorCardContactsDTO>> Get(ParamCastingActorDTO dto)
        {
            try
            {
                var list = _actorCardContactsService.Get(dto.ActorCardId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get CastingListActor Contact for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardContactsDTO>> Get(int id)
        {
            ActorCardContactsDTO model = new ActorCardContactsDTO();
            try
            {
                model = _actorCardContactsService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard Contact By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        public async Task<ActionResult<ActorCardContactsDTO>> Post([FromBody] ActorCardContactsDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardContactsService.Add(dto);
                if (!result.IsError)
                {
                    dto.ActrorCard_ContactsId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Contact for Post {e.Message}", e);
                throw;
            }
        }

        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult<ActorCardKnowsForDTO>> Update([FromBody] ActorCardContactsDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardContactsService.Update(dto);
                if (!result.IsError)
                {
                    dto.ActrorCard_ContactsId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update ActorCard Contact for Update {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _actorCardContactsService.Delete(id);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorCard Contact for Delete {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeSortOrder")]
        public async Task<ActionResult> ChangeSortOrder([FromBody] List<ActorSortDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }


                _actorCardContactsService.UpdateSortOrder(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Contact for ChangeSortOrder  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeHiddenStatus")]
        public async Task<ActionResult> ChangeHiddenStatus([FromBody] List<ActorStatusDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                _actorCardContactsService.UpdateSatus(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard Contact for ChangeHiddenStatus  {e.Message}", e);
                throw;
            }
        }
    }
}

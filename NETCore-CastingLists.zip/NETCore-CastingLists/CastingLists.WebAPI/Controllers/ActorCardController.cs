﻿using CastingLists.CoreLibrary.Models;
using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorCardController : ControllerBase
    {
        private readonly IActorCardService _actorCardService;
        private readonly IActorCardImdbService _actorCardImdbService;
        private readonly IActorMasterCastService _actorMasterCastService;
        private readonly ILogger<ActorCardController> _logger;
      
        public ActorCardController(IActorMasterCastService actorMasterCastService, IActorCardImdbService actorCardImdbService, IActorCardService actorCardService, ILogger<ActorCardController> logger)
        {
            _logger = logger;
            _actorCardService = actorCardService;
            _actorCardImdbService = actorCardImdbService;
            _actorMasterCastService = actorMasterCastService;
        }
        //[HttpGet]
        //[Route("All")]
        //public async Task<ActionResult<CastingListActorDTO>> Get()
        //{
        //    try
        //    {
        //        int createdByUserId = this.User.GetAuthenticatedUserId();
        //        int createdByUserType = this.User.GetAuthenticatedUserTypeId();
        //      var  list =  _actorCardService.Get(createdByUserId, createdByUserType);
        //        return Ok(list);
        //    }
        //    catch (Exception e)
        //    {

        //        _logger.LogError(e, $"Get CastingListActor for Get {e.Message}", e);
        //        throw;
        //    }
        //}

        [HttpGet]
        [Route("ByList")]
        public async Task<ActionResult<List<ActorCardDTO>>> GetActorByList(int listId)
        {
            List<ActorCardDTO> list = new List<ActorCardDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<ActorCardDTO>)_actorCardService.GetByListId(listId, createdByUserId, createdByUserType);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpGet]
        [Route("ByListSimplified ")]
        public async Task<ActionResult<List<ActorCardSimplifiedDTO>>> ByListSimplified(int listId)
        {
            List<ActorCardSimplifiedDTO> list = new List<ActorCardSimplifiedDTO>();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                list = (List<ActorCardSimplifiedDTO>)_actorCardService.GetByListSimplified(listId, createdByUserId, createdByUserType);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard By Id for Get  {e.Message}", e);
                throw;
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardDTO>> Get(int id)
        {
            ActorCardDTO model = new ActorCardDTO();
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                model = _actorCardService.GetById(id, createdByUserId, createdByUserType);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get ActorCard By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
      
        public async Task<ActionResult<ActorCardDTO>> Post([FromBody] ActorCardDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();

                var result = _actorCardService.Add(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard for Post {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ViaImdb")]
        public async Task<ActionResult<ParamActorImdbSearchDTO>> ViaImdb([FromBody] ParamActorImdbSearchDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _actorCardImdbService.Add(dto);
                if (!result.IsError)
                {
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard for ViaImdb {e.Message}", e);
                throw;
            }
        }

        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult> Update([FromBody] CastingListActorUpdateDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _actorCardService.Update(dto);
                if (!result.IsError)
                {
                    dto.Id = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Update ActorCard for Update {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                int createdByUserId = this.User.GetAuthenticatedUserId();
                int createdByUserType = this.User.GetAuthenticatedUserTypeId();
                _actorCardService.Delete(id, createdByUserId, createdByUserType);
                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Delete ActorCard for Delete {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeSortOrder")]
        public async Task<ActionResult> ChangeSortOrder([FromBody] List<ActorSortDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }


                _actorCardService.UpdateSortOrder(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard for ChangeSortOrder  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeHiddenStatus")]
        public async Task<ActionResult> ChangeHiddenStatus([FromBody] List<ActorStatusDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }


                _actorCardService.UpdateSatus(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard for ChangeHiddenStatus  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("ViaMasterCast")]
        public async Task<ActionResult<ParamActorMasterCastSearchDTO>> ViaMasterCast([FromBody] ParamActorMasterCastSearchDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                dto.CreatedByUserId = this.User.GetAuthenticatedUserId();
                dto.CreatedByUserType = this.User.GetAuthenticatedUserTypeId();
                var result = _actorMasterCastService.Add(dto);
                if (!result.IsError)
                {
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard for ViaImdb {e.Message}", e);
                throw;
            }
        }

    }
}

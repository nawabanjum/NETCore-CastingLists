﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using CastingLists.CoreLibrary.StaticMessages;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ListReportsController : ControllerBase
    {
        private readonly IActorReportService  _actorReportService;

        private readonly ILogger<ListReportsController> _logger;
        public ListReportsController(IActorReportService  actorReportService, ILogger<ListReportsController> logger)
        {
            _logger = logger;
            _actorReportService = actorReportService;
        }
        [HttpPost]
        [Route("Preview")]
        public async Task<ActionResult> Post([FromBody] GlobalSearchActorImdb dto)
        {
            try
            {
                
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                
                var result = await _actorReportService.GetActorList(dto);

                return Ok(result);

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Reports for Post {e.Message}", e);
                throw;
            }
        }

    }
}

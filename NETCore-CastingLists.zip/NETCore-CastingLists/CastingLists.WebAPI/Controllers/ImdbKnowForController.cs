﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CastingLists.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImdbKnowForController : ControllerBase
    {
        private readonly IKnowsForService _knowsForService;
        private readonly ILogger<ImdbKnowForController> _logger;
        public ImdbKnowForController(IKnowsForService knowsForService, ILogger<ImdbKnowForController> logger)
        {
            _knowsForService = knowsForService;
            _logger = logger;
        }

        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<List<KnowsForDTO>>> Get(ParamActorDTO dto)
        {
            try
            {
                var list = _knowsForService.GetByActorId(dto.ActorId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Actor Knows For List for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<KnowsForDTO>> Get(int id)
        {
            KnowsForDTO model = new KnowsForDTO();
            try
            {
                model = _knowsForService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get Knows For  By Id for Get  {e.Message}", e);
                throw;
            }
        }

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<KnowsForDTO>> Add([FromBody] KnowsForDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }
                var result = _knowsForService.Add(dto);
                if (!result.IsError)
                {
                    dto.KnowsId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Save KnowsFor  for Add {e.Message}", e);
                throw;
            }
        }

        //[HttpPost]
        //[Route("Update")]
        //public async Task<ActionResult> Update([FromBody] KnowsForDTO dto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid)
        //        {
        //            return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
        //        }
        //        var response = _knowsForService.Update(dto);
        //        return Ok(response);
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e, $"Update KnowsFor for Update {e.Message}", e);
        //        throw;
        //    }
        //}

        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    try
        //    {
        //        _knowsForService.Delete(id);
        //        return Ok();
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e, $"Delete KnowsFor for Delete {e.Message}", e);
        //        throw;
        //    }
        //}
    }
}

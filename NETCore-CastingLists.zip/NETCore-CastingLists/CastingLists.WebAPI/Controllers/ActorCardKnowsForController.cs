﻿using CastingLists.CoreLibrary.Models.DTO;
using CastingLists.CoreLibrary.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CastingLists.WebAPI.Controllers
{
    [Authorize("SamOrDirectorUser")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActorCardKnowsForController : ControllerBase
    {
        private readonly IActorCardKnowsForService _actorCardKnowsForService;
        private readonly ILogger<ActorCardKnowsForController> _logger;
        public ActorCardKnowsForController(IActorCardKnowsForService actorCardKnowsForService, ILogger<ActorCardKnowsForController> logger)
        {
            _actorCardKnowsForService = actorCardKnowsForService;
            _logger = logger;
        }
        [HttpPost]
        [Route("All")]
        public async Task<ActionResult<ActorCardKnowsForDTO>> Get(ParamCastingActorDTO dto)
        {
            try
            {
                var list = _actorCardKnowsForService.Get(dto.ActorCardId);
                return Ok(list);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Get CastingListActor KnowsFor for Get {e.Message}", e);
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ActorCardKnowsForDTO>> Get(int id)
        {
            try
            {

                ActorCardKnowsForDTO model = new ActorCardKnowsForDTO();
                model = _actorCardKnowsForService.GetById(id);
                return Ok(model);
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"Get ActorCard KnowsFor By Id for Get  {e.Message}", e);
                throw;
            }
        }


        [HttpPost]
        public async Task<ActionResult<ActorCardKnowsForDTO>> Post([FromBody] ActorCardKnowsForDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardKnowsForService.Add(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_KnowsForId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"SaveActorCard KnowsFor for Post {e.Message}", e);
                throw;
            }
        }


        [HttpPut]
        [Route("Update")]
        public async Task<ActionResult<ActorCardKnowsForDTO>> Update([FromBody] ActorCardKnowsForDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                var result = _actorCardKnowsForService.Update(dto);
                if (!result.IsError)
                {
                    dto.ActorCard_KnowsForId = (int)result.Id;
                    return Ok(dto);
                }
                return (new ObjectResult(result) { StatusCode = 500 });
            }
            catch (Exception e)
            {

                _logger.LogError(e, $"Update ActorCard KnowsFor for Update {e.Message}", e);
                throw;
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                _actorCardKnowsForService.Delete(id);
                return Ok();
            }
            catch (Exception  e)
            {

                _logger.LogError(e, $"Delete ActorCard KnowsFor for Delete {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeSortOrder")]
        public async Task<ActionResult> ChangeSortOrder([FromBody] List<ActorSortDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }


                _actorCardKnowsForService.UpdateSortOrder(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard KnowsFor for ChangeSortOrder  {e.Message}", e);
                throw;
            }
        }
        [HttpPost]
        [Route("ChangeHiddenStatus")]
        public async Task<ActionResult> ChangeHiddenStatus([FromBody] List<ActorStatusDTO> dto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                }

                _actorCardKnowsForService.UpdateSatus(dto);
                return Ok();

            }
            catch (Exception e)
            {
                _logger.LogError(e, $"SaveActorCard KnowsFor for ChangeHiddenStatus  {e.Message}", e);
                throw;
            }
        }
    }
}

using CastingLists.CoreLibrary.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Core5SharedLibrary;
using Core5SharedLibrary.Util;
using CastingLists.CoreLibrary.Services.Interfaces;
using CastingLists.CoreLibrary.Services;
using CastingLists.CoreLibrary.Repositories.Interfaces;
using CastingLists.CoreLibrary.Repositories;
using Core5SharedLibrary.Models;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Options;
using System.Text;
using Microsoft.AspNetCore.HttpOverrides;
using CastingLists.WebAPI.Filters;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc.Formatters;
using System.Text.Json;
using Microsoft.Extensions.FileProviders;
using System.IO;
using Core5SharedLibrary.Extensions;
using log4net.Config;

namespace CastingLists.WebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            Configuration = configuration;

            FileInfo fInfo;
            if (env.IsDevelopment())
                fInfo = env.GetLog4NetFile($"log4net.xml");
            else
            {
                if (File.Exists(Path.Combine(env.ContentRootPath, $"log4net.{env.EnvironmentName}.xml")))
                    fInfo = env.GetLog4NetFile($"log4net.{env.EnvironmentName}.xml");
                else
                    fInfo = env.GetLog4NetFile($"log4net.xml");
            }
            XmlConfigurator.Configure(fInfo);
            Console.WriteLine("Compilation=DEBUG");
            Console.WriteLine($"Environment={env.EnvironmentName}");

            if (!log4net.LogManager.GetRepository().Configured)
            {
                // log4net not configured
                foreach (log4net.Util.LogLog message in log4net.LogManager.GetRepository().ConfigurationMessages.Cast<log4net.Util.LogLog>())
                {
                    throw new InvalidOperationException("log4net not configured", message.Exception);
                }
            }
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "CastingLists.WebAPI", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter a valid token",
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type=ReferenceType.SecurityScheme,
                                Id="Bearer"
                            }
                        },
                        new string[]{}
                    }
                });
                c.OperationFilter<SwaggerFileOperationFilter>();
            });

            _RegisterRepositories(services);
            _RegisterServices(services);
            _Others(services);
            _DbContext(services);
            services.Configure<JwtConfigurableOptions>(Configuration.GetSection("JwtAuthentication"));
            services.Configure<UploadSettings>(Configuration.GetSection("UploadSettings"));
            services.Configure<ValidImageExtensions>(Configuration.GetSection("ValidImageExtensions"));
            services.Configure<ValidateImageSizes>(Configuration.GetSection("ValidateImageSizes"));
            services.Configure<CWBActorPhotoSetting>(Configuration.GetSection("CWBActorPhoto"));

            services.AddHttpClient();
            //Allow max lenght in request body for config
            services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(x =>
            {
                x.ValueLengthLimit = int.MaxValue;
                x.MultipartBodyLengthLimit = int.MaxValue;
                x.MultipartHeadersLengthLimit = int.MaxValue;
            });
            // Register the Swagger generator, defining one or more Swagger documents

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });
            services.ConfigureSwaggerGen(options =>
            {
                options.OperationFilter<Operation>(); //Register File Upload Operation Filter
            });
            services.AddAuthorization(options =>
            {
                options.AddPolicy("SamOrDirectorUser", policy =>
                 {
                     policy.RequireAuthenticatedUser();
                     policy.Requirements.Add(new AssertionRequirement(add =>
                     {
                         if (add.User.Identities == null ||
                             !add.User.Identities.Any() ||
                             add.User.Identities.All(a => !a.IsAuthenticated))
                             return false;

                         var userPair = add.User.GetAuthUserTypeAndUserId();
                         var sellerId = add.User.GetAuthenticatedUserSellerId();

                         if (userPair.userType == 2)
                             return true;

                         if (userPair.userType == 3)
                         {
                             if (sellerId == 103)
                                 return true;
                         }

                         return false;
                     }));
                 });

            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(a =>
                {
                    var tempProvider = services.BuildServiceProvider();
                    var configurableOptions = tempProvider.GetService<IOptions<JwtConfigurableOptions>>();

                    var token = (TokenValidationParameters)new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(configurableOptions.Value?.SigningKey ?? "")),
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidIssuer = configurableOptions.Value?.ValidIssuer,
                        ValidAudience = configurableOptions.Value?.ValidAudience,
                    };

                    a.RequireHttpsMetadata = false;
                    a.TokenValidationParameters = token;
                });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddLog4Net();
            if (!env.IsProduction())
            {
                app.UseDeveloperExceptionPage();
            }
            app.Use(async (context, next) =>
            {
                context.Features.Get<Microsoft.AspNetCore.Http.Features.IHttpMaxRequestBodySizeFeature>().MaxRequestBodySize = 4294967295;
                await next.Invoke();
            });
            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swagger, httpReq) =>
                {
                    var ngrok = new OpenApiServer { Url = $"https://cwb-int-api.ngrok.io/{httpReq.PathBase.ToString().TrimStart('/')}".TrimEnd('/') };
                    if (!env.IsDevelopment())
                    {
                        var list = swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"https://{httpReq.Host.Value}/{httpReq.PathBase.ToString().TrimStart('/')}".TrimEnd('/') } };
                        if (!env.IsProduction())
                        {
                            list.Insert(0, ngrok);
                        }
                    }
                    else
                    {
                        swagger.Servers = swagger?.Servers.ToList() ?? new List<OpenApiServer>();
                        swagger.Servers.Add(ngrok);
                    }
                });
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("v1/swagger.json", "CastingLists.WebAPI v1");
            });

            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(
       Configuration.GetSection("UploadSettings")["ImdbSaveFolderLocation"]),
                RequestPath = Configuration.GetSection("UploadSettings")["ImdbSaveUrlLocation"]

            });
            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(
       Configuration.GetSection("UploadSettings")["ActorCardSaveFolderLocation"]),
                RequestPath = Configuration.GetSection("UploadSettings")["ActorCardSaveUrlLocation"]

            });
            var allValidOrigins = new[]
            {
                "http://localhost",
                "localhost:3000",
                "http://localhost:3000",
                "https://localhost:3000",
                "http://*.thecwbintlocal.com",
                "https://*.thecwbintlocal.com",
                "http://thecwbintlocal.com",
                "https://thecwbintlocal.com",
                "http://*.thecwbint.com",
                "https://*.thecwbint.com",
                "http://thecwbint.com",
                "https://thecwbint.com",
                "http://*.castingworkbook.com",
                "https://*.castingworkbook.com",
                "http://castingworkbook.com",
                "https://castingworkbook.com",
                "http://teamshare.thecwbint.com",
                "https://teamshare.thecwbint.com"
            }.Concat(new[] {
                "chrome-extension://*",
                "chrome-extension://khbmjebikhbmdmfbeclecggjnmhcljgn"
                }).ToArray();
            if (env.IsProduction())
                app.UseHttpsRedirection();

            app.UseCors(settings =>
              settings
              .SetIsOriginAllowedToAllowWildcardSubdomains()
              .WithOrigins(allValidOrigins)
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials()
          );

            app.UseAuthentication();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.UseStaticFiles();
            app.UseForwardedHeaders();



        }


        private void _RegisterServices(IServiceCollection services)
        {
            services.AddScoped<IJobService, JobService>();
            services.AddScoped<IProjectService, ProjectService>();
            services.AddScoped<IListService, ListService>();
            services.AddScoped<ILookUpService, LookUpService>();
            services.AddScoped<IRoleService, RoleService>();
            services.AddScoped<IHomeService, HomeService>();
            services.AddScoped<IActorService, ActorService>();
            services.AddScoped<IActorContactsService, ActorContactsService>();
            services.AddScoped<IKnowsForService, KnowsForService>();
            services.AddScoped<ISocialLinkService, SocialLinkService>();
            services.AddScoped<IActorPrivateNotesService, ActorPrivateNotesService>();
            services.AddScoped<IClientService, ClientService>();
            services.AddScoped<IActorCardService, ActorCardService>();
            services.AddScoped<IActorCardVideoSrvice, ActorCardVideoSrvice>();
            services.AddScoped<IActorCardPrivateNoteService, ActorCardPrivateNoteService>();
            services.AddScoped<IActorCardKnowsForService, ActorCardKnowsForService>();
            services.AddScoped<IActorCardEthnicityService, ActorCardEthnicityService>();
            services.AddScoped<IActorCardContactsService, ActorCardContactsService>();
            services.AddScoped<IFilmographyService, FilmographyService>();
            services.AddScoped<IActorReportService, ActorReportService>();
            services.AddScoped<IActorCardReportExportsService, ActorCardReportExportsService>();
            services.AddScoped<IActorCardImageService, ActorCardImageService>();
            services.AddScoped<IActorCardImdbService, ActorCardImdbService>();
            services.AddScoped<IActorCardLinkService, ActorCardLinkService>();
            services.AddScoped<IActorMasterCastService, ActorMasterCastService>();
            services.AddScoped<ISynchronizationCastListService,  SynchronizationCastListService>();
            services.AddScoped<ISynchronizationImdbActorService,  SynchronizationImdbActorService>();
            services.AddScoped<IActorImdbImagesService, ActorImdbImagesService>();
        }
        private void _RegisterRepositories(IServiceCollection services)
        {
            services.AddScoped<IJobRepository, JobRepository>();
            services.AddScoped<IProjectRepository, ProjectRepository>();
            services.AddScoped<IListRepository, ListRepository>();
            services.AddScoped<ILookupRepository, LookupRepository>();
            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddScoped<IHomeRepository, HomeRepository>();
            services.AddScoped<IActorRepository, ActorRepository>();
            services.AddScoped<IActorContactsRepository, ActorContactsRepository>();
            services.AddScoped<IKnowsForRepository, KnowsForRepository>();
            services.AddScoped<ISocialLinkRepository, SocialLinkRepository>();
            services.AddScoped<IActorImdbArchiveRepository, ActorImdbArchiveRepository>();
            services.AddScoped<IActorPrivateNotesRepository, ActorPrivateNotesRepository>();
            services.AddScoped<IClientRepository, ClientRepository>();
            services.AddScoped<IActorCardRepository, ActorCardRepository>();
            services.AddScoped<IActorCardVideoRepository, ActorCardVideoRepository>();
            services.AddScoped<IActorCardContactsRepository, ActorCardContactsRepository>();
            services.AddScoped<IActorCardPrivateNoteRepository, ActorCardPrivateNoteRepository>();
            services.AddScoped<IActorCardKnowsForRepository, ActorCardKnowsForRepository>();
            services.AddScoped<IActorCardEthnicityRepository, ActorCardEthnicityRepository>();
            services.AddScoped<IFilmographyRepository, FilmographyRepository>();
            services.AddScoped<IActorReportRepository, ActorReportRepository>();
            services.AddScoped<IActorCardReportExportsRepository, ActorCardReportExportsRepository>();
            services.AddScoped<IActorCardImageRepository, ActorCardImageRepository>();
            services.AddScoped<IActorCardImdbRepository, ActorCardImdbRepository>();
            services.AddScoped<IActorCardLinkRepository, ActorCardLinkRepository>();
            services.AddScoped<IActorMasterCastRepository, ActorMasterCastRepository>();
            services.AddScoped<IMasterCastImdbActorConnectionRepository, MasterCastImdbActorConnectionRepository>();
            services.AddScoped<ISynchronizationCastListRepository, SynchronizationCastListRepository>();
            services.AddScoped<ISynchronizationImdbActorRepository, SynchronizationImdbActorRepository>();
            services.AddScoped<IActorImdbImagesRepository, ActorImdbImagesRepository>();

        }
        private void _DbContext(IServiceCollection services)
        {
            // DB Context
            services.AddDbContextPool<ProjectManContext>(options => options.UseSqlServer(Configuration.GetConnectionString("ProjectMan")));

        }

        private void _Others(IServiceCollection services)
        {
            services.AddScoped<IDataConnector>(a => new DataConnector(Configuration));
            services.AddControllers().AddNewtonsoftJson(x => x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Serialize);

        }
    }
}

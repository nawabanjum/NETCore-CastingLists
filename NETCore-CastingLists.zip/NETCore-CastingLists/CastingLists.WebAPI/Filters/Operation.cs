﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CastingLists.WebAPI.Filters
{
   
        public class Operation : IOperationFilter
        {
            public void Apply(OpenApiOperation operation, OperationFilterContext context)
            {
                      var prm = operation.Parameters.FirstOrDefault(t => t.Name == "authorization");
                if (prm != null)
                {
                    operation.Parameters.Remove(prm);
                    operation.Parameters.Add(new OpenApiParameter
                    {
                        Name = "authorization",
                        In = ParameterLocation.Header,
                        Required = true,
                        Schema = new OpenApiSchema
                        {
                            Type = "string"
                        }
                    });
                }

               }
        }
    
}

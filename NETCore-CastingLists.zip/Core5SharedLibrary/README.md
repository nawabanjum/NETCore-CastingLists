# Core5SharedLibrary
Built in .net core 5, Just like dotnet-core-modern but all shared resources in one project only.

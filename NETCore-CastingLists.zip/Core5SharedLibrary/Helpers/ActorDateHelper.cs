﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Core5SharedLibrary.Interfaces;
using Core5SharedLibrary.Models;
using Dapper;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace Core5SharedLibrary.Helpers
{
    public class ActorDateHelper : IActorDateHelper
    {
        private readonly IDataConnector _dataConnector;
        private readonly IMemoryCache _memoryCache;
        private readonly CWBCacheEntryOptions _cacheSettings;

        public ActorDateHelper(IDataConnector dataConnector,
            IMemoryCache memoryCache, IOptions<CWBCacheEntryOptions> cacheEntryOptions)
        {
            _dataConnector = dataConnector;
            //   _userData = userData;
            _memoryCache = memoryCache;
            _cacheSettings = cacheEntryOptions?.Value;
        }


        /// <summary>
        /// Converts the given dateToConvert time to Logged-In users home city Date Time
        /// </summary>
        /// <param name="dateToConvert"></param>
        /// <param name="offSetInHours">Add this so a call to database is not made each time, when cache is disabled</param>
        /// <returns>Converted Date Time to Logged-In User Home City</returns>
        public async Task<DateTime?> ToUserHomeCityTime(DateTime? dateToConvert, int offSetInHours)
        {
            if (!dateToConvert.HasValue || dateToConvert == default(DateTime)) return null;

            if (offSetInHours == 0) return dateToConvert;

            return dateToConvert.Value.AddHours(offSetInHours);
        }



        /// <summary>
        /// Converts the given dateToConvert time to given users home city Date Time
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <param name="dateToConvert"></param>
        /// <returns>Converted Date Time to given User Home City</returns>
        public async Task<DateTime?> ToUserHomeCityTime(int userId, int userType, DateTime? dateToConvert)
        {
            if (!dateToConvert.HasValue || dateToConvert == default(DateTime)) return null;

            if (userId <= 0 || userType <= 0) return dateToConvert;
            var homeCityInfo = await GetUserHomeCityDetailsCached(userId, userType);
            if (homeCityInfo == null || homeCityInfo.OffSetInHours == 0) return dateToConvert;

            return dateToConvert.Value.AddHours(homeCityInfo.OffSetInHours);
        }


        /// <summary>
        /// Converts logged-in user date time to server (Vancouver) date time
        /// </summary>
        /// <param name="dateToConvert"></param>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        public async Task<DateTime?> ConvertUserDateToVancouverTime(DateTime? dateToConvert, int userId, int userType)
        {
            if (userId <= 0 || userType <= 0) return dateToConvert;
            if (!dateToConvert.HasValue || dateToConvert == default(DateTime)) return null;

            var userHomeCityOffSet = await GetUserHomeCityOffSetInHours(userId, userType);

            var serverOffset = GetServerDateTimeOffset(dateToConvert.Value);
            if (!serverOffset.HasValue)
                return dateToConvert.Value;

            var delta = serverOffset.Value.Offset.Hours - userHomeCityOffSet;

            return dateToConvert.Value.AddHours(delta);
        }


        /// <summary>
        /// Gets server offset from a given date time
        /// </summary>
        /// <param name="dateToConvert"></param>
        /// <returns></returns>
        public DateTimeOffset? GetServerDateTimeOffset(DateTime? dateToConvert)
        {
            if (!dateToConvert.HasValue || dateToConvert == default(DateTime)) return null;

            var currentZone = TimeZoneInfo.Local;
            const string pacificStandardTime = "Pacific Standard Time";
            if (currentZone.Id == pacificStandardTime)
                return new DateTimeOffset(dateToConvert.Value);

            var baseUtcOffset = TimeZoneInfo.FindSystemTimeZoneById(pacificStandardTime).BaseUtcOffset;
            return new DateTimeOffset(dateToConvert.Value, baseUtcOffset);
        }


        /// <summary>
        /// Use it to get home city id by any user Id and user Type
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <returns>Home City Id</returns>
        public async Task<int> GetUserHomeCityId(int userId, int userType)
        {
            if (userId <= 0 || userType <= 0) return 0;
            var homeCityInfo = await GetUserHomeCityDetailsCached(userId, userType);
            if (homeCityInfo == null || homeCityInfo.OffSetInHours == 0) return 0;

            return homeCityInfo.HomeCityId;
        }


        /// <summary>
        /// Use it to get the any user home city offset in hours by userId and userType
        /// </summary>
        /// <returns>home city offset in hours</returns>
        public async Task<int> GetUserHomeCityOffSetInHours(int userId, int userType)
        {
            if (userId <= 0 || userType <= 0) return 0;
            var homeCityInfo = await GetUserHomeCityDetailsCached(userId, userType);
            if (homeCityInfo == null || homeCityInfo.OffSetInHours == 0) return 0;

            return homeCityInfo.OffSetInHours;
        }


        private async Task<UserHomeCityDto> GetUserHomeCityDetailsCached(int userId, int userType)
        {
            var cacheKey = $"UserHomeCityCache-Id{userId}-Type{userType}";

            var result = await _memoryCache.GetOrCreateAsync(cacheKey, a =>
            {
                a.SetOptions(_cacheSettings);
                return userType == 8 ? GetClientHomeCityDetails(userId) : null; // Only supporting Clients right now
            });

            return result;
        }


        private async Task<UserHomeCityDto> GetClientHomeCityDetails(int clientId)
        {
            var sql = $@"
                   SELECT 
                        clientId AS UserId, 
            		    8 AS UserType, -- User Type for Clients
            		    residence AS HomeCityId, 
            		    hourOffSet AS OffSetInHours
                    FROM clients..tblClients client (NOLOCK) 
                    INNER JOIN casting..lstCities city (NOLOCK) ON city.CityID = client.residence
                    WHERE client.clientId = {clientId}
                ";

            using (var conn = _dataConnector.GetOpenConnection())
            {
                var options = await conn.QueryAsync<UserHomeCityDto>(sql);
                return options.FirstOrDefault();
            }
        }

    }

}

﻿using Core5SharedLibrary.Extensions;
using Core5SharedLibrary.Models;
using System;
using System.Linq;
using System.Security.Authentication;
using System.Security.Claims;
using System.Security.Principal;

namespace Core5SharedLibrary.Helpers
{
    public static class CWBIdentityHelper
    {
        public static int GetAuthenticatedUserId(this IPrincipal principal)
        {
            if (!principal.Identity.IsAuthenticated)
                throw new AuthenticationException("User not authenticated");

            principal.ThrowErrorIfMoreThanOneIdentityIsAuthenticated();

            var claimsIdentity = principal.Identity as ClaimsIdentity;
            return claimsIdentity.GetAuthenticatedUserId();
        }

        public static int GetAuthenticatedUserId(this ClaimsIdentity claimsIdentity)
        {
            if (claimsIdentity == null)
                throw new NullReferenceException(nameof(claimsIdentity));

            var userIdClaim = claimsIdentity.FindFirst(CWBClaimsDefinition.UserIdClaim);

            if (userIdClaim == null)
                throw new NullReferenceException(nameof(userIdClaim));

            return userIdClaim.Value.ConvertToInt32OrDefault();
        }

        public static int GetAuthenticatedUserTypeId(this IPrincipal principal)
        {
            if (!principal.Identity.IsAuthenticated)
                throw new AuthenticationException("User not authenticated");

            principal.ThrowErrorIfMoreThanOneIdentityIsAuthenticated();

            var claimsIdentity = principal.Identity as ClaimsIdentity;
            return claimsIdentity.GetAuthenticatedUserTypeId();
        }

        public static int GetAuthenticatedUserTypeId(this ClaimsIdentity claimsIdentity)
        {
            if (claimsIdentity == null)
                throw new NullReferenceException(nameof(claimsIdentity));

            var userTypeClaim = claimsIdentity.FindFirst(CWBClaimsDefinition.UserTypeClaim);
            if (userTypeClaim == null)
                throw new NullReferenceException(nameof(userTypeClaim));

            return userTypeClaim.Value.ConvertToInt32OrDefault();
        }

        public static int GetAuthenticatedUserSellerId(this IPrincipal principal)
        {
            if (!principal.Identity.IsAuthenticated)
                throw new AuthenticationException("User not authenticated");

            principal.ThrowErrorIfMoreThanOneIdentityIsAuthenticated();

            var claimsIdentity = principal.Identity as ClaimsIdentity;
            return claimsIdentity.GetAuthenticatedUserSellerId();
        }

        public static int GetAuthenticatedUserSellerId(this ClaimsIdentity claimsIdentity)
        {
            if (claimsIdentity == null)
                throw new NullReferenceException(nameof(claimsIdentity));

            var sellerIdClaim = claimsIdentity.FindFirst(CWBClaimsDefinition.SellerId);
            if (sellerIdClaim == null)
                throw new NullReferenceException(nameof(sellerIdClaim));

            return sellerIdClaim.Value.ConvertToInt32OrDefault();
        }

        public static int GetAuthenticatedUserLanguageChoice(this IPrincipal principal)
        {
            if (!principal.Identity.IsAuthenticated)
                throw new AuthenticationException("User not authenticated");

            principal.ThrowErrorIfMoreThanOneIdentityIsAuthenticated();

            var claimsIdentity = principal.Identity as ClaimsIdentity;
            return claimsIdentity.GetAuthenticatedUserLanguageChoice();
        }

        public static int GetAuthenticatedUserLanguageChoice(this ClaimsIdentity claimsIdentity)
        {
            if (claimsIdentity == null)
                throw new NullReferenceException(nameof(claimsIdentity));

            // languagechoice is usually 0 therefore the JWT token will not have it, which results in in this claim to be null.
            var languageChoiceClaim = claimsIdentity.FindFirst(CWBClaimsDefinition.LanguageChoice);
            return languageChoiceClaim?.Value.ConvertToInt32OrDefault() ?? 0;
        }

        public static void ThrowErrorIfMoreThanOneIdentityIsAuthenticated(this IPrincipal principal)
        {
            if (principal is ClaimsPrincipal claimsPrincipal)
            {
                if (claimsPrincipal.Identities.Count(a => a.IsAuthenticated) > 1 &&
                    claimsPrincipal.Identities.Select(a => a.GetAuthUserTypeAndUserId()).Distinct().Count() > 1)
                {
                    //ClaimsPrincipal.ClaimsPrincipalSelector
                    //ClaimsPrincipal.PrimaryIdentitySelector
                    //todo: pick the best authenticated identity
                    //todo implement: (priority would be JWT / cookie / session  / qs)
                    throw new InvalidOperationException("Primary identity is not defined (there is no support for multiple authentication types)");
                }
            }
        }

        public static (int userType, int userId) GetAuthUserTypeAndUserId(this IPrincipal principal)
        {
            if (!principal.Identity.IsAuthenticated)
                throw new AuthenticationException("User not authenticated");

            principal.ThrowErrorIfMoreThanOneIdentityIsAuthenticated();

            var claimsIdentity = principal.Identity as ClaimsIdentity;
            return claimsIdentity.GetAuthUserTypeAndUserId();
        }

        public static (int userType, int userId) GetAuthUserTypeAndUserId(this ClaimsIdentity claimsIdentity)
        {
            if (claimsIdentity == null)
                throw new NullReferenceException(nameof(claimsIdentity));

            var userIdClaim = claimsIdentity.FindFirst(CWBClaimsDefinition.UserIdClaim);
            if (userIdClaim == null)
                throw new NullReferenceException(nameof(userIdClaim));

            var userTypeClaim = claimsIdentity.FindFirst(CWBClaimsDefinition.UserTypeClaim);
            if (userTypeClaim == null)
                throw new NullReferenceException(nameof(userTypeClaim));

            var userType = userTypeClaim.Value.ConvertToInt32OrDefault();
            var userId = userIdClaim.Value.ConvertToInt32OrDefault();

            return (userType, userId);
        }


        public static string GetUserWebSessionKey(this IPrincipal principal)
        {
            if (!principal.Identity.IsAuthenticated)
                throw new AuthenticationException("User not authenticated");

            principal.ThrowErrorIfMoreThanOneIdentityIsAuthenticated();

            var claimsIdentity = principal.Identity as ClaimsIdentity;
            var webSessionKey = claimsIdentity.FindFirst("WebSessionKey");
            return webSessionKey.Value;
        }
    }
}

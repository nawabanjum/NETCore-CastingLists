﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Core5SharedLibrary.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace Core5SharedLibrary.Middlewares
{
    /// <summary>
    /// This middleware restricts calls to swagger in production environment.
    /// It would only work in Local environment or with internal IP addresses or IP addresses mentioned in Whitelist inside appSettings
    ///
    /// Make sure to add the appropriate keys in appSettings 
    ///  "InternalAccessSettings": {
    ///     "AllowPrivateAddresses": true,
    ///     "WhiteList": [ "184.70.140.190", "54.188.149.149", "52.27.167.249" ]
    ///     }
    ///
    ///  AND configure in startup.cs
    /// services.Configure<InternalAccessOptions>(Configuration.GetSection("GeneralAuthSettings:InternalAccessSettings"));
    /// 
    /// </summary>
    public class InternalSwaggerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IWebHostEnvironment _env;
        private readonly IOptions<InternalAccessOptions> _accessOptions;

        public InternalSwaggerMiddleware(RequestDelegate next, IWebHostEnvironment env, IOptions<InternalAccessOptions> accessOptions)
        {
            _next = next;
            _env = env;
            _accessOptions = accessOptions;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var ipAddress = context.Connection?.RemoteIpAddress?.ToString();
            var whiteList = _accessOptions.Value.WhiteList;
            if (context.Request.Path.Value.Contains("/swagger")
                && _env.IsProduction()
                && !IsLocal(context.Connection)
                && !(whiteList != null && whiteList.Any(o => o.Equals(ipAddress)))
            )
            {
                context.Response.StatusCode = 401; // Unauthorized
                await context.Response.WriteAsync($"Unauthorized ({ipAddress})");
                return;
            }


            await _next.Invoke(context);
        }

        private bool IsLocal(ConnectionInfo connInfo)
        {
            var ipAddress = connInfo.RemoteIpAddress.ToString();

            var ipParts = ipAddress.Split(new[] { "." }, StringSplitOptions.RemoveEmptyEntries)
                .Select(a =>
                {
                    if (int.TryParse(a, out int value))
                        return new int?(value);

                    return new int?();
                }).Where(a => a.HasValue).Select(a => a.Value).ToArray();

            if (ipParts.Length <= 0)
            {
                if (ipAddress == "::1")
                    return true;

                return false;
            }
            // in private ip range
            if (
                connInfo.LocalIpAddress.Equals(connInfo.RemoteIpAddress) ||
                ipParts[0] == 10 ||
                ipParts[0] == 192 && ipParts[1] == 168 ||
                ipParts[0] == 172 && ipParts[1] >= 16 && ipParts[1] <= 31)
            {
                return true;
            }

            // IP Address is probably public.
            // This doesn't catch some VPN ranges like OpenVPN and Hamachi.
            return false;
        }

    }
}

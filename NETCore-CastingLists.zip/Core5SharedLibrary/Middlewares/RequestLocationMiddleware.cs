﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using Core5SharedLibrary.Helpers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.Net.Http.Headers;

namespace Core5SharedLibrary.Middlewares
{
    public static class RequestLocalizationMiddleware
    {
        /// <summary>
        ///  The following middleware must be used after UseAuthentication() so that User Localized settings can be retrieved
        ///     app.UseRequestLocalization(RequestLocalization.getRequestLocalizationOptions());
        /// </summary>
        /// <returns></returns>
        public static RequestLocalizationOptions GetRequestLocalizationOptions()
        {
            var supportedCultures = new List<CultureInfo>
            {
                new CultureInfo("en-GB"),
                new CultureInfo("en-US"),
                new CultureInfo("en-CA"),
                new CultureInfo("en"),
                new CultureInfo("en-AU"),
                new CultureInfo("en"),
                new CultureInfo("fr-CA"),
                new CultureInfo("fr-FR"),
                new CultureInfo("fr"),
                new CultureInfo("es-ES"),
                new CultureInfo("es"),
                new CultureInfo("nb-NO"), // For X Language
                new CultureInfo("nb") // For X Language
            };

            var requestLocalizationOptions = new RequestLocalizationOptions()
            {
                DefaultRequestCulture = new RequestCulture("en-US", "en-US"),
                SupportedCultures = supportedCultures,
                SupportedUICultures = supportedCultures,
            };

            // Define custom provider to get the default culture from Database if user is logged in. Otherwise, get it from request headers.
            requestLocalizationOptions.RequestCultureProviders.Insert(0, new CustomRequestCultureProvider(async context =>
            {
                var typeHeaders = context.Request.GetTypedHeaders();

                var userAgents = context.Request.Headers["User-Agent"];
                var browserAcceptLanguage = typeHeaders.AcceptLanguage;
                var androidAppHeader = context.Request.Headers["X-App-Android-Lang"].FirstOrDefault();

                // Android App
                if (!string.IsNullOrWhiteSpace(androidAppHeader))
                    return GetSupportedLanguageByHeader(supportedCultures, androidAppHeader);

                if (userAgents.Any())
                {
                    // iOS App
                    if (userAgents.Any(o => o.ToLower().Contains("selftaping")) && userAgents.Any(o => o.ToLower().Contains("alamofire")))
                        return GetSupportedLanguageByHeader(supportedCultures, browserAcceptLanguage);
                }

                // Android or iOS browser follow the same rule as any other browser
                //if ((userAgents.Any(o => o.ToLower().Contains("dalvik")) && (userAgents.Any(o => o.ToLower().Contains("android")))) ||
                //(userAgents.Any(o => o.ToLower().Contains("darwin"))))
                {
                    var result = context.User.Identity.IsAuthenticated
                        ? GetUserLanguage(context.User)
                        : GetSupportedLanguageByHeader(supportedCultures, browserAcceptLanguage);
                    return result;
                }
            }));

            return requestLocalizationOptions;
        }

        private static ProviderCultureResult GetSupportedLanguageByHeader(IList<CultureInfo> supportedCultures, string acceptLanguage)
        {
            if (string.IsNullOrWhiteSpace(acceptLanguage))
                return new ProviderCultureResult("en-US");

            var cultureInfo = supportedCultures.FirstOrDefault(o => acceptLanguage.Contains(o.Name));
            if (cultureInfo == null)
                return new ProviderCultureResult("en-US");

            return new ProviderCultureResult(cultureInfo.Name);
        }

        private static ProviderCultureResult GetSupportedLanguageByHeader(IList<CultureInfo> supportedCultures, IList<StringWithQualityHeaderValue> acceptLanguage)
        {
            if (acceptLanguage == null || acceptLanguage.Count <= 0)
                return new ProviderCultureResult("en-US");

            var cultureInfo = acceptLanguage.Select((obj, i) => (index: i, lang: obj))
                .OrderByDescending(a =>
                {
                    if (a.lang.Quality.HasValue)
                        return a.lang.Quality;

                    return a.index == 0 ? 1 : -1;
                })
                .Select(o =>
                    supportedCultures.FirstOrDefault(b =>
                        o.lang.Value.ToString().IndexOf(b.Name, StringComparison.OrdinalIgnoreCase) > -1)
                )
                .FirstOrDefault(a => a != null);
            if (cultureInfo == null)
                return new ProviderCultureResult("en-US");

            return new ProviderCultureResult(cultureInfo.Name);
        }


        private static ProviderCultureResult GetUserLanguage(ClaimsPrincipal user)
        {
            // Get the language culture - Defaults to English
            var userLanguageChoice = user.GetAuthenticatedUserLanguageChoice();
            switch (userLanguageChoice)
            {
                // Not supported yet French
                case 1:
                    return new ProviderCultureResult("fr-FR");
                // English (United Kingdom)
                case 2:
                    return new ProviderCultureResult("en-GB");
                // Spanish
                case 3:
                    return new ProviderCultureResult("es-ES");
                // X Language
                case 99:
                    return new ProviderCultureResult("nb-NO");
                default:
                    return new ProviderCultureResult("en-US");
            }
        }
    }


    public static class HttpRequestExtensions
    {
        public static string[] GetUserLanguages(this HttpRequest request)
        {
            return request.GetTypedHeaders()
                       .AcceptLanguage
                       ?.OrderByDescending(x => x.Quality ?? 1)
                       .Select(x => x.Value.ToString())
                       .ToArray() ?? Array.Empty<string>();
        }
    }
}

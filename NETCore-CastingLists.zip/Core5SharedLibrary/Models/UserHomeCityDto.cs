﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Models
{
    public class UserHomeCityDto
    {
        public int UserId { get; set; }
        public int UserType { get; set; }
        public int HomeCityId { get; set; }
        public int OffSetInHours { get; set; }

    }
}

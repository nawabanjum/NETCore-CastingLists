﻿namespace Core5SharedLibrary.Models
{
    public static class CWBClaimsDefinition
    {
        public static readonly string Login = "Login";

        public static readonly string SecurityStamp = "SStamp";

        public static readonly string UserTypeClaim = nameof(CookieIdentity.UserType);
        public static readonly string UserIdClaim = nameof(CookieIdentity.UserId);

        public static readonly string FirstName = "FirstName";
        public static readonly string LastName = "LastName";
        public static readonly string Gender = "GenderId";

        public static readonly string SellerId = "SellerId";
        public static readonly string StudioId = "StudioId";

        public static readonly string TalentWorkbookId = "WorkbookId";

        public static readonly string LanguageChoice = "LanguageId";

        public static readonly string ClientType = "ClientType";
        public static readonly string ActorSubType = "ActorSubType";

        public static readonly string RosterId = "RosterId";
        public static readonly string Residence = "Residence";
        public static readonly string MiddleName = "MiddleName";
        public static readonly string AgencyId = "AgencyId";

        public static readonly string IpAddress = "Ip";

        public static readonly string WebSessionKey = "WebSessionKey";
    }
}

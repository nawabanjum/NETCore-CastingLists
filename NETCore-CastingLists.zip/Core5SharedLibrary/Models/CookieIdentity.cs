﻿using System.Security.Principal;

namespace Core5SharedLibrary.Models
{
    public class CookieIdentity : IIdentity
    {
        public CookieIdentity(int userId, string userName, int userType, string authenticationType, bool isAuthenticated)
        {
            UserId = userId;
            Name = userName;
            UserType = userType;
            AuthenticationType = authenticationType;
            IsAuthenticated = isAuthenticated;
        }
        public string Name { get; }
        public int UserId { get; }
        public int UserType { get; }
        public string AuthenticationType { get; }
        public bool IsAuthenticated { get; }
    }
}

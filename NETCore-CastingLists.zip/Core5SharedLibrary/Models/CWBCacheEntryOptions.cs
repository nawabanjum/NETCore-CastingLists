﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

namespace Core5SharedLibrary.Models
{
    public class CWBCacheEntryOptions : MemoryCacheEntryOptions
    {
        private bool _disabled;

        public bool Disabled
        {
            get => _disabled;
            set
            {
                if (value)
                {
                    AbsoluteExpirationRelativeToNow = null;
                    SlidingExpiration = null;
                    this.SetAbsoluteExpiration(default(DateTime));
                    this.SetSize(0);
                }
                _disabled = value;
            }
        }
    }
}
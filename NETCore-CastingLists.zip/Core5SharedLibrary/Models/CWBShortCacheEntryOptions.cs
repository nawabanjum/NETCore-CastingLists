﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Models
{
    public class CWBShortCacheEntryOptions : CWBCacheEntryOptions
    {
        // Using this class for a very short cache like 1 minute cache (Typically used for searches)
    }
}

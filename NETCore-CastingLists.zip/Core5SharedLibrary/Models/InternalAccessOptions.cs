﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Models
{
    public class InternalAccessOptions
    {
        public bool AllowPrivateAddresses { get; set; }
        public string[] WhiteList { get; set; }
    }
}
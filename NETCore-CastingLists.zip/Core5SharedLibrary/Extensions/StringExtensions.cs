﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Extensions
{
    /// <summary>
    /// Extension methods for String class
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Removes invalid characters from the string, and replace them with underscore (_)
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string Sanitize(this string str)
        {
            if (string.IsNullOrWhiteSpace(str)) return null;

            var invalid = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
            foreach (var c in invalid)
                str = str.Replace(c.ToString(), "_");

            return str;
        }


        public static string ToBase64Encode(this Guid guidToConvertToBase64)
        {
            if (guidToConvertToBase64 == Guid.Empty) return string.Empty;

            return Convert.ToBase64String(Encoding.UTF8.GetBytes(guidToConvertToBase64.ToString()));
        }


        public static Guid ToBase64Decode(this string base64String)
        {
            if (string.IsNullOrWhiteSpace(base64String)) return Guid.Empty;

            try
            {
                var base64EncodedBytes = Convert.FromBase64String(base64String);
                return Guid.Parse(Encoding.UTF8.GetString(base64EncodedBytes));
            }
            catch (Exception)
            {
                return Guid.Empty;
            }

        }
        public static bool ContainsEx(this string text, string word, StringComparison stringComparison = StringComparison.OrdinalIgnoreCase)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                if (string.IsNullOrWhiteSpace(word))
                    return true;

                return false;
            }

            if (text == word)
                return true;

            var result = text.IndexOf(word, stringComparison) > -1;
            return result;
        }
    }
}

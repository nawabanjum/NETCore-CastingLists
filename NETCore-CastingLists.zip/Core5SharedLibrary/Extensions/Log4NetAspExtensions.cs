﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using Core5SharedLibrary.Util.Logging;

namespace Core5SharedLibrary.Extensions
{
    public static class Log4NetAspExtensions
    {
        public static FileInfo GetLog4NetFile(this IWebHostEnvironment appEnv, string configFileRelativePath)
        {
            GlobalContext.Properties["appRoot"] = appEnv.ContentRootPath;
            var configFile = new FileInfo(Path.Combine(appEnv.ContentRootPath, configFileRelativePath));
            //XmlConfigurator.Configure(configFile);
            return configFile;

        }

        public static FileInfo GetLog4NetFile(string currentDir, string configFileRelativePath)
        {
            GlobalContext.Properties["appRoot"] = currentDir;
            var configFile = new FileInfo(Path.Combine(currentDir, configFileRelativePath));
            //XmlConfigurator.Configure(configFile);
            return configFile;
        }

        public static void AddLog4Net(this ILoggerFactory loggerFactory)
        {
            loggerFactory.AddProvider(new Log4NetProvider());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Core5SharedLibrary.Extensions
{
    public static class TypeExtensions
    {
        public static DateTime? ConvertToDateTimeOrNull(this object obj)
        {
            if (obj is DateTime)
                return (DateTime)obj;

            if (obj == null)
                return null;

            if (obj is string)
            {
                DateTime result;
                if (DateTime.TryParse((string)obj, out result))
                    return result;

                return null;
            }
            try
            {
                var result = Convert.ToDateTime(obj);
                return result;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static int? TryConvertToInt32(this object obj)
        {
            return obj.ConvertToInt32OrNull();
        }

        public static T? ToNullIfDefaultValue<T>(this T? obj) where T : struct
        {
            return obj?.ToNullIfDefaultValue();
        }

        public static T? ToNullIfDefaultValue<T>(this T obj) where T : struct
        {
            var foo = default(T);
            if (foo.Equals(obj))
                return null;
            return obj;
        }

        public static TR ToFuncTrueIfDefaultValue<T, TR>(this T obj, Func<T, bool, TR> res) where T : struct
        {
            var foo = default(T);
            if (foo.Equals(obj))
                return res(obj, true);

            return res(obj, false);
        }

        public static int? ConvertToInt32OrNull(this object obj)
        {
            if (obj is int)
                return (int)obj;

            if (obj == null)
                return null;

            if (obj is string)
            {
                int newValue;
                if (int.TryParse((string)obj, out newValue))
                {
                    return newValue;
                }
                return null;
            }

            try
            {
                return Convert.ToInt32(obj);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static IComparable ConvertToComparable(this object obj)
        {
            if (obj == null)
                return null;

            if (obj is IComparable)
                return (IComparable)obj;

            return null;
        }

        public static bool IsNullable<T>(T obj)
        {
            if (obj == null) return true; // obvious
            Type type = typeof(T);
            return IsNullableTypeCheck(type);
        }

        private static bool IsNullableTypeCheck(Type type)
        {
            if (!type.IsValueType) return true; // ref-type
            if (Nullable.GetUnderlyingType(type) != null) return true; // Nullable<T>
            return false; // value-type
        }


        public static int ConvertToInt32OrDefault(this object obj)
        {
            if (obj is int)
                return (int)obj;

            if (obj == null)
                return 0;

            if (obj is string)
            {
                int newValue;
                int.TryParse((string)obj, out newValue);
                return newValue;
            }

            try
            {
                return Convert.ToInt32(obj);
            }
            catch (Exception)
            {
                return 0;
            }
        }


        public static bool ConvertToBooleanOrDefault(this object obj)
        {
            if (obj is bool)
                return (bool)obj;

            if (obj == null)
                return false;

            var text = obj as string;
            if (text != null)
            {
                bool newValue;
                if (bool.TryParse(text, out newValue))
                    return newValue;

                if (StringComparer.OrdinalIgnoreCase.Equals("yes", text)
                    || StringComparer.OrdinalIgnoreCase.Equals("1", text)
                    || StringComparer.OrdinalIgnoreCase.Equals("true", text))
                    return true;

                return false;
            }

            try
            {
                return Convert.ToBoolean(obj);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static string ConvertToString(this IEnumerable<char> source)
        {
            if (source == null)
                throw new ArgumentNullException(nameof(source));

            string text;
            if (source is char[])
            {
                text = new string((char[])source);
            }
            else
            {
                text = new string(source.ToArray());
            }

            return text;
        }

        private static readonly char[] DefaultSplitOptions = new char[] { ',', ';' };
        public static IList<int> SplitToIntsSafe(this string text)
        {
            return SplitToIntsSafe(text, DefaultSplitOptions);
        }

        public static IList<int> SplitToIntsSafe(string text, char[] splitOptions)
        {
            if (text == null)
                return new int[0];
            if (string.IsNullOrWhiteSpace(text))
                return new int[0];

            var col = text.Split(splitOptions, StringSplitOptions.RemoveEmptyEntries);
            var result = col.Select(a =>
            {
                int number;
                if (int.TryParse(a, out number))
                {
                    return new int?(number);
                }

                return null;
            }).Where(a => a != null)
                .Select(a => a.Value)
                .ToArray();
            return result;
        }


        public static readonly Type TupleType = typeof(Tuple<>);

        public static string GetReadableTypeName(this Type type)
        {
            if (type == null)
                throw new ArgumentNullException(nameof(type));

            if (!type.IsGenericType)
                return type.GetNestedTypeName();

            StringBuilder stringBuilder = new StringBuilder();
            BuildClassNameRecursiv(type, stringBuilder);
            return stringBuilder.ToString();
        }

        private static void BuildClassNameRecursiv(Type type, StringBuilder classNameBuilder, int genericParameterIndex = 0)
        {
            if (type.IsGenericParameter)
                classNameBuilder.AppendFormat("T{0}", genericParameterIndex + 1);
            else if (type.IsGenericType)
            {
                classNameBuilder.Append(type.GetNestedTypeName() + "[");
                int subIndex = 0;
                foreach (Type genericTypeArgument in type.GetGenericArguments())
                {
                    if (subIndex > 0)
                        classNameBuilder.Append(":");

                    BuildClassNameRecursiv(genericTypeArgument, classNameBuilder, subIndex++);
                }
                classNameBuilder.Append("]");
            }
            else
                classNameBuilder.Append(type.GetNestedTypeName());
        }

        public static string GetNestedTypeName(this Type type)
        {
            if (type == null)
                throw new ArgumentNullException(nameof(type));
            if (!type.IsNested)
                return GetNonGenericTypeName(type);

            var nestedName = new StringBuilder();
            while (type != null)
            {
                if (nestedName.Length > 0)
                    nestedName.Insert(0, '.');

                nestedName.Insert(0, GetNonGenericTypeName(type));

                type = type.DeclaringType;
            }
            return nestedName.ToString();
        }

        private static string GetNonGenericTypeName(Type type)
        {
            return type.IsGenericType ? type.Name.Split('`')[0] : type.Name;
        }
    }


}

﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Extensions
{
    public static class GeneralExtensions
    {
        public static string FirstLetterToUpper(this string str)
        {
            if (str == null)
                return null;

            if (str.Length > 1)
                return char.ToUpper(str[0]) + str.Substring(1);

            return str.ToUpper();
        }

        public static void Run<T>(this IEnumerable<T> source)
        {
            using (var enumerator = source.GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                }
            }
        }

        public static async Task RunAsync<T>(this IEnumerable<T> source, Func<T, Task> action)
        {
            foreach (var next in source)
            {
                await action(next);
            }
        }

        public static IEnumerable<T> Do<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (var next in source)
            {
                action(next);
                yield return next;
            }
        }

        public static IEnumerable<T> ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (var item in source)
            {
                action(item);
            }
            return source;
        }

        public static string ConcatAllIfExists(this IEnumerable<string> source, string separator)
        {
            var strBuilder = new StringBuilder();
            foreach (var next in source)
            {
                if (string.IsNullOrWhiteSpace(next))
                    continue;

                if (strBuilder.Length > 0)
                    strBuilder.Append(separator);
                strBuilder.Append(next);
            }

            return strBuilder.ToString();
        }

        public static IEnumerable<T> ConcatAllSafe<T>(params IEnumerable<T>[] source)
        {
            IEnumerable<T> projection = Enumerable.Empty<T>();
            if (source == null)
                return projection;

            foreach (var enumerable in source)
            {
                if (enumerable == null)
                    continue;

                projection = projection.Concat(enumerable);
            }
            return projection;
        }

        public static V? GetOrNull<K, V>(this IDictionary<K, V> source, K key) where V : struct
        {
            if (key == null)
                return null;

            V result;
            if (source.TryGetValue(key, out result))
                return result;

            return default(V);
        }

        public static K GetOrDefault<T, K>(this IDictionary<T, K> source, T key)
        {
            if (key == null)
                return default;

            K result;
            if (source.TryGetValue(key, out result))
                return result;

            return default;
        }

        public static K GetOrCreate<T, K>(this IDictionary<T, K> source, T key, Func<T, K> creatorFunc)
        {
            K result;
            if (source.TryGetValue(key, out result))
                return result;

            source[key] = result = creatorFunc(key);
            return result;
        }

        public static L GetOrCreateCast<T, K, L>(this IDictionary<T, K> source, T key, Func<T, L> creatorFunc) where K : class
                                                                                                           where L : K
        {
            var res = source.GetOrCreate(key, a => creatorFunc(key));
            return (L)res;
        }

        public static string SafeSubstring(this string text, int start)
        {
            if (text == null) return null;

            return text.Length <= start ? "" : text.Substring(start);
        }

        public static string[] SplitFirst(this string source, char delimiter)
        {
            var i = source.IndexOf(delimiter);

            if (i == -1)
                return new[] { source };
            else
                return new[]
                {
                    source.Substring(0, i),
                    source.SafeSubstring(i + 1, source.Length - i - 1)
                };
        }

        public static string[] SplitFirst(this string source, string delimiter, StringComparison comparison = StringComparison.OrdinalIgnoreCase)
        {
            var i = source.IndexOf(delimiter, comparison);

            if (i == -1)
                return new[] { source };
            else
                return new[]
                {
                    source.Substring(0, i),
                    source.SafeSubstring(i + 1, source.Length - i - 1)
                };
        }

        public static string ToText(this IEnumerable<char> text)
        {
            if (text == null) return "";

            return new string(text.ToArray());
        }

        public static string SafeSubstring(this string text, int start, int length)
        {
            if (text == null) return null;

            return text.Length <= start ? ""
                : text.Length - start <= length ? text.Substring(start)
                : text.Substring(start, length);
        }

        public static string ToConcatenatedOrNull(this IList<int> collection, string separator = ",")
        {
            if (collection == null || collection.Count <= 0)
                return null;

            return string.Join(separator, collection);
        }

        public static string ToConcatenated(this IList<int> collection, string separator = ",")
        {
            if (collection == null)
                throw new ArgumentNullException(nameof(collection));

            return string.Join(separator, collection);
        }

        public static string ToConcatenated(this IEnumerable<string> collection, string separator = ",")
        {
            if (collection == null)
                throw new ArgumentNullException(nameof(collection));

            return string.Join(separator, collection);
        }

        public static string ToConcatenated(this Guid[] collection, string separator = ",")
        {
            if (collection == null)
                throw new ArgumentNullException(nameof(collection));

            return string.Join(separator, collection.Select(a => $"'{a}'"));
        }

        public static bool In(this string target, params string[] col)
        {
            return target.In(StringComparison.CurrentCulture, col);
        }
        public static bool InIgnoreCase(this string target, params string[] col)
        {
            return target.In(StringComparison.OrdinalIgnoreCase, col);
        }

        public static bool In(this string target, StringComparison comparisonType = StringComparison.OrdinalIgnoreCase, params string[] col)
        {
            if (target == null && col == null)
                return true;

            if (col == null || target == null)
                return false;

            if (col.Any(a => string.Equals(target, a, comparisonType)))
                return true;

            return false;
        }

        public static bool NotIn(this string target, params string[] col)
        {
            if (target == null && col == null)
                return false;

            if (col == null || target == null)
                return true;

            if (col.Any(target.Equals))
                return false;

            return true;
        }

        public static bool NotInIgnoreCase(this string target, params string[] col)
        {
            if (target == null && col == null)
                return false;

            if (col == null || target == null)
                return true;

            if (col.Any(a => StringComparer.OrdinalIgnoreCase.Equals(target, a)))
                return false;

            return true;
        }


        public static string ToSqlString(this ListSortDirection direction)
        {
            if (direction == ListSortDirection.Ascending)
            {
                return "ASC";
            }

            return "DESC";
        }


        public static Tuple<string, ListSortDirection> GetOrderByAndDirection(string jtSorting)
        {

            string[] sortConfig = jtSorting?.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries) ?? new[] { "" };

            string orderByColumn = null;
            string sortDirection = null;
            if (sortConfig.Length >= 1)
            {
                orderByColumn = sortConfig[0];
                if (sortConfig.Length >= 2)
                {
                    sortDirection = sortConfig[1];
                }
            }
            var listSortDirection = StringComparer.OrdinalIgnoreCase.Equals(sortDirection, "ASC") ? ListSortDirection.Ascending : ListSortDirection.Descending;
            return new Tuple<string, ListSortDirection>(orderByColumn, listSortDirection);
        }


        public static ExpandoObject ToExpando(this object anonymousObject)
        {
            IDictionary<string, object> expando = new ExpandoObject();
            foreach (PropertyDescriptor propertyDescriptor in TypeDescriptor.GetProperties(anonymousObject))
            {
                var obj = propertyDescriptor.GetValue(anonymousObject);
                expando.Add(propertyDescriptor.Name, obj);
            }
            return (ExpandoObject)expando;
        }

        public static string[] GetTypePropNames(Type targetType)
        {
            if (targetType == null)
                return new string[0];

            var allProps = targetType.GetProperties();
            return allProps.Select(a => a.Name).ToArray();
        }

        public static bool IsBitPositionSet<T>(T t, int pos) where T : struct, IConvertible
        {
            var value = t.ToInt64(CultureInfo.CurrentCulture);
            return (value & 1 << pos) != 0;
        }

        public static T[] Append<T>(this T[] source, T[] newItems)
        {
            var z = new T[source.Length + newItems.Length];
            source.CopyTo(z, 0);
            newItems.CopyTo(z, source.Length);
            return z;
        }

        public static T[] AppendOne<T>(this T[] source, T newItem)
        {
            var z = new T[source.Length + 1];
            source.CopyTo(z, 0);
            z[z.Length - 1] = newItem;
            return z;
        }

        public static string Trim(this string s, string trimmer, bool ignoreCase = true)
        {
            if (string.IsNullOrWhiteSpace(s))
                return s;

            if (string.IsNullOrEmpty(trimmer))
                return s;

            var temp = s;
            string copy;
            do
            {
                copy = temp;
                temp = copy.TrimStartOnce(trimmer, ignoreCase)
                    .TrimEndOnce(trimmer, ignoreCase);
            } while (temp != copy);

            return copy;
        }

        public static string TrimStartOnce(this string s, string trimmer, bool ignoreCase = true)
        {
            if (
                string.IsNullOrEmpty(s) ||
                string.IsNullOrEmpty(trimmer) ||
                !s.StartsWith(trimmer, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)
            )
                return s;
            else
                return s.Substring(trimmer.Length, s.Length - trimmer.Length);
        }

        public static string TrimEndOnce(this string s, string trimmer, bool ignoreCase = true)
        {
            if (
                string.IsNullOrEmpty(s) ||
                string.IsNullOrEmpty(trimmer) ||
                !s.EndsWith(trimmer, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)
                )
                return s;
            else
                return s.Substring(0, s.Length - trimmer.Length);
        }

        public static string RemoveDiacritics(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return text;

            var normalizedString = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }

        public static string Replace(this string source, string oldValue, string newValue, StringComparison comparisonType)
        {
            if (source.Length == 0 || oldValue.Length == 0)
                return source;

            var result = new StringBuilder();
            int startingPos = 0;
            int nextMatch;
            while ((nextMatch = source.IndexOf(oldValue, startingPos, comparisonType)) > -1)
            {
                result.Append(source, startingPos, nextMatch - startingPos);
                result.Append(newValue);
                startingPos = nextMatch + oldValue.Length;
            }

            if (result.Length <= 0)
                return source;

            result.Append(source, startingPos, source.Length - startingPos);
            return result.ToString();
        }

        public static bool TryRemoveMatch<TKey, TValue>(this ConcurrentDictionary<TKey, TValue> dictionary, KeyValuePair<TKey, TValue> pair)
        {
            if (dictionary == null)
                throw new ArgumentNullException(nameof(dictionary));

            return ((ICollection<KeyValuePair<TKey, TValue>>)dictionary).Remove(pair);
        }

        public static bool TryRemoveMatch<TKey, TValue>(this ConcurrentDictionary<TKey, TValue> dictionary, TKey key, TValue value)
        {
            if (dictionary == null)
                throw new ArgumentNullException(nameof(dictionary));

            return ((ICollection<KeyValuePair<TKey, TValue>>)dictionary).Remove(new KeyValuePair<TKey, TValue>(key, value));
        }

        public static NameValueCollection GetNameValueCollection(string uriQuery)
        {
            var queryParameters = new NameValueCollection();
            string[] querySegments = uriQuery.Split('&');
            foreach (string segment in querySegments)
            {
                string[] parts = segment.Split('=');
                if (parts.Length > 0)
                {
                    string key = parts[0].Trim(new char[] { '?', ' ' });
                    if (parts.Length > 1)
                    {
                        var encodedValue = parts[1].Trim();
                        string val = WebUtility.UrlDecode(encodedValue);
                        queryParameters.Add(key, val);
                    }
                    else
                    {
                        queryParameters.Add(key, "");
                    }
                }
            }
            return queryParameters;
        }

        public static string QueryBuilder(IEnumerable<KeyValuePair<string, string>> pairs)
        {
            var stringBuilder = new StringBuilder("?");
            foreach (var segment in pairs)
            {
                if (stringBuilder.Length > 1)
                    stringBuilder.Append("&");

                stringBuilder.Append($"{segment.Key}={WebUtility.UrlEncode(segment.Value)}");
            }

            return stringBuilder.ToString();
        }

        public static bool ExecuteSafe(Action action, Action<Exception> onError = null)
        {
            try
            {
                action();
                return true;
            }
            catch (Exception e)
            {
                onError?.Invoke(e);
                return false;
            }
        }

        public static bool ExecuteSafe<T>(Action<T> action, T arg, Action<T, Exception> onError = null)
        {
            try
            {
                action(arg);
                return true;
            }
            catch (Exception e)
            {
                onError?.Invoke(arg, e);
                return false;
            }
        }

        public static bool ExecuteSafe<T, T2>(Action<T, T2> action, T arg, T2 arg2, Action<T, T2, Exception> onError = null)
        {
            try
            {
                action(arg, arg2);
                return true;
            }
            catch (Exception e)
            {
                onError?.Invoke(arg, arg2, e);
                return false;
            }
        }

        /// <summary>
        /// Returns the only element of a sequence, or a default value if the sequence is empty or contains more than one element.
        /// </summary>
        public static TSource SingleOrDefaultIfMultiple<TSource>(this IEnumerable<TSource> source)
        {
            var elements = source.Take(2).ToArray();

            return elements.Length == 1 ? elements[0] : default;
        }

        /// <summary>
        /// Returns the only element of a sequence, or a default value if the sequence is empty or contains more than one element.
        /// </summary>
        public static TSource SingleOrDefaultIfMultiple<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate)
        {
            return source.Where(predicate).SingleOrDefaultIfMultiple();
        }

        /// <summary>
        /// Returns the only element of a sequence, or a default value if the sequence is empty or contains more than one element.
        /// </summary>
        public static TSource SingleOrDefaultIfMultiple<TSource>(this IQueryable<TSource> source)
        {
            var elements = source.Take(2).ToArray();

            return elements.Length == 1 ? elements[0] : default;
        }

        /// <summary>
        /// Returns the only element of a sequence, or a default value if the sequence is empty or contains more than one element.
        /// </summary>
        public static TSource SingleOrDefaultIfMultiple<TSource>(this IQueryable<TSource> source, Expression<Func<TSource, bool>> predicate)
        {
            return source.Where(predicate).SingleOrDefaultIfMultiple();
        }

        public static async Task<bool> ExecuteSafeAsync(Func<Task> action, Action<Exception> onError = null)
        {
            try
            {
                await action();
                return true;
            }
            catch (Exception e)
            {
                onError?.Invoke(e);
                return false;
            }
        }
    }
}

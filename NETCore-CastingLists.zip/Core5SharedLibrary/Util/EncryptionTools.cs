﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Util
{
    public class EncryptionTools
    {
        private static string CWB_SALT = "s&d0q8g6@2y7#yls3#20";

        public static string CwbEncrypt(string text)
        {
            return EncryptionHandlerEncodeHex(text);
        }

        public static string CwbDecrypt(string text)
        {
            return EncryptionHandlerHex(text);
        }

        private static int ParseNybble(char c)
        {
            if (c >= '0' && c <= '9')
            {
                return c - 48;
            }

            if (c >= 'A' && c <= 'F')
            {
                return c - 65 + 10;
            }

            if (c >= 'a' && c <= 'f')
            {
                return c - 97 + 10;
            }

            throw new ArgumentException("Invalid hex digit: " + c);
        }

        private static byte[] ParseHex(string hex)
        {
            int num = hex.StartsWith("0x") ? 2 : 0;
            if (hex.Length % 2 != 0)
            {
                throw new ArgumentException("Invalid length: " + hex.Length);
            }

            byte[] array = new byte[(hex.Length - num) / 2];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = (byte)((ParseNybble(hex[num]) << 4) | ParseNybble(hex[num + 1]));
                num += 2;
            }

            return array;
        }

        private static string EncryptionHandlerHex(string text)
        {
            try
            {
                return new RC4(CWB_SALT, RC4.HexStrToStr(text)).EnDeCrypt();
            }
            catch (Exception innerException)
            {
                throw new Exception($"Problem password: {text}", innerException);
            }
        }

        private static string EncryptionHandlerEncodeHex(string text)
        {
            return RC4.StrToHexStr(new RC4(CWB_SALT, text).EnDeCrypt());
        }
    }
}

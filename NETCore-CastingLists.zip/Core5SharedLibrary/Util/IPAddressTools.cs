﻿using System;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;

namespace Core5SharedLibrary.Util
{
    /// <summary>
    /// Provides tools for determining a user's true IP address, within the context of a
    /// proxied environment (via Apache2's mod_proxy) which may or may not be turned on
    /// or active. E.g. If the reverse proxy is disabled via a configuration change,
    /// the application must not rely on the "X-Forwarded-For" header since it will not
    /// exist. Furthermore, the ability to easily fake a X-Forwarded-For by an untrusted
    /// client is extremely easy, and would bypass the IP security of the application.
    /// This class provides a way to determine if the X-Forwarded-For header should be
    /// trusted or not. If the user's host is a LAN (or non-routable/private address)
    /// we assume that the traffic is from a trusted proxy (or LAN/VPN connection).
    /// Only then do we attempt to retrieve the user's IP address from the X-Forwarded-For
    /// header. In all other cases, the IP address will be retrieved from the user's
    /// host via the .NET HttpContext's Request object.
    /// 
    /// How to use (by example):
    /// string userIPAddress = IPAddressTools.GetRemoteIPByProxyStatus();
    /// // userIPAddress at this point will either contain:
    /// // 1. HttpContext.Current.Request.Headers["X-Forwarded-For"] -- Proxy is active, host is from trusted via LAN IP
    /// // 2. HttpContext.Current.Request.UserHostAddress -- Proxy is inactive
    /// </summary>
    public static class IPAddressTools
    {
        /// <summary>
        /// RFC 1918: Address Allocation for Private Internets
        /// http://www.faqs.org/rfcs/rfc1918.html
        /// These are private address spaces
        /// </summary>
        private static readonly IPAddress[] NON_ROUTABLE_ADDRS = new IPAddress[5]
        {
            IPAddress.Parse("127.0.0.1"), // 10.0.0.0 - 10.255.255.255 (10/8 prefix)
            IPAddress.Parse("10.0.0.0"), // 10.0.0.0 - 10.255.255.255 (10/8 prefix)
            IPAddress.Parse("172.16.0.0"), // 172.16.0.0 - 172.31.255.255 (172.16/12 prefix)
            IPAddress.Parse("192.168.0.0"), // 192.168.0.0 - 192.168.255.255 (192.168/16 prefix)
            IPAddress.Parse("192.168.2.0") // 192.168.0.0 - 192.168.255.255 (192.168/16 prefix)
        };

        /// <summary>
        /// Credit: http://blogs.msdn.com/knom/archive/2008/12/31/ip-address-calculations-with-c-subnetmasks-networks.aspx
        /// </summary>
        /// <param name="address"></param>
        /// <param name="subnetMask"></param>
        /// <returns></returns>
        public static IPAddress GetNetworkAddress(IPAddress address, IPAddress subnetMask)
        {
            if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                address = address.MapToIPv4();

            byte[] ipAdressBytes = address.GetAddressBytes();
            byte[] subnetMaskBytes = subnetMask.GetAddressBytes();

            // only do this check for IPV4
            if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && ipAdressBytes.Length != subnetMaskBytes.Length)
                throw new ArgumentException("Lengths of IP address and subnet mask do not match.");

            byte[] broadcastAddress = new byte[ipAdressBytes.Length];
            for (int i = 0; i < broadcastAddress.Length; i++)
            {
                broadcastAddress[i] = (byte)(ipAdressBytes[i] & (subnetMaskBytes[i]));
            }
            return new IPAddress(broadcastAddress);
        }

        /// <summary>
        /// Test if an IPv4 address is in a subnet
        /// </summary>
        /// <param name="address"></param>
        /// <param name="subnetMask"></param>
        /// <returns></returns>
        public static bool IsInSubnet(IPAddress address, IPAddress subnetMask)
        {
            IPAddress network = GetNetworkAddress(address, subnetMask);
            return address.Equals(subnetMask);
        }

        /// <summary>
        /// Test if an IPv4 address is non-routable
        /// </summary>
        /// <param name="address">IPv4 Address</param>
        /// <returns>true if address is non-routable</returns>
        public static bool IsNonRoutable(IPAddress address)
        {
            if (address == null)
                return true;

            foreach (IPAddress nonRoutableNetwork in NON_ROUTABLE_ADDRS)
            {
                IPAddress network = GetNetworkAddress(address, nonRoutableNetwork);
                if (network.Equals(nonRoutableNetwork))
                    return true;
            }
            return false;
        }

        public static bool IsInSameSubnet(this IPAddress sourceAddress, IPAddress targetAddress, IPAddress subnetMask)
        {
            var sourceMask = ReturnSubnetmask(sourceAddress);
            IPAddress network1 = GetNetworkAddress(sourceAddress, sourceMask);
            var targetMask = ReturnSubnetmask(targetAddress);
            IPAddress network2 = GetNetworkAddress(subnetMask, targetMask);

            return network1.Equals(network2);
        }

        public static IPAddress ReturnSubnetmask(IPAddress ipaddress)
        {
            uint firstOctet = ReturnFirtsOctet(ipaddress);
            if (firstOctet <= 127)
                return IPAddress.Parse("255.0.0.0");
            else if (firstOctet >= 128 && firstOctet <= 191)
                return IPAddress.Parse("255.255.0.0");
            else if (firstOctet >= 192 && firstOctet <= 223)
                return IPAddress.Parse("255.255.255.0");
            else return IPAddress.Parse("0.0.0.0");
        }

        public static uint ReturnFirtsOctet(IPAddress ipAddress)
        {
            byte[] byteIP = ipAddress.GetAddressBytes();
            uint ipInUint = (uint)byteIP[0];
            return ipInUint;
        }

        /// <summary>
        /// See static bool IsNonRoutable(IPAddress)
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        public static bool IsNonRoutable(string address)
        {
            if (address == null)
                return true;

            if (address.StartsWith("::1") ||
                address.StartsWith("[::1") ||
                address.StartsWith("127.0.0.1"))
                return true;

            return IsNonRoutable(IPAddress.Parse(address));
        }

        /// <summary>
        /// Return the IP Address of the remote client based on whether the request is being
        /// forwarded by a reverse proxy (Apache's mod_proxy) or not
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static string GetRemoteIPByProxyStatus(HttpContext context)
        {
            var ipAddress = GetRemoteIP(context);

            if (ipAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                ipAddress = ipAddress.MapToIPv4();

            var remoteIp = ipAddress.ToString();
            if (IsNonRoutable(remoteIp))
            {
                string forwardedForIp = GetForwardedForIP(context);
                if (String.IsNullOrEmpty(forwardedForIp))
                    return remoteIp; // user is in LAN/VPN environment, no proxy active
                else
                    return forwardedForIp; // proxy inserted header
            }

            return remoteIp; // proxy is not active
        }

        public static bool IsLocal(HttpContext context)
        {
            var connection = context.Connection;

            var result = IsLocalConnection(connection);
            return result;
        }

        public static bool IsLocalConnection(ConnectionInfo connection)
        {
            var remoteIpAddress = connection.RemoteIpAddress;
            if (remoteIpAddress.IsSet())
            {
                //We have a remote address set up
                return connection.LocalIpAddress.IsSet()
                    //Is local is same as remote, then we are local
                    ? remoteIpAddress.Equals(connection.LocalIpAddress)
                    //else we are remote if the remote IP address is not a loopback address
                    : IPAddress.IsLoopback(remoteIpAddress);
            }

            return true;
        }

        private const string NullIpAddress = "::1";
        private static bool IsSet(this IPAddress address)
        {
            return address != null && address.ToString() != NullIpAddress;
        }

        private static string GetForwardedForIP(HttpContext context)
        {
            string forwardedFor = context.Request.Headers["X-Forwarded-For"];
            if (!String.IsNullOrEmpty(forwardedFor))
            {
                int comma = forwardedFor.IndexOf(',');
                if (comma > -1)
                {
                    forwardedFor = forwardedFor.Substring(0, comma);
                }
            }
            return forwardedFor;
        }

        private static IPAddress GetRemoteIP(HttpContext context)
        {
            var feature = context.Features.Get<IHttpConnectionFeature>();
            if (feature == null)
                return null;

            return feature.RemoteIpAddress;
        }
    }
}

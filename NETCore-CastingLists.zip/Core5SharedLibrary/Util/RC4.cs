﻿using System;
using System.Text;

namespace Core5SharedLibrary.Util
{
    public class RC4
    {
        private const int N = 256;

        private int[] sbox;

        private string password;

        private string text;

        public string Text
        {
            get
            {
                return text;
            }
            set
            {
                text = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }

        public RC4(string password, string text)
        {
            this.password = password;
            this.text = text;
        }

        public RC4(string password)
        {
            this.password = password;
        }

        public string EnDeCrypt()
        {
            RC4Initialize();
            int num = 0;
            int num2 = 0;
            int num3 = 0;
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < text.Length; i++)
            {
                num = (num + 1) % 256;
                num2 = (num2 + sbox[num]) % 256;
                int num4 = sbox[num];
                sbox[num] = sbox[num2];
                sbox[num2] = num4;
                num3 = sbox[(sbox[num] + sbox[num2]) % 256];
                int value = text[i] ^ num3;
                stringBuilder.Append(Convert.ToChar(value));
            }

            return stringBuilder.ToString();
        }

        public static string StrToHexStr(string str)
        {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < str.Length; i++)
            {
                int num = Convert.ToInt32(str[i]);
                stringBuilder.Append($"{num:X2}");
            }

            return stringBuilder.ToString();
        }

        public static string HexStrToStr(string hexStr)
        {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < hexStr.Length; i += 2)
            {
                int value = Convert.ToInt32(hexStr.Substring(i, 2), 16);
                stringBuilder.Append(Convert.ToChar(value));
            }

            return stringBuilder.ToString();
        }

        private void RC4Initialize()
        {
            sbox = new int[256];
            int[] array = new int[256];
            int length = password.Length;
            for (int i = 0; i < 256; i++)
            {
                array[i] = password[i % length];
                sbox[i] = i;
            }

            int num = 0;
            for (int j = 0; j < 256; j++)
            {
                num = (num + sbox[j] + array[j]) % 256;
                int num2 = sbox[j];
                sbox[j] = sbox[num];
                sbox[num] = num2;
            }
        }
    }
}
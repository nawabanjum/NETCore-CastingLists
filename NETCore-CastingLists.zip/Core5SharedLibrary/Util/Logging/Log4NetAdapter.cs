﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using log4net;
using Microsoft.Extensions.Logging;

namespace Core5SharedLibrary.Util.Logging
{
    public class Log4NetAdapter : ILogger
    {
        private readonly ILog _logger;

        public Log4NetAdapter(string loggerName)
        {
            _logger = LogManager.GetLogger(loggerName);
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            switch (logLevel)
            {
                case LogLevel.Trace:
                case LogLevel.Debug:
                    return _logger.IsDebugEnabled;
                case LogLevel.Information:
                    return _logger.IsInfoEnabled;
                case LogLevel.Warning:
                    return _logger.IsWarnEnabled;
                case LogLevel.Error:
                    return _logger.IsErrorEnabled;
                case LogLevel.Critical:
                    return _logger.IsFatalEnabled;
                case LogLevel.None:
                    return false;
                default:
                    throw new ArgumentException($"Unknown log level {logLevel}.", nameof(logLevel));
            }
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return new EmptyDisposable();
        }

        public class EmptyDisposable : IDisposable
        {
            public void Dispose()
            {

            }
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            if (!IsEnabled(logLevel))
            {
                return;
            }
            if (formatter == null)
            {
                throw new ArgumentNullException(nameof(formatter));
            }

            string message;
            try
            {
                message = formatter(state, exception);
            }
            catch (Exception e)
            {
                message = "Unknown (Log Serializer Error)";
                //var format = state as FormattedLogValues;
                //if (format == null)
                //{
                //    message = "Unknown (log Serializer error)";
                //    if (exception == null)
                //        exception = e;
                //    else
                //        message = " | " + e.Message;
                //}
                //else
                //{
                //    var args = AsEnumerableSafe(format).ToArray();

                //    if (exception == null)
                //    {
                //        exception = args.FirstOrDefault(a => a.Value is Exception).Value as Exception;
                //    }

                //    message = ("Log message has invalid arguments | " + args.FirstOrDefault(a => a.Value is string).Value as string)
                //                        .Trim();
                //}
            }


            switch (logLevel)
            {
                case LogLevel.Trace:
                case LogLevel.Debug:
                    _logger.Debug(message, exception);
                    break;
                case LogLevel.Information:
                    _logger.Info(message, exception);
                    break;
                case LogLevel.Warning:
                    _logger.Warn(message, exception);
                    break;
                case LogLevel.Error:
                    _logger.Error(message, exception);
                    break;
                case LogLevel.Critical:
                    _logger.Fatal(message, exception);
                    break;
                case LogLevel.None:
                    break;
                default:
                    _logger.Warn($"Encountered unknown log level {logLevel}, writing out as Info.");
                    _logger.Info(message, exception);
                    break;
            }
        }

        //private static IEnumerable<KeyValuePair<string, object>> AsEnumerableSafe(FormattedLogValues format)
        //{
        //    var list = new List<KeyValuePair<string, object>>();
        //    for (int i = 0; i < format.Count; i++)
        //    {
        //        try
        //        {
        //            var result = format[i];
        //            list.Add(result);
        //        }
        //        catch (Exception)
        //        {
        //        }
        //    }

        //    return list;
        //}

        private static IEnumerable<T> YieldSafe<T>(IEnumerable<T> collection)
        {
            var list = new List<T>();
            using (var enumerator = collection.GetEnumerator())
            {
                int maxErrors = 10;
                int errors = 0;
                for (; ; )
                {
                    try
                    {
                        if (!enumerator.MoveNext())
                            break;
                    }
                    catch (Exception)
                    {
                        errors++;
                        if (maxErrors == errors)
                            break;

                        continue;
                    }

                    yield return enumerator.Current;
                }
            }
        }
    }
}
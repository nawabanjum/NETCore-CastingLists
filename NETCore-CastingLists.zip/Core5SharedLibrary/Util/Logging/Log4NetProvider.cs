﻿using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;

namespace Core5SharedLibrary.Util.Logging
{
    public class Log4NetProvider : ILoggerProvider
    {
        private readonly ConcurrentDictionary<string, ILogger> _loggers
            = new ConcurrentDictionary<string, ILogger>();

        public ILogger CreateLogger(string name)
        {
            var result = _loggers.GetOrAdd(name, key => new Log4NetAdapter(key));
            return result;
        }

        public void Dispose()
        {
            _loggers.Clear();
        }
    }
}
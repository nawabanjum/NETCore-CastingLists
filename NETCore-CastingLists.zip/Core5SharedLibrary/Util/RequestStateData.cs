﻿using Core5SharedLibrary.Extensions;
using Core5SharedLibrary.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using System;
using System.Security.Claims;

namespace Core5SharedLibrary.Util
{
    public class RequestStateData : IRequestStateData
    {
        private readonly IHttpContextAccessor _contextAccessor;

        private readonly HttpContext _savedContext; // in case that .Context is lazy evaluated outside of the thread

        public RequestStateData(IHttpContextAccessor contextAccessor)
        {
            if (contextAccessor == null)
                throw new ArgumentNullException(nameof(contextAccessor));

            _contextAccessor = contextAccessor;
            _savedContext = contextAccessor.HttpContext;
        }

        public string GetIPAddress()
        {
            var httpContext = _contextAccessor.HttpContext ?? _savedContext;
            if (httpContext == null)
                throw new NullReferenceException(nameof(httpContext));

            return IPAddressTools.GetRemoteIPByProxyStatus(httpContext);
        }

        public string GetUrlCalled()
        {
            var httpContext = _contextAccessor.HttpContext ?? _savedContext;
            if (httpContext == null)
                throw new NullReferenceException(nameof(httpContext));

            return httpContext.Request.GetDisplayUrl();
        }

        public ClaimsPrincipal GetPrincipal()
        {
            throw new NotImplementedException();
        }

        public string GetBrowserApp()
        {
            var httpContext = _contextAccessor.HttpContext ?? _savedContext;
            if (httpContext == null)
                throw new NullReferenceException(nameof(httpContext));

            string android = httpContext.Request.Headers["X-App-Android-Lang"].ToString();
            if (!string.IsNullOrWhiteSpace(android))
                return "Android";

            string browserApp = "";
            string userAgent = httpContext.Request.Headers["User-Agent"].ToString();

            if (String.IsNullOrWhiteSpace(userAgent))
                return "";

            if (userAgent.ContainsEx("selftaping") || userAgent.ContainsEx("alamofire"))
                browserApp = "iPhone/iPad";
            else if (userAgent.ContainsEx("okhttp"))
                browserApp = "Android";
            else if (userAgent.ContainsEx("Android"))
                browserApp = "Android";
            else if (userAgent.ContainsEx("iPhone"))
                browserApp = "iPhone";
            else if (userAgent.ContainsEx("Darwin"))
                browserApp = "iPhone/iPad";
            else if (userAgent.ContainsEx("iPad"))
                browserApp = "iPad";
            else if (userAgent.ContainsEx("iPod"))
                browserApp = "iPod";
            else if (userAgent.ContainsEx("Mac"))
                browserApp = "Mac";
            else if (userAgent.ContainsEx("Chrome"))
                browserApp = "Chrome";
            else if (userAgent.ContainsEx("Firefox"))
                browserApp = "Firefox";
            else if (userAgent.ContainsEx("Safari"))
                browserApp = "Safari";
            else if (userAgent.ContainsEx("Opera"))
                browserApp = "Opera";
            else if (userAgent.ContainsEx("MSIE"))
                browserApp = "IExplorer";
            else if (userAgent.ContainsEx("Netscape"))
                browserApp = "Netscape";
            else
                browserApp = "Other";

            return browserApp;
        }

        public string GetRequestAgent()
        {
            var httpContext = _contextAccessor.HttpContext ?? _savedContext;
            if (httpContext == null)
                throw new NullReferenceException(nameof(httpContext));

            return httpContext.Request.Headers["User-Agent"].ToString();
        }

        public string GetCookieValue(string cookieKey)
        {
            throw new NotImplementedException();
        }

        public string GetReferralSource()
        {
            var httpContext = _contextAccessor.HttpContext ?? _savedContext;
            if (httpContext == null)
                return "";

            return httpContext.Request.Headers["Referer"].ToString();
        }
    }
}
﻿using System;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace Core5SharedLibrary.Util
{
    public class DataConnector : IDataConnectorEx
    {
        public DataConnector()
        {

        }

        public DataConnector(IConfiguration config)
        {
            if (config == null)
                throw new ArgumentNullException(nameof(config));

            CoreConfig = config;
        }

        public IConfiguration CoreConfig { get; set; }

        public DbConnection GetOpenConnection(DbConnectionType connectionType)
        {
            var connectionString = ResolveConnectionString(connectionType);
            DbConnection sql = new SqlConnection(connectionString);
            try
            {
                sql.Open();
            }
            catch (Exception)
            {
                try
                {
                    sql.Dispose();
                }
                catch (Exception)
                {
                }

                throw;
            }


            return sql;
        }

        public virtual string ResolveConnectionString(DbConnectionType connectionType)
        {
            var configurationSection = CoreConfig.GetChildren()?.FirstOrDefault(a => string.Equals(a.Key, "ConnectionStrings", StringComparison.OrdinalIgnoreCase));

            if (configurationSection == null)
                throw new InvalidOperationException(nameof(configurationSection) + ":ConnectionStrings");

            var targetConfig = connectionType.ToString();
            var connectionString = configurationSection[targetConfig];
            return connectionString;
        }
    }
}
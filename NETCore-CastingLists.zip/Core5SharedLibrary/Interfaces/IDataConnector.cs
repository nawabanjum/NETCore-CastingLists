﻿using System.Data.Common;

namespace Core5SharedLibrary
{
    public interface IDataConnector
    {
        DbConnection GetOpenConnection(DbConnectionType connectionType = DbConnectionType.Clients);
    }

    public interface IDataConnectorEx : IDataConnector
    {
        string ResolveConnectionString(DbConnectionType connectionType);
    }

    public enum DbConnectionType
    {
        ProjectMan,
        Clients,
        Casting,
        Uploader,
        Performers
        
    }
}
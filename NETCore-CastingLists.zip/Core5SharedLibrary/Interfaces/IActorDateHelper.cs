﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core5SharedLibrary.Interfaces
{
    public interface IActorDateHelper
    {
        
        /// <summary>
        /// Converts logged-in user date time to server (Vancouver) date time
        /// </summary>
        /// <param name="dateToConvert"></param>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        Task<DateTime?> ConvertUserDateToVancouverTime(DateTime? dateToConvert, int userId, int userType);

        /// <summary>
        /// Gets server offset from a given date time
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        DateTimeOffset? GetServerDateTimeOffset(DateTime? date);

    

        /// <summary>
        /// Use it to get home city id by any user Id and user Type
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <returns>Home City Id</returns>
        Task<int> GetUserHomeCityId(int userId, int userType);

         
        /// <summary>
        /// Use it to get the any user home city offset in hours by userId and userType
        /// </summary>
        /// <returns>home city offset in hours</returns>
        Task<int> GetUserHomeCityOffSetInHours(int userId, int userType);

   

        /// <summary>
        /// Converts the given dateToConvert time to given users home city Date Time
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <param name="dateToConvert"></param>
        /// <returns>Converted Date Time to given User Home City</returns>
        Task<DateTime?> ToUserHomeCityTime(int userId, int userType, DateTime? dateToConvert);

        /// <summary>
        /// Converts the given dateToConvert time to Logged-In users home city Date Time
        /// </summary>
        /// <param name="dateToConvert"></param>
        /// <param name="offSetInHours">Add this so a call to database is not made each time, when cache is disabled</param>
        /// <returns>Converted Date Time to Logged-In User Home City</returns>
        Task<DateTime?> ToUserHomeCityTime(DateTime? dateToConvert, int offSetInHours);
    }



}

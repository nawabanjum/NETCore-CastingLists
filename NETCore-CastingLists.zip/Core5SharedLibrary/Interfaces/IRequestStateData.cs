﻿using System;
using System.Security.Claims;

namespace Core5SharedLibrary.Interfaces
{
    public interface IRequestUserData : IRequestStateData, IAuthenticatedUserAccessor
    {
        T GetAuthenticatedUserInfo<T>(Func<ClaimsIdentity, T> userInfoBuilder);
    }

    public interface IRequestStateData
    {
        string GetIPAddress();

        string GetUrlCalled();

        ClaimsPrincipal GetPrincipal();

        string GetBrowserApp();

        string GetRequestAgent();

        string GetCookieValue(string cookieKey);

        string GetReferralSource();
    }
}
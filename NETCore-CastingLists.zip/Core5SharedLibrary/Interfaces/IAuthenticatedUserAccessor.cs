﻿using System.Security.Claims;

namespace Core5SharedLibrary.Interfaces
{
    public interface IAuthenticatedUserAccessor
    {
        ClaimsIdentity GetAuthenticatedUser();

        ClaimsPrincipal GetAuthenticatedPrincipal();
    }
}